const sql = require('mssql');

function buildConfig() {
  // Kết nối THẲNG tới SQL Server qua TCP, không phụ thuộc SQL Server Browser.
  // Cấu hình mong muốn của máy hiện tại:
  //   Server   = Cyro
  //   Instance = DEEPSERVER (chỉ mang tính thông tin; không dùng khi đã chỉ rõ port)
  //   Database = QLBanHang
  //   TCP Port = 1433
  const server = (process.env.DB_SERVER || 'Cyro').trim();
  const database = (process.env.DB_DATABASE || 'QLBanHang').trim();
  const user = (process.env.DB_USER || 'sa').trim();
  const password = process.env.DB_PASSWORD || '';
  const port = Number(process.env.DB_PORT || 1433);

  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error(`DB_PORT không hợp lệ: ${process.env.DB_PORT}`);
  }

  return {
    server,
    port,
    database,
    user,
    password,
    options: {
      encrypt: String(process.env.DB_ENCRYPT || 'false').toLowerCase() === 'true',
      trustServerCertificate:
        String(process.env.DB_TRUST_SERVER_CERTIFICATE || 'true').toLowerCase() === 'true',
      enableArithAbort: true
    },
    pool: {
      max: 10,
      min: 0,
      idleTimeoutMillis: 30000
    },
    connectionTimeout: Number(process.env.DB_CONNECTION_TIMEOUT || 15000),
    requestTimeout: Number(process.env.DB_REQUEST_TIMEOUT || 30000)
  };
}

const config = buildConfig();
let poolPromise;

function describeConfig() {
  return `${config.server}:${config.port}/${config.database}`;
}

async function getPool() {
  if (!poolPromise) {
    poolPromise = new sql.ConnectionPool(config)
      .connect()
      .then(pool => {
        console.log(`Đã kết nối SQL Server: ${describeConfig()}`);
        return pool;
      })
      .catch(error => {
        poolPromise = undefined;
        throw error;
      });
  }

  return poolPromise;
}

async function testConnection() {
  const pool = await getPool();
  const result = await pool.request().query(`
    SELECT
      DB_NAME() AS DatabaseName,
      @@SERVERNAME AS ServerName,
      @@SERVICENAME AS ServiceName,
      CONNECTIONPROPERTY('net_transport') AS NetTransport,
      CONNECTIONPROPERTY('local_net_address') AS LocalNetAddress,
      CONNECTIONPROPERTY('local_tcp_port') AS LocalTcpPort
  `);

  return result.recordset[0];
}

async function query(text, inputs = []) {
  const pool = await getPool();
  const request = pool.request();
  inputs.forEach(p => request.input(p.name, p.type, p.value));

  // Giữ tương thích với các route của project: query() trả về một mảng
  // chứa kết quả mssql, nên code gọi [0].recordset sẽ hoạt động.
  const result = await request.query(text);
  return [result];
}

async function execute(text, inputs = []) {
  return query(text, inputs);
}

async function procedure(name, inputs = [], outputParams = []) {
  const pool = await getPool();
  const request = pool.request();
  inputs.forEach(p => request.input(p.name, p.type, p.value));
  outputParams.forEach(p => request.output(p.name, p.type, p.value));
  return request.execute(name);
}

async function closePool() {
  if (poolPromise) {
    try {
      const pool = await poolPromise;
      await pool.close();
    } finally {
      poolPromise = undefined;
    }
  }
}

module.exports = {
  sql,
  config,
  buildConfig,
  describeConfig,
  getPool,
  testConnection,
  query,
  execute,
  procedure,
  closePool
};
