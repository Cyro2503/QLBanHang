﻿/* =====================================================================
   01_TaoBang.sql - CSDL QLBanHang (cửa hàng điện máy TechMart) - SQL Server
   Phần 1 của đề: thiết kế CSDL, 9 bảng theo đề.
   Đổi tên database thành QLBanHang_<MãNhóm> nếu cần (sửa 3 chỗ: CREATE DATABASE, USE, và DB_ID).
   Chạy lại được nhiều lần (tự xóa bảng cũ theo thứ tự phụ thuộc).

   Các bảng: LoaiSanPham, NhaCungCap, SanPham, KhachHang, NhanVien,
             HoaDon, ChiTietHoaDon, PhieuNhap, ChiTietPhieuNhap.

   Thiết kế đã thống nhất:
   1) SanPham chỉ liên kết với LoaiSanPham. Nhà cung cấp được xác định tại từng dòng
      nhập hàng qua ChiTietPhieuNhap.MaNCC, vì một sản phẩm có thể được nhập từ nhiều NCC.
   2) HoaDon và PhieuNhap chỉ chứa thông tin tổng quát của chứng từ.
      - ChiTietHoaDon chứa sản phẩm, số lượng, đơn giá bán và phần trăm giảm giá.
      - ChiTietPhieuNhap chứa sản phẩm, nhà cung cấp, số lượng và giá nhập.
   3) Không sử dụng LoaiHD và không tạo bảng LichSuGia.

   Quy ước ON DELETE: mọi khóa ngoại dùng NO ACTION (không cho xóa dây chuyền).
   Lý do: chứng từ bán/nhập là dữ liệu kế toán, không được mất dấu vết khi xóa danh mục
   (khách, nhân viên, sản phẩm, nhà cung cấp...). Hóa đơn sai thì chuyển sang 'Đã hủy' thay vì xóa.
   Nếu xóa dòng chi tiết thì phải xóa từng dòng để trigger hoàn lại tồn kho; ON DELETE CASCADE
   sẽ xóa chi tiết sau khi dòng cha đã mất nên trigger không tính đúng được tồn kho.
   ===================================================================== */

IF DB_ID(N'QLBanHang') IS NULL
    CREATE DATABASE QLBanHang;
GO

USE QLBanHang;
GO

/* ---------- Xóa bảng cũ (bảng con trước, bảng cha sau) ---------- */
-- Dọn các bảng của phiên bản thiết kế trước (kho, hóa đơn nhập, thanh toán nhập) nếu còn sót,
-- vì chúng có khóa ngoại trỏ tới các bảng bên dưới và sẽ chặn việc xóa.
IF OBJECT_ID(N'dbo.ChiTietPhieuChuyenKho', N'U') IS NOT NULL DROP TABLE dbo.ChiTietPhieuChuyenKho;   -- bảng cũ
IF OBJECT_ID(N'dbo.PhieuChuyenKho',   N'U') IS NOT NULL DROP TABLE dbo.PhieuChuyenKho;               -- bảng cũ
IF OBJECT_ID(N'dbo.TonKho',           N'U') IS NOT NULL DROP TABLE dbo.TonKho;                       -- bảng cũ
IF OBJECT_ID(N'dbo.ThanhToanNhap',    N'U') IS NOT NULL DROP TABLE dbo.ThanhToanNhap;                -- bảng cũ
IF OBJECT_ID(N'dbo.HoaDonNhap',       N'U') IS NOT NULL DROP TABLE dbo.HoaDonNhap;                   -- bảng cũ
IF OBJECT_ID(N'dbo.ChiTietPhieuNhap', N'U') IS NOT NULL DROP TABLE dbo.ChiTietPhieuNhap;
IF OBJECT_ID(N'dbo.PhieuNhap',        N'U') IS NOT NULL DROP TABLE dbo.PhieuNhap;
IF OBJECT_ID(N'dbo.ChiTietHoaDon',    N'U') IS NOT NULL DROP TABLE dbo.ChiTietHoaDon;
IF OBJECT_ID(N'dbo.HoaDon',           N'U') IS NOT NULL DROP TABLE dbo.HoaDon;
IF OBJECT_ID(N'dbo.Kho',              N'U') IS NOT NULL DROP TABLE dbo.Kho;                          -- bảng cũ
IF OBJECT_ID(N'dbo.LichSuGia',        N'U') IS NOT NULL DROP TABLE dbo.LichSuGia;                -- bảng đã loại bỏ khỏi thiết kế
IF OBJECT_ID(N'dbo.SanPham',          N'U') IS NOT NULL DROP TABLE dbo.SanPham;
IF OBJECT_ID(N'dbo.NhanVien',         N'U') IS NOT NULL DROP TABLE dbo.NhanVien;
IF OBJECT_ID(N'dbo.KhachHang',        N'U') IS NOT NULL DROP TABLE dbo.KhachHang;
IF OBJECT_ID(N'dbo.NhaCungCap',       N'U') IS NOT NULL DROP TABLE dbo.NhaCungCap;
IF OBJECT_ID(N'dbo.LoaiSanPham',      N'U') IS NOT NULL DROP TABLE dbo.LoaiSanPham;
GO

/* Giải thích chọn kiểu dữ liệu:
   - Mã (MaSP, MaKH...): VARCHAR(10) vì chỉ gồm chữ và số không dấu (SP001, KH0001), nhỏ gọn, dễ so sánh.
   - Tên, địa chỉ, chức vụ...: NVARCHAR vì có dấu tiếng Việt (Unicode).
   - Số điện thoại: VARCHAR(15) (giữ số 0 đầu, không tính toán), email: VARCHAR(100).
   - Tiền (giá bán, giá nhập, lương): DECIMAL(18,2), chính xác, không sai số như FLOAT.
   - Phần trăm giảm giá: DECIMAL(5,2) (0.00 đến 100.00, thực tế bị CHECK giới hạn 50).
   - Số lượng: INT. Ngày sinh/đăng ký/vào làm: DATE. Ngày giờ lập chứng từ: DATETIME. */

/* ---------- 1. LoaiSanPham ---------- */
CREATE TABLE dbo.LoaiSanPham (
    MaLoai   VARCHAR(10)   NOT NULL,
    TenLoai  NVARCHAR(100) NOT NULL,
    CONSTRAINT PK_LoaiSanPham PRIMARY KEY (MaLoai),
    CONSTRAINT UQ_LoaiSanPham_TenLoai UNIQUE (TenLoai)
);
GO

/* ---------- 2. NhaCungCap ---------- */
CREATE TABLE dbo.NhaCungCap (
    MaNCC        VARCHAR(10)   NOT NULL,
    TenNCC       NVARCHAR(150) NOT NULL,
    SoDienThoai  VARCHAR(15)   NULL,
    Email        VARCHAR(100)  NULL,
    DiaChi       NVARCHAR(255) NULL,
    CONSTRAINT PK_NhaCungCap PRIMARY KEY (MaNCC)
);
GO

-- Email nhà cung cấp không trùng; cho phép NULL nếu chưa có email.
CREATE UNIQUE INDEX UX_NhaCungCap_Email
    ON dbo.NhaCungCap(Email)
    WHERE Email IS NOT NULL;
GO

/* ---------- 3. SanPham ----------
   Khóa ngoại chỉ có MaLoai (mỗi sản phẩm thuộc một loại duy nhất).
   Nhà cung cấp không gắn cố định: xem ghi chú đầu file. */
CREATE TABLE dbo.SanPham (
    MaSP        VARCHAR(10)   NOT NULL,
    TenSP       NVARCHAR(200) NOT NULL,
    DonViTinh   NVARCHAR(30)  NOT NULL,
    GiaBan      DECIMAL(18,2) NOT NULL,
    SoLuongTon  INT           NOT NULL CONSTRAINT DF_SanPham_SoLuongTon DEFAULT (0),
    MaLoai      VARCHAR(10)   NOT NULL,
    CONSTRAINT PK_SanPham PRIMARY KEY (MaSP),
    CONSTRAINT FK_SanPham_LoaiSanPham FOREIGN KEY (MaLoai) REFERENCES dbo.LoaiSanPham(MaLoai) ON DELETE NO ACTION,
    CONSTRAINT CK_SanPham_GiaBan     CHECK (GiaBan > 0),
    CONSTRAINT CK_SanPham_SoLuongTon CHECK (SoLuongTon >= 0)   -- chốt chặn cuối cùng chống bán vượt tồn
);
GO

/* ---------- 4. KhachHang ---------- */
CREATE TABLE dbo.KhachHang (
    MaKH           VARCHAR(10)   NOT NULL,
    HoTen          NVARCHAR(100) NOT NULL,
    SoDienThoai    VARCHAR(15)   NOT NULL,
    Email          VARCHAR(100)  NULL,
    DiaChi         NVARCHAR(255) NULL,
    NgayDangKy     DATE          NOT NULL CONSTRAINT DF_KhachHang_NgayDangKy DEFAULT (CAST(GETDATE() AS DATE)),
    HangThanhVien  NVARCHAR(10)  NOT NULL CONSTRAINT DF_KhachHang_Hang DEFAULT (N'Đồng'),
    CONSTRAINT PK_KhachHang PRIMARY KEY (MaKH),
    CONSTRAINT UQ_KhachHang_SoDienThoai UNIQUE (SoDienThoai),
    CONSTRAINT CK_KhachHang_Hang CHECK (HangThanhVien IN (N'Đồng', N'Bạc', N'Vàng'))
);
GO

-- Email không trùng. Dùng unique index lọc (bỏ qua NULL) vì UNIQUE thường của SQL Server
-- chỉ cho phép đúng một dòng NULL, trong khi nhiều khách có thể chưa có email.
CREATE UNIQUE INDEX UX_KhachHang_Email ON dbo.KhachHang(Email) WHERE Email IS NOT NULL;
GO

/* ---------- 5. NhanVien ---------- */
CREATE TABLE dbo.NhanVien (
    MaNV        VARCHAR(10)   NOT NULL,
    HoTen       NVARCHAR(100) NOT NULL,
    NgaySinh    DATE          NOT NULL,
    GioiTinh    NVARCHAR(3)   NOT NULL,
    ChucVu      NVARCHAR(50)  NOT NULL,
    LuongCoBan  DECIMAL(18,2) NOT NULL,
    NgayVaoLam  DATE          NOT NULL,
    CONSTRAINT PK_NhanVien PRIMARY KEY (MaNV),
    CONSTRAINT CK_NhanVien_GioiTinh CHECK (GioiTinh IN (N'Nam', N'Nữ')),
    CONSTRAINT CK_NhanVien_Luong    CHECK (LuongCoBan >= 0),
    CONSTRAINT CK_NhanVien_Du18Tuoi CHECK (DATEADD(YEAR, 18, NgaySinh) <= NgayVaoLam)   -- đủ 18 tuổi khi vào làm
);
GO

/* ---------- 6. HoaDon ----------
   Chỉ giữ thông tin chung của chứng từ bán: số hóa đơn, ngày lập, khách hàng,
   nhân viên và trạng thái. Thông tin sản phẩm nằm hoàn toàn ở ChiTietHoaDon.
*/
CREATE TABLE dbo.HoaDon (
    SoHD       VARCHAR(10) NOT NULL,
    NgayLap    DATETIME    NOT NULL CONSTRAINT DF_HoaDon_NgayLap DEFAULT (GETDATE()),
    MaKH       VARCHAR(10) NOT NULL,
    MaNV       VARCHAR(10) NOT NULL,
    TrangThai  NVARCHAR(20) NOT NULL CONSTRAINT DF_HoaDon_TrangThai DEFAULT (N'Chờ thanh toán'),
    CONSTRAINT PK_HoaDon PRIMARY KEY (SoHD),
    CONSTRAINT FK_HoaDon_KhachHang FOREIGN KEY (MaKH) REFERENCES dbo.KhachHang(MaKH) ON DELETE NO ACTION,
    CONSTRAINT FK_HoaDon_NhanVien  FOREIGN KEY (MaNV) REFERENCES dbo.NhanVien(MaNV) ON DELETE NO ACTION,
    CONSTRAINT CK_HoaDon_TrangThai CHECK (TrangThai IN (N'Chờ thanh toán', N'Đã thanh toán', N'Đã hủy'))
);
GO

/* ---------- 7. ChiTietHoaDon ----------
   Mỗi dòng là một sản phẩm của hóa đơn bán. */
CREATE TABLE dbo.ChiTietHoaDon (
    SoHD          VARCHAR(10)   NOT NULL,
    MaSP          VARCHAR(10)   NOT NULL,
    SoLuong       INT           NOT NULL,
    DonGiaBan     DECIMAL(18,2) NOT NULL,
    PhanTramGiam  DECIMAL(5,2)  NOT NULL CONSTRAINT DF_CTHD_Giam DEFAULT (0),
    CONSTRAINT PK_ChiTietHoaDon PRIMARY KEY (SoHD, MaSP),
    CONSTRAINT FK_CTHD_HoaDon  FOREIGN KEY (SoHD) REFERENCES dbo.HoaDon(SoHD) ON DELETE NO ACTION,
    CONSTRAINT FK_CTHD_SanPham FOREIGN KEY (MaSP) REFERENCES dbo.SanPham(MaSP) ON DELETE NO ACTION,
    CONSTRAINT CK_CTHD_SoLuong CHECK (SoLuong > 0),
    CONSTRAINT CK_CTHD_DonGia CHECK (DonGiaBan > 0),
    CONSTRAINT CK_CTHD_Giam CHECK (PhanTramGiam BETWEEN 0 AND 50)
);
GO

/* ---------- 8. PhieuNhap ----------
   Chỉ giữ thông tin chung của phiếu nhập: số phiếu, ngày nhập và nhân viên lập.
   Nhà cung cấp thuộc về từng dòng nhập nên đặt ở ChiTietPhieuNhap.MaNCC. */
CREATE TABLE dbo.PhieuNhap (
    SoPN     VARCHAR(10) NOT NULL,
    NgayNhap DATETIME    NOT NULL CONSTRAINT DF_PhieuNhap_NgayNhap DEFAULT (GETDATE()),
    MaNV     VARCHAR(10) NOT NULL,
    CONSTRAINT PK_PhieuNhap PRIMARY KEY (SoPN),
    CONSTRAINT FK_PhieuNhap_NhanVien FOREIGN KEY (MaNV) REFERENCES dbo.NhanVien(MaNV) ON DELETE NO ACTION
);
GO

/* ---------- 9. ChiTietPhieuNhap ----------
   Mỗi dòng xác định sản phẩm, nhà cung cấp, số lượng và giá nhập. */
CREATE TABLE dbo.ChiTietPhieuNhap (
    SoPN     VARCHAR(10)   NOT NULL,
    MaSP     VARCHAR(10)   NOT NULL,
    MaNCC    VARCHAR(10)   NOT NULL,
    SoLuong  INT           NOT NULL,
    GiaNhap  DECIMAL(18,2) NOT NULL,
    CONSTRAINT PK_ChiTietPhieuNhap PRIMARY KEY (SoPN, MaSP),
    CONSTRAINT FK_CTPN_PhieuNhap FOREIGN KEY (SoPN) REFERENCES dbo.PhieuNhap(SoPN) ON DELETE NO ACTION,
    CONSTRAINT FK_CTPN_SanPham FOREIGN KEY (MaSP) REFERENCES dbo.SanPham(MaSP) ON DELETE NO ACTION,
    CONSTRAINT FK_CTPN_NhaCungCap FOREIGN KEY (MaNCC) REFERENCES dbo.NhaCungCap(MaNCC) ON DELETE NO ACTION,
    CONSTRAINT CK_CTPN_SoLuong CHECK (SoLuong > 0),
    CONSTRAINT CK_CTPN_GiaNhap CHECK (GiaNhap > 0)
);
GO

/* ---------- Chỉ mục cho các khóa ngoại hay truy vấn ---------- */
CREATE INDEX IX_SanPham_MaLoai   ON dbo.SanPham(MaLoai);
CREATE INDEX IX_HoaDon_MaKH      ON dbo.HoaDon(MaKH);
CREATE INDEX IX_HoaDon_MaNV      ON dbo.HoaDon(MaNV);
CREATE INDEX IX_CTHD_MaSP        ON dbo.ChiTietHoaDon(MaSP);
CREATE INDEX IX_CTPN_MaNCC      ON dbo.ChiTietPhieuNhap(MaNCC);
CREATE INDEX IX_PhieuNhap_MaNV   ON dbo.PhieuNhap(MaNV);
CREATE INDEX IX_CTPN_MaSP        ON dbo.ChiTietPhieuNhap(MaSP);
GO
