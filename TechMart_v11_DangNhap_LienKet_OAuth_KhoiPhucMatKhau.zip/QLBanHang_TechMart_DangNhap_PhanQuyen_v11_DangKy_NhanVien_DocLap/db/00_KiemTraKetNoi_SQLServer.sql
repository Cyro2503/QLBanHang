/* Chạy trong SSMS khi đang kết nối thành công tới database QLBanHang. */
SELECT
    @@SERVERNAME AS ServerName,
    @@SERVICENAME AS InstanceName,
    DB_NAME() AS DatabaseName,
    CONNECTIONPROPERTY('local_net_address') AS LocalNetAddress,
    CONNECTIONPROPERTY('local_tcp_port') AS TcpPort,
    SERVERPROPERTY('IsIntegratedSecurityOnly') AS WindowsOnly;

/* Kiểm tra database có tồn tại */
SELECT name, state_desc, recovery_model_desc
FROM sys.databases
WHERE name = N'QLBanHang';

/* Kiểm tra các bảng mà web sử dụng */
SELECT s.name AS SchemaName, t.name AS TableName
FROM QLBanHang.sys.tables t
JOIN QLBanHang.sys.schemas s ON s.schema_id = t.schema_id
WHERE s.name = N'dbo'
ORDER BY t.name;
