/* =====================================================================
   06_PhanQuyen_DangNhap.sql
   Đăng nhập nội bộ + phân quyền tài khoản cho TechMart.

   Chạy SAU 01_TaoBang_Sua.sql và 02_BoSung_Gmail_NhaCungCap.sql (nếu có).
   Script này chỉ bổ sung bảng, không xóa 9 bảng nghiệp vụ hiện tại.

   Luồng:
   1) Admin tạo hồ sơ nhân viên trong dbo.NhanVien.
   2) Admin tạo tài khoản nội bộ, gắn MaNV và cấp vai trò.
   3) Nhân viên chỉ đăng nhập bằng tài khoản do Admin tạo.
   4) Không có đăng ký công khai hoặc tự tạo tài khoản qua mạng xã hội.
   ===================================================================== */

USE QLBanHang;
GO

IF OBJECT_ID(N'dbo.VaiTro', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.VaiTro (
        MaVaiTro  VARCHAR(30) NOT NULL,
        TenVaiTro NVARCHAR(80) NOT NULL,
        MoTa      NVARCHAR(255) NULL,
        CONSTRAINT PK_VaiTro PRIMARY KEY (MaVaiTro),
        CONSTRAINT UQ_VaiTro_Ten UNIQUE (TenVaiTro)
    );
END
GO

IF OBJECT_ID(N'dbo.Quyen', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Quyen (
        MaQuyen   VARCHAR(80) NOT NULL,
        TenQuyen  NVARCHAR(100) NOT NULL,
        NhomQuyen NVARCHAR(50) NOT NULL,
        MoTa      NVARCHAR(255) NULL,
        CONSTRAINT PK_Quyen PRIMARY KEY (MaQuyen),
        CONSTRAINT UQ_Quyen_Ten UNIQUE (TenQuyen)
    );
END
GO

IF OBJECT_ID(N'dbo.TaiKhoan', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.TaiKhoan (
        TaiKhoanId      INT IDENTITY(1,1) NOT NULL,
        TenDangNhap     VARCHAR(50) NOT NULL,
        MatKhauHash     VARCHAR(300) NOT NULL,
        MaNV            VARCHAR(10) NULL,
        TrangThai       VARCHAR(20) NOT NULL CONSTRAINT DF_TaiKhoan_TrangThai DEFAULT ('CHO_DUYET'),
        NgayTao         DATETIME2(0) NOT NULL CONSTRAINT DF_TaiKhoan_NgayTao DEFAULT (SYSDATETIME()),
        LanDangNhapCuoi DATETIME2(0) NULL,
        CONSTRAINT PK_TaiKhoan PRIMARY KEY (TaiKhoanId),
        CONSTRAINT UQ_TaiKhoan_TenDangNhap UNIQUE (TenDangNhap),
        CONSTRAINT CK_TaiKhoan_TrangThai CHECK (TrangThai IN ('CHO_DUYET', 'HOAT_DONG', 'KHOA')),
        CONSTRAINT FK_TaiKhoan_NhanVien FOREIGN KEY (MaNV) REFERENCES dbo.NhanVien(MaNV) ON DELETE NO ACTION
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_TaiKhoan_MaNV' AND object_id = OBJECT_ID(N'dbo.TaiKhoan'))
    CREATE UNIQUE INDEX UX_TaiKhoan_MaNV ON dbo.TaiKhoan(MaNV) WHERE MaNV IS NOT NULL;
GO

IF OBJECT_ID(N'dbo.TaiKhoanVaiTro', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.TaiKhoanVaiTro (
        TaiKhoanId INT NOT NULL,
        MaVaiTro   VARCHAR(30) NOT NULL,
        CONSTRAINT PK_TaiKhoanVaiTro PRIMARY KEY (TaiKhoanId),
        CONSTRAINT FK_TKVT_TaiKhoan FOREIGN KEY (TaiKhoanId) REFERENCES dbo.TaiKhoan(TaiKhoanId) ON DELETE CASCADE,
        CONSTRAINT FK_TKVT_VaiTro FOREIGN KEY (MaVaiTro) REFERENCES dbo.VaiTro(MaVaiTro) ON DELETE NO ACTION
    );
END
GO

IF OBJECT_ID(N'dbo.VaiTroQuyen', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.VaiTroQuyen (
        MaVaiTro VARCHAR(30) NOT NULL,
        MaQuyen  VARCHAR(80) NOT NULL,
        CONSTRAINT PK_VaiTroQuyen PRIMARY KEY (MaVaiTro, MaQuyen),
        CONSTRAINT FK_VTQ_VaiTro FOREIGN KEY (MaVaiTro) REFERENCES dbo.VaiTro(MaVaiTro) ON DELETE CASCADE,
        CONSTRAINT FK_VTQ_Quyen FOREIGN KEY (MaQuyen) REFERENCES dbo.Quyen(MaQuyen) ON DELETE NO ACTION
    );
END
GO

/* ===== Vai trò mặc định ===== */
INSERT dbo.VaiTro(MaVaiTro, TenVaiTro, MoTa)
SELECT v.MaVaiTro, v.TenVaiTro, v.MoTa
FROM (VALUES
    ('ADMIN',    N'Quản trị viên', N'Toàn quyền hệ thống, quản lý tài khoản và phân quyền.'),
    ('QUANLY',   N'Quản lý',      N'Điều hành nghiệp vụ; quyền chi tiết có thể chỉnh bởi Admin.'),
    ('THUNGAN',  N'Thu ngân',     N'Lập hóa đơn và tra cứu thông tin phục vụ bán hàng.'),
    ('KHO',      N'Kho',          N'Quản lý sản phẩm, nhà cung cấp và nhập hàng.')
) v(MaVaiTro, TenVaiTro, MoTa)
WHERE NOT EXISTS (SELECT 1 FROM dbo.VaiTro x WHERE x.MaVaiTro = v.MaVaiTro);
GO

/* ===== Danh sách quyền ===== */
INSERT dbo.Quyen(MaQuyen, TenQuyen, NhomQuyen, MoTa)
SELECT p.MaQuyen, p.TenQuyen, p.NhomQuyen, p.MoTa
FROM (VALUES
    ('dashboard.view', N'Xem tổng quan', N'Hệ thống', N'Mở trang tổng quan.'),
    ('products.view', N'Xem sản phẩm', N'Sản phẩm', N'Xem danh sách và chi tiết sản phẩm.'),
    ('products.create', N'Thêm sản phẩm', N'Sản phẩm', N'Tạo sản phẩm mới.'),
    ('products.edit', N'Sửa sản phẩm', N'Sản phẩm', N'Chỉnh sửa sản phẩm.'),
    ('products.delete', N'Xóa sản phẩm', N'Sản phẩm', N'Xóa sản phẩm.'),
    ('categories.view', N'Xem loại sản phẩm', N'Loại sản phẩm', N'Xem nhóm sản phẩm.'),
    ('categories.create', N'Thêm loại sản phẩm', N'Loại sản phẩm', N'Tạo loại sản phẩm mới.'),
    ('categories.edit', N'Sửa loại sản phẩm', N'Loại sản phẩm', N'Chỉnh sửa loại sản phẩm.'),
    ('categories.delete', N'Xóa loại sản phẩm', N'Loại sản phẩm', N'Xóa loại sản phẩm.'),
    ('customers.view', N'Xem khách hàng', N'Khách hàng', N'Xem hồ sơ khách hàng.'),
    ('customers.create', N'Thêm khách hàng', N'Khách hàng', N'Tạo khách hàng mới.'),
    ('customers.edit', N'Sửa khách hàng', N'Khách hàng', N'Chỉnh sửa khách hàng.'),
    ('customers.delete', N'Xóa khách hàng', N'Khách hàng', N'Xóa khách hàng.'),
    ('employees.view', N'Xem nhân viên', N'Nhân viên', N'Xem hồ sơ nhân viên.'),
    ('employees.create', N'Thêm nhân viên', N'Nhân viên', N'Tạo nhân viên mới.'),
    ('employees.edit', N'Sửa nhân viên', N'Nhân viên', N'Chỉnh sửa nhân viên.'),
    ('employees.delete', N'Xóa nhân viên', N'Nhân viên', N'Xóa nhân viên.'),
    ('suppliers.view', N'Xem nhà cung cấp', N'Nhà cung cấp', N'Xem thông tin NCC.'),
    ('suppliers.create', N'Thêm nhà cung cấp', N'Nhà cung cấp', N'Tạo NCC mới.'),
    ('suppliers.edit', N'Sửa nhà cung cấp', N'Nhà cung cấp', N'Chỉnh sửa NCC.'),
    ('suppliers.delete', N'Xóa nhà cung cấp', N'Nhà cung cấp', N'Xóa NCC.'),
    ('invoices.view', N'Xem hóa đơn', N'Hóa đơn', N'Tra cứu hóa đơn.'),
    ('invoices.create', N'Lập hóa đơn', N'Hóa đơn', N'Tạo hóa đơn bán.'),
    ('invoices.cancel', N'Hủy hóa đơn', N'Hóa đơn', N'Hủy hóa đơn sai.'),
    ('purchases.view', N'Xem phiếu nhập', N'Nhập hàng', N'Tra cứu phiếu nhập.'),
    ('purchases.create', N'Tạo phiếu nhập', N'Nhập hàng', N'Tạo phiếu nhập hàng.'),
    ('reports.view', N'Xem báo cáo', N'Báo cáo', N'Xem và lọc báo cáo kinh doanh.'),
    ('accounts.manage', N'Quản lý tài khoản', N'Phân quyền', N'Duyệt, khóa, mở khóa, gán vai trò và đặt lại mật khẩu.'),
    ('roles.manage', N'Quản lý phân quyền', N'Phân quyền', N'Tạo vai trò và bật/tắt quyền cho vai trò.')
) p(MaQuyen, TenQuyen, NhomQuyen, MoTa)
WHERE NOT EXISTS (SELECT 1 FROM dbo.Quyen q WHERE q.MaQuyen = p.MaQuyen);
GO

/* ===== Quyền mặc định theo vai trò ===== */
-- ADMIN: toàn bộ quyền
INSERT dbo.VaiTroQuyen(MaVaiTro, MaQuyen)
SELECT 'ADMIN', q.MaQuyen
FROM dbo.Quyen q
WHERE NOT EXISTS (SELECT 1 FROM dbo.VaiTroQuyen x WHERE x.MaVaiTro='ADMIN' AND x.MaQuyen=q.MaQuyen);
GO

-- QUANLY: toàn bộ nghiệp vụ, không đụng phần phân quyền.
INSERT dbo.VaiTroQuyen(MaVaiTro, MaQuyen)
SELECT 'QUANLY', q.MaQuyen
FROM dbo.Quyen q
WHERE q.MaQuyen NOT IN ('accounts.manage', 'roles.manage')
  AND NOT EXISTS (SELECT 1 FROM dbo.VaiTroQuyen x WHERE x.MaVaiTro='QUANLY' AND x.MaQuyen=q.MaQuyen);
GO

-- THUNGAN
INSERT dbo.VaiTroQuyen(MaVaiTro, MaQuyen)
SELECT 'THUNGAN', q.MaQuyen
FROM dbo.Quyen q
WHERE q.MaQuyen IN ('dashboard.view','products.view','customers.view','customers.create','customers.edit','invoices.view','invoices.create')
  AND NOT EXISTS (SELECT 1 FROM dbo.VaiTroQuyen x WHERE x.MaVaiTro='THUNGAN' AND x.MaQuyen=q.MaQuyen);
GO

-- KHO
INSERT dbo.VaiTroQuyen(MaVaiTro, MaQuyen)
SELECT 'KHO', q.MaQuyen
FROM dbo.Quyen q
WHERE q.MaQuyen IN ('dashboard.view','products.view','products.create','products.edit','categories.view','suppliers.view','suppliers.create','suppliers.edit','purchases.view','purchases.create','reports.view')
  AND NOT EXISTS (SELECT 1 FROM dbo.VaiTroQuyen x WHERE x.MaVaiTro='KHO' AND x.MaQuyen=q.MaQuyen);
GO

/* ===== Tài khoản ADMIN ban đầu =====
   Username: admin
   Password: Admin@123456
   Đây là tài khoản hệ thống, chưa gắn MaNV. Hãy đổi mật khẩu sau lần đăng nhập đầu.
*/
IF NOT EXISTS (SELECT 1 FROM dbo.TaiKhoan WHERE TenDangNhap='admin')
BEGIN
    INSERT dbo.TaiKhoan(TenDangNhap, MatKhauHash, MaNV, TrangThai)
    VALUES (
        'admin',
        'scrypt$16384$8$1$3b11282a074af460abc9b1f045636f64$ad7510cc0adc63ee352429eb405cf08654efc523c3f556d93304afe1917ff63b82f976c98cabb718411b44d75d37fadab7338618ef59a9a9d480199fd634af89',
        NULL,
        'HOAT_DONG'
    );
END
GO

IF NOT EXISTS (
    SELECT 1 FROM dbo.TaiKhoanVaiTro tv
    INNER JOIN dbo.TaiKhoan tk ON tk.TaiKhoanId=tv.TaiKhoanId
    WHERE tk.TenDangNhap='admin'
)
BEGIN
    INSERT dbo.TaiKhoanVaiTro(TaiKhoanId, MaVaiTro)
    SELECT TaiKhoanId, 'ADMIN' FROM dbo.TaiKhoan WHERE TenDangNhap='admin';
END
GO

PRINT N'Đã bổ sung hệ thống đăng nhập nội bộ và phân quyền TechMart. Tài khoản chỉ do Admin tạo.';
PRINT N'Tài khoản quản trị ban đầu: admin / Admin@123456';
GO
