/*
   07_Luong_DangKy_NhanVien.sql - ĐÃ NGỪNG SỬ DỤNG.
   TechMart không còn nhận đăng ký tài khoản nhân viên công khai.
   Admin tạo hồ sơ trong dbo.NhanVien, sau đó tạo tài khoản tại /admin/accounts/new.
   Migration này được giữ lại để tránh thiếu tệp trong các bộ dự án cũ; không thay đổi dữ liệu.
*/
USE QLBanHang;
GO
PRINT N'Luồng đăng ký công khai đã bị vô hiệu hóa. Không có thao tác SQL nào được thực hiện.';
GO
