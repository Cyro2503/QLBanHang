/* =====================================================================
   08_Auth_External_Recovery.sql
   Bổ sung liên kết Google/Facebook và khôi phục mật khẩu qua Email/SMS.

   Chạy trên QLBanHang SAU 06_PhanQuyen_DangNhap.sql.
   Migration chỉ tạo bảng mới, không xóa/sửa dữ liệu nghiệp vụ hiện tại.
   Không tạo tài khoản nhân viên và không mở chức năng đăng ký công khai.
   ===================================================================== */
USE QLBanHang;
GO

IF OBJECT_ID(N'dbo.TaiKhoanLienKet', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.TaiKhoanLienKet (
        LienKetId INT IDENTITY(1,1) NOT NULL,
        TaiKhoanId INT NOT NULL,
        Provider VARCHAR(20) NOT NULL,
        ProviderUserId NVARCHAR(191) NOT NULL,
        ProviderEmail NVARCHAR(254) NULL,
        NgayLienKet DATETIME2(0) NOT NULL CONSTRAINT DF_TaiKhoanLienKet_Ngay DEFAULT (SYSDATETIME()),
        CONSTRAINT PK_TaiKhoanLienKet PRIMARY KEY (LienKetId),
        CONSTRAINT FK_TaiKhoanLienKet_TaiKhoan FOREIGN KEY (TaiKhoanId) REFERENCES dbo.TaiKhoan(TaiKhoanId) ON DELETE CASCADE,
        CONSTRAINT CK_TaiKhoanLienKet_Provider CHECK (Provider IN ('GOOGLE','FACEBOOK'))
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name=N'UX_TaiKhoanLienKet_ProviderUser' AND object_id=OBJECT_ID(N'dbo.TaiKhoanLienKet'))
    CREATE UNIQUE INDEX UX_TaiKhoanLienKet_ProviderUser ON dbo.TaiKhoanLienKet(Provider,ProviderUserId);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name=N'UX_TaiKhoanLienKet_AccountProvider' AND object_id=OBJECT_ID(N'dbo.TaiKhoanLienKet'))
    CREATE UNIQUE INDEX UX_TaiKhoanLienKet_AccountProvider ON dbo.TaiKhoanLienKet(TaiKhoanId,Provider);
GO

IF OBJECT_ID(N'dbo.ThongTinKhoiPhucTaiKhoan', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ThongTinKhoiPhucTaiKhoan (
        TaiKhoanId INT NOT NULL,
        Email NVARCHAR(254) NULL,
        EmailXacMinhLuc DATETIME2(0) NULL,
        SoDienThoai VARCHAR(20) NULL,
        SDTXacMinhLuc DATETIME2(0) NULL,
        CapNhatLuc DATETIME2(0) NOT NULL CONSTRAINT DF_ThongTinKhoiPhuc_CapNhat DEFAULT (SYSDATETIME()),
        CONSTRAINT PK_ThongTinKhoiPhucTaiKhoan PRIMARY KEY (TaiKhoanId),
        CONSTRAINT FK_ThongTinKhoiPhuc_TaiKhoan FOREIGN KEY (TaiKhoanId) REFERENCES dbo.TaiKhoan(TaiKhoanId) ON DELETE CASCADE
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name=N'UX_ThongTinKhoiPhuc_Email' AND object_id=OBJECT_ID(N'dbo.ThongTinKhoiPhucTaiKhoan'))
    CREATE UNIQUE INDEX UX_ThongTinKhoiPhuc_Email ON dbo.ThongTinKhoiPhucTaiKhoan(Email) WHERE Email IS NOT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name=N'UX_ThongTinKhoiPhuc_SDT' AND object_id=OBJECT_ID(N'dbo.ThongTinKhoiPhucTaiKhoan'))
    CREATE UNIQUE INDEX UX_ThongTinKhoiPhuc_SDT ON dbo.ThongTinKhoiPhucTaiKhoan(SoDienThoai) WHERE SoDienThoai IS NOT NULL;
GO

IF OBJECT_ID(N'dbo.MaXacMinhTaiKhoan', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.MaXacMinhTaiKhoan (
        OtpId BIGINT IDENTITY(1,1) NOT NULL,
        TaiKhoanId INT NOT NULL,
        MucDich VARCHAR(20) NOT NULL,
        Kenh VARCHAR(10) NOT NULL,
        DoiTuongHash CHAR(64) NOT NULL,
        MaHash CHAR(64) NOT NULL,
        TaoLuc DATETIME2(0) NOT NULL CONSTRAINT DF_MaXacMinh_Tao DEFAULT (SYSDATETIME()),
        HetHanLuc DATETIME2(0) NOT NULL,
        SoLanSai TINYINT NOT NULL CONSTRAINT DF_MaXacMinh_Sai DEFAULT (0),
        DaSuDungLuc DATETIME2(0) NULL,
        IpHash CHAR(64) NULL,
        CONSTRAINT PK_MaXacMinhTaiKhoan PRIMARY KEY (OtpId),
        CONSTRAINT FK_MaXacMinh_TaiKhoan FOREIGN KEY (TaiKhoanId) REFERENCES dbo.TaiKhoan(TaiKhoanId) ON DELETE CASCADE,
        CONSTRAINT CK_MaXacMinh_MucDich CHECK (MucDich IN ('VERIFY_EMAIL','VERIFY_PHONE','RESET_PASSWORD')),
        CONSTRAINT CK_MaXacMinh_Kenh CHECK (Kenh IN ('EMAIL','SMS')),
        CONSTRAINT CK_MaXacMinh_SoLanSai CHECK (SoLanSai BETWEEN 0 AND 5)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name=N'IX_MaXacMinh_AccountPurposeTime' AND object_id=OBJECT_ID(N'dbo.MaXacMinhTaiKhoan'))
    CREATE INDEX IX_MaXacMinh_AccountPurposeTime
    ON dbo.MaXacMinhTaiKhoan(TaiKhoanId,MucDich,Kenh,TaoLuc DESC)
    INCLUDE (DoiTuongHash,HetHanLuc,SoLanSai,DaSuDungLuc);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name=N'IX_MaXacMinh_IpTime' AND object_id=OBJECT_ID(N'dbo.MaXacMinhTaiKhoan'))
    CREATE INDEX IX_MaXacMinh_IpTime ON dbo.MaXacMinhTaiKhoan(IpHash,TaoLuc DESC);
GO

PRINT N'Đã tạo bảng liên kết OAuth và khôi phục mật khẩu TechMart.';
PRINT N'Đặt OTP_HASH_SECRET và OAUTH_STATE_SECRET đủ dài trong .env trước khi bật dịch vụ.';
PRINT N'Gmail cần SMTP App Password hoặc SMTP relay; SMS cần tài khoản SMS Gateway/Twilio.';
GO
