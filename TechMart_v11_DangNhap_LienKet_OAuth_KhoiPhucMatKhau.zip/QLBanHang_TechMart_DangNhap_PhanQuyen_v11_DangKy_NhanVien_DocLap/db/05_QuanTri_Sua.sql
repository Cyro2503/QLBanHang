﻿/* =====================================================================
   05_QuanTri_Sua.sql - Phân quyền, sao lưu và phục hồi CSDL QLBanHang (SQL Server)
   Chạy SAU 01_TaoBang_Sua.sql và 04_LapTrinh_Sua.sql, bằng tài khoản sa / sysadmin.
   Nếu đặt tên database khác (vd. QLBanHang_<MãNhóm>) thì đổi USE bên dưới
   và đổi biến @Db trong PHẦN 4 (sao lưu) cho khớp.

   PHẦN 1  Schema và view báo cáo doanh thu (cho vai trò KeToan)
   PHẦN 2  Login, user, role
   PHẦN 3  GRANT / DENY / REVOKE theo từng vai trò
   PHẦN 4  Sao lưu Full / Differential / Transaction Log
   PHẦN 5  Phục hồi về thời điểm trước sự cố (point-in-time restore)
   PHẦN 6  Lịch sao lưu đề xuất và SQL Server Agent Job tự động hằng ngày
   ===================================================================== */

USE QLBanHang;
GO

/* =====================================================================
   PHẦN 1 - SCHEMA bc VÀ VIEW BÁO CÁO DOANH THU
   Đặt view báo cáo trong schema riêng để cấp quyền cho KeToan theo cả schema,
   đồng thời chặn toàn bộ schema dbo (bảng gốc) mà không bị xung đột GRANT/DENY.
   Doanh thu chỉ tính hóa đơn BÁN đã thanh toán.
   ===================================================================== */
IF SCHEMA_ID(N'bc') IS NULL
    EXEC (N'CREATE SCHEMA bc AUTHORIZATION dbo');
GO

CREATE OR ALTER VIEW bc.vw_DoanhThuTheoNgay
AS
SELECT CAST(hd.NgayLap AS DATE) AS Ngay,
       COUNT(DISTINCT hd.SoHD)  AS SoHoaDon,
       SUM(ct.SoLuong)          AS SoLuongBan,
       SUM(ct.SoLuong * ct.DonGiaBan * (1 - ct.PhanTramGiam / 100.0)) AS DoanhThu
FROM dbo.HoaDon hd
JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = hd.SoHD
WHERE hd.TrangThai = N'Đã thanh toán'
GROUP BY CAST(hd.NgayLap AS DATE);
GO

CREATE OR ALTER VIEW bc.vw_DoanhThuTheoThang
AS
SELECT YEAR(hd.NgayLap)  AS Nam,
       MONTH(hd.NgayLap) AS Thang,
       COUNT(DISTINCT hd.SoHD) AS SoHoaDon,
       SUM(ct.SoLuong)         AS SoLuongBan,
       SUM(ct.SoLuong * ct.DonGiaBan * (1 - ct.PhanTramGiam / 100.0)) AS DoanhThu
FROM dbo.HoaDon hd
JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = hd.SoHD
WHERE hd.TrangThai = N'Đã thanh toán'
GROUP BY YEAR(hd.NgayLap), MONTH(hd.NgayLap);
GO

CREATE OR ALTER VIEW bc.vw_DoanhThuTheoSanPham
AS
SELECT sp.MaSP,
       sp.TenSP,
       SUM(ct.SoLuong) AS SoLuongBan,
       SUM(ct.SoLuong * ct.DonGiaBan * (1 - ct.PhanTramGiam / 100.0)) AS DoanhThu
FROM dbo.HoaDon hd
JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = hd.SoHD
JOIN dbo.SanPham sp       ON sp.MaSP = ct.MaSP
WHERE hd.TrangThai = N'Đã thanh toán'
GROUP BY sp.MaSP, sp.TenSP;
GO

/* =====================================================================
   PHẦN 2 - LOGIN, USER, ROLE
   4 vai trò: QuanLy, ThuNgan, ThuKho, KeToan; mỗi vai trò một tài khoản mẫu.
   !!! Mật khẩu bên dưới chỉ là mẫu để làm bài. Đổi ngay nếu dùng thật. !!!
   ===================================================================== */

-- Login (mức server)
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'lg_quanly')
    CREATE LOGIN lg_quanly  WITH PASSWORD = N'QuanLy@QLBanHang#2026',  CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'lg_thungan')
    CREATE LOGIN lg_thungan WITH PASSWORD = N'ThuNgan@QLBanHang#2026', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'lg_thukho')
    CREATE LOGIN lg_thukho  WITH PASSWORD = N'ThuKho@QLBanHang#2026',  CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'lg_ketoan')
    CREATE LOGIN lg_ketoan  WITH PASSWORD = N'KeToan@QLBanHang#2026',  CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
GO

-- User (mức database) gắn với login
IF DATABASE_PRINCIPAL_ID(N'u_quanly')  IS NULL CREATE USER u_quanly  FOR LOGIN lg_quanly;
IF DATABASE_PRINCIPAL_ID(N'u_thungan') IS NULL CREATE USER u_thungan FOR LOGIN lg_thungan;
IF DATABASE_PRINCIPAL_ID(N'u_thukho')  IS NULL CREATE USER u_thukho  FOR LOGIN lg_thukho;
IF DATABASE_PRINCIPAL_ID(N'u_ketoan')  IS NULL CREATE USER u_ketoan  FOR LOGIN lg_ketoan;
GO

-- Role (mức database)
IF DATABASE_PRINCIPAL_ID(N'QuanLy')  IS NULL CREATE ROLE QuanLy;
IF DATABASE_PRINCIPAL_ID(N'ThuNgan') IS NULL CREATE ROLE ThuNgan;
IF DATABASE_PRINCIPAL_ID(N'ThuKho')  IS NULL CREATE ROLE ThuKho;
IF DATABASE_PRINCIPAL_ID(N'KeToan')  IS NULL CREATE ROLE KeToan;
GO

-- Gán user vào role
IF IS_ROLEMEMBER(N'QuanLy',  N'u_quanly')  = 0 ALTER ROLE QuanLy  ADD MEMBER u_quanly;
IF IS_ROLEMEMBER(N'ThuNgan', N'u_thungan') = 0 ALTER ROLE ThuNgan ADD MEMBER u_thungan;
IF IS_ROLEMEMBER(N'ThuKho',  N'u_thukho')  = 0 ALTER ROLE ThuKho  ADD MEMBER u_thukho;
IF IS_ROLEMEMBER(N'KeToan',  N'u_ketoan')  = 0 ALTER ROLE KeToan  ADD MEMBER u_ketoan;
GO

/* =====================================================================
   PHẦN 3 - GRANT / DENY / REVOKE
   Nguyên tắc: cấp tối thiểu (least privilege). Hóa đơn, khách hàng, phiếu nhập... được ghi
   qua stored procedure hoặc theo đúng quyền INSERT được cấp; các trigger và stored procedure
   cùng chủ sở hữu (dbo) nên chạy được nhờ ownership chaining mà không cần cấp quyền trực tiếp
   lên bảng mà trigger/procedure đụng tới (SanPham, ChiTietHoaDon...).
   ===================================================================== */

-- 3.0 REVOKE: gỡ quyền cấp ở mức schema (cả GRANT lẫn DENY) để chạy lại script luôn sạch
REVOKE SELECT, INSERT, UPDATE, DELETE, EXECUTE ON SCHEMA::dbo FROM ThuNgan, ThuKho, KeToan;
REVOKE SELECT ON SCHEMA::bc FROM ThuNgan, ThuKho, KeToan;
GO

-- 3.1 QuanLy: toàn quyền trên CSDL
IF IS_ROLEMEMBER(N'db_owner', N'QuanLy') = 0
    ALTER ROLE db_owner ADD MEMBER QuanLy;
GO

-- 3.2 ThuNgan: xem sản phẩm, khách hàng; thực thi sp_LapHoaDon, sp_ThemKhachHang;
--              không sửa trực tiếp bảng
GRANT SELECT ON dbo.SanPham     TO ThuNgan;
GRANT SELECT ON dbo.LoaiSanPham TO ThuNgan;
GRANT SELECT ON dbo.KhachHang   TO ThuNgan;

DENY INSERT, UPDATE, DELETE ON SCHEMA::dbo TO ThuNgan;   -- không ghi trực tiếp vào bảng nào
DENY SELECT ON dbo.NhanVien TO ThuNgan;                  -- không xem lương nhân viên

-- Hai stored procedure này sẽ được viết ở bước sau; nếu chưa có thì chạy lại khối này sau khi tạo
IF OBJECT_ID(N'dbo.sp_LapHoaDon', N'P') IS NOT NULL
    GRANT EXECUTE ON dbo.sp_LapHoaDon TO ThuNgan;
ELSE
    PRINT N'Chưa có dbo.sp_LapHoaDon: hãy tạo thủ tục rồi chạy lại để cấp EXECUTE cho ThuNgan.';

IF OBJECT_ID(N'dbo.sp_ThemKhachHang', N'P') IS NOT NULL
    GRANT EXECUTE ON dbo.sp_ThemKhachHang TO ThuNgan;
ELSE
    PRINT N'Chưa có dbo.sp_ThemKhachHang: hãy tạo thủ tục rồi chạy lại để cấp EXECUTE cho ThuNgan.';
GO

-- 3.3 ThuKho: xem và thêm phiếu nhập; xem sản phẩm; không xem lương nhân viên
GRANT SELECT ON dbo.SanPham                TO ThuKho;
GRANT SELECT ON dbo.LoaiSanPham            TO ThuKho;
GRANT SELECT ON dbo.NhaCungCap             TO ThuKho;
GRANT SELECT ON dbo.PhieuNhap              TO ThuKho;
GRANT SELECT ON dbo.ChiTietPhieuNhap       TO ThuKho;

-- Được xem thông tin nhân viên nhưng không xem cột lương
GRANT SELECT ON dbo.NhanVien (MaNV, HoTen, NgaySinh, GioiTinh, ChucVu, NgayVaoLam) TO ThuKho;
DENY  SELECT ON dbo.NhanVien (LuongCoBan) TO ThuKho;

-- Thêm phiếu nhập
GRANT INSERT ON dbo.PhieuNhap              TO ThuKho;
GRANT INSERT ON dbo.ChiTietPhieuNhap       TO ThuKho;

-- Không sửa / xóa dữ liệu nào; không thêm vào các bảng ngoài phiếu nhập
DENY UPDATE, DELETE ON SCHEMA::dbo TO ThuKho;
DENY INSERT ON dbo.HoaDon       TO ThuKho;
DENY INSERT ON dbo.ChiTietHoaDon TO ThuKho;
DENY INSERT ON dbo.KhachHang    TO ThuKho;
DENY INSERT ON dbo.SanPham      TO ThuKho;
DENY INSERT ON dbo.LoaiSanPham  TO ThuKho;
DENY INSERT ON dbo.NhaCungCap   TO ThuKho;
DENY INSERT ON dbo.NhanVien     TO ThuKho;
GO

-- 3.4 KeToan: chỉ xem các view báo cáo doanh thu
GRANT SELECT ON SCHEMA::bc TO KeToan;
DENY SELECT, INSERT, UPDATE, DELETE, EXECUTE ON SCHEMA::dbo TO KeToan;   -- không đụng tới bảng gốc
GO

-- 3.5 Xem lại toàn bộ quyền đã cấp / chặn của 4 vai trò
SELECT pr.name AS VaiTro,
       pe.state_desc AS TrangThai,
       pe.permission_name AS Quyen,
       pe.class_desc AS LoaiDoiTuong,
       CASE pe.class
            WHEN 1 THEN OBJECT_SCHEMA_NAME(pe.major_id) + N'.' + OBJECT_NAME(pe.major_id)
            WHEN 3 THEN N'SCHEMA ' + SCHEMA_NAME(pe.major_id)
            ELSE N'DATABASE'
       END AS DoiTuong,
       CASE WHEN pe.class = 1 AND pe.minor_id > 0
            THEN COL_NAME(pe.major_id, pe.minor_id) END AS Cot
FROM sys.database_permissions pe
JOIN sys.database_principals pr ON pr.principal_id = pe.grantee_principal_id
WHERE pr.name IN (N'ThuNgan', N'ThuKho', N'KeToan')
ORDER BY pr.name, DoiTuong, pe.permission_name;
GO

/* ---------------------------------------------------------------------
   3.6 KIỂM THỬ PHÂN QUYỀN (chạy thủ công từng khối, chụp màn hình kết quả)
   Cách 1: đăng nhập SSMS bằng lg_thungan / lg_thukho / lg_ketoan rồi chạy lệnh.
   Cách 2: ngay trong cửa sổ này dùng EXECUTE AS USER ... REVERT như dưới.

   -- ThuNgan: được xem sản phẩm, bị chặn khi sửa trực tiếp
   EXECUTE AS USER = N'u_thungan';
       SELECT TOP (5) * FROM dbo.SanPham;                 -- được phép
       UPDATE dbo.SanPham SET GiaBan = GiaBan;            -- bị chặn (lỗi 229)
       SELECT * FROM dbo.NhanVien;                        -- bị chặn
   REVERT;

   -- ThuKho: được xem sản phẩm và cột không phải lương, bị chặn xem lương
   EXECUTE AS USER = N'u_thukho';
       SELECT MaNV, HoTen, ChucVu FROM dbo.NhanVien;      -- được phép
       SELECT LuongCoBan FROM dbo.NhanVien;               -- bị chặn
       DELETE FROM dbo.PhieuNhap;                         -- bị chặn
   REVERT;

   -- KeToan: chỉ xem view báo cáo
   EXECUTE AS USER = N'u_ketoan';
       SELECT * FROM bc.vw_DoanhThuTheoThang;             -- được phép
       SELECT * FROM dbo.HoaDon;                          -- bị chặn
   REVERT;
   --------------------------------------------------------------------- */

/* =====================================================================
   PHẦN 4 - SAO LƯU: FULL, DIFFERENTIAL, TRANSACTION LOG
   - Cần recovery model FULL thì mới sao lưu được log và phục hồi theo thời điểm.
   - Thư mục sao lưu: sửa @Dir cho phù hợp. Thư mục được tạo tự động nếu chưa có.
   - Thứ tự bắt buộc: Full trước, rồi Differential, rồi Log (log cần có Full làm gốc).
   ===================================================================== */

-- 4.0 Bật recovery model FULL và tạo thư mục
DECLARE @Db SYSNAME = DB_NAME();
DECLARE @Dir NVARCHAR(260) = N'C:\Backup\QLBanHang\';
DECLARE @sql NVARCHAR(MAX) = N'ALTER DATABASE ' + QUOTENAME(@Db) + N' SET RECOVERY FULL;';
EXEC (@sql);
EXEC master.sys.xp_create_subdir @Dir;
SELECT name AS CSDL, recovery_model_desc AS MoHinhPhucHoi FROM sys.databases WHERE name = @Db;
GO

-- 4.1 Full backup
DECLARE @Db SYSNAME = DB_NAME();
DECLARE @Dir NVARCHAR(260) = N'C:\Backup\QLBanHang\';
DECLARE @File NVARCHAR(400) = @Dir + @Db + N'_FULL_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + N'.bak';
BACKUP DATABASE @Db TO DISK = @File WITH CHECKSUM, STATS = 10;
RESTORE VERIFYONLY FROM DISK = @File WITH CHECKSUM;   -- kiểm tra file sao lưu đọc được
PRINT N'Đã sao lưu Full: ' + @File;
GO

-- 4.2 Differential backup (chỉ lưu phần thay đổi kể từ lần Full gần nhất)
DECLARE @Db SYSNAME = DB_NAME();
DECLARE @Dir NVARCHAR(260) = N'C:\Backup\QLBanHang\';
DECLARE @File NVARCHAR(400) = @Dir + @Db + N'_DIFF_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + N'.bak';
BACKUP DATABASE @Db TO DISK = @File WITH DIFFERENTIAL, CHECKSUM, STATS = 10;
RESTORE VERIFYONLY FROM DISK = @File WITH CHECKSUM;
PRINT N'Đã sao lưu Differential: ' + @File;
GO

-- 4.3 Transaction Log backup (cho phép phục hồi đến từng thời điểm)
DECLARE @Db SYSNAME = DB_NAME();
DECLARE @Dir NVARCHAR(260) = N'C:\Backup\QLBanHang\';
DECLARE @File NVARCHAR(400) = @Dir + @Db + N'_LOG_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + N'.trn';
BACKUP LOG @Db TO DISK = @File WITH CHECKSUM, STATS = 10;
RESTORE VERIFYONLY FROM DISK = @File WITH CHECKSUM;
PRINT N'Đã sao lưu Log: ' + @File;
GO

-- 4.4 Xem lịch sử sao lưu của database hiện tại
SELECT TOP (20)
       bs.database_name AS CSDL,
       CASE bs.type WHEN 'D' THEN N'Full' WHEN 'I' THEN N'Differential' WHEN 'L' THEN N'Log' END AS Loai,
       bs.backup_start_date AS BatDau,
       bs.backup_finish_date AS KetThuc,
       CAST(bs.backup_size / 1048576.0 AS DECIMAL(18,2)) AS DungLuongMB,
       bmf.physical_device_name AS Tep
FROM msdb.dbo.backupset bs
JOIN msdb.dbo.backupmediafamily bmf ON bmf.media_set_id = bs.media_set_id
WHERE bs.database_name = DB_NAME()
ORDER BY bs.backup_finish_date DESC;
GO

/* =====================================================================
   PHẦN 5 - PHỤC HỒI VỀ THỜI ĐIỂM TRƯỚC SỰ CỐ (POINT-IN-TIME RESTORE)
   Kịch bản: lỡ xóa nhầm một bảng. Cách an toàn là phục hồi sang một database MỚI
   (QLBanHang_Restore) về đúng thời điểm trước sự cố, rồi chép dữ liệu bảng bị mất về
   database gốc, không ghi đè lên database đang chạy.
   Các lệnh dưới đây được để dạng chú thích; bỏ chú thích và sửa tên tệp, giờ cho đúng.

   -- B1. Chạy 4.1 (Full), 4.2 (Diff), 4.3 (Log) trước. Ghi lại giờ trước khi xảy ra sự cố:
   SELECT GETDATE() AS ThoiDiemTruocSuCo;                  -- vd. 2026-10-06 15:30:00

   -- B2. Mô phỏng sự cố: xóa nhầm bảng ChiTietHoaDon.
   -- Chỉ thực hiện sau khi đã có Full/Diff/Log backup và hiểu rõ hậu quả.
   DROP TABLE dbo.ChiTietHoaDon;

   -- B3. Sao lưu phần log còn lại tới thời điểm hiện tại (để có đủ log cho STOPAT)
   BACKUP LOG QLBanHang TO DISK = N'C:\Backup\QLBanHang\QLBanHang_LOG_CUOI.trn' WITH CHECKSUM;

   -- B4. Xem tên logical của tệp dữ liệu và log trong bản Full (dùng cho MOVE)
   RESTORE FILELISTONLY FROM DISK = N'C:\Backup\QLBanHang\QLBanHang_FULL_xxxxxxxx_xxxxxx.bak';

   -- B5. Phục hồi sang database mới theo thứ tự Full -> Diff -> Log, dừng đúng giờ
   RESTORE DATABASE QLBanHang_Restore
       FROM DISK = N'C:\Backup\QLBanHang\QLBanHang_FULL_xxxxxxxx_xxxxxx.bak'
       WITH MOVE N'QLBanHang'     TO N'C:\Backup\QLBanHang\QLBanHang_Restore.mdf',
            MOVE N'QLBanHang_log' TO N'C:\Backup\QLBanHang\QLBanHang_Restore.ldf',
            NORECOVERY;
   RESTORE DATABASE QLBanHang_Restore
       FROM DISK = N'C:\Backup\QLBanHang\QLBanHang_DIFF_xxxxxxxx_xxxxxx.bak'
       WITH NORECOVERY;
   RESTORE LOG QLBanHang_Restore
       FROM DISK = N'C:\Backup\QLBanHang\QLBanHang_LOG_xxxxxxxx_xxxxxx.trn'
       WITH NORECOVERY;
   RESTORE LOG QLBanHang_Restore
       FROM DISK = N'C:\Backup\QLBanHang\QLBanHang_LOG_CUOI.trn'
       WITH STOPAT = N'2026-10-06 15:30:00', RECOVERY;      -- giờ ngay trước sự cố

   -- B6. Kiểm tra dữ liệu bảng đã mất còn trong bản phục hồi
   SELECT COUNT(*) FROM QLBanHang_Restore.dbo.ChiTietHoaDon;

   -- B7. Tạo lại bảng ChiTietHoaDon ở database gốc bằng script 01_TaoBang_Sua.sql,
   --     rồi chép dữ liệu từ bản phục hồi về.
   INSERT INTO dbo.ChiTietHoaDon (SoHD, MaSP, SoLuong, DonGiaBan, PhanTramGiam)
   SELECT SoHD, MaSP, SoLuong, DonGiaBan, PhanTramGiam
   FROM QLBanHang_Restore.dbo.ChiTietHoaDon;

   -- B8. Dọn dẹp khi xong
   DROP DATABASE QLBanHang_Restore;

   Ghi chú: nếu cần phục hồi đè lên chính database gốc (mất hẳn database) thì dùng cùng chuỗi
   RESTORE nhưng với tên database gốc, thêm WITH REPLACE ở lệnh đầu, sau khi đã sao lưu log cuối
   bằng BACKUP LOG ... WITH NORECOVERY (tail-log backup).
   ===================================================================== */

/* =====================================================================
   PHẦN 6 - LỊCH SAO LƯU ĐỀ XUẤT CHO CỬA HÀNG VÀ SQL SERVER AGENT JOB

   Đề xuất cho cửa hàng bán lẻ (mở cửa ban ngày, dữ liệu phát sinh liên tục):
     Loại            Tần suất                     Lý do
     Full            Chủ nhật 23:00 (hằng tuần)   Mốc gốc; ngày nghỉ ít giao dịch nên ít ảnh hưởng
     Differential    23:00 các ngày còn lại       Nhỏ, nhanh; phục hồi chỉ cần Full + 1 Diff + Log
     Transaction Log Mỗi 60 phút (08:00-22:59)    Mất tối đa 1 giờ giao dịch khi có sự cố
   Lưu bản sao ra ổ khác hoặc ổ mạng/đám mây; giữ khoảng 2 tuần rồi xóa bản cũ.
   Kiểm tra phục hồi thử định kỳ (RESTORE VERIFYONLY và phục hồi sang database thử).

   Hai job bên dưới: QLBanHang_Backup_HangNgay (23:00 mỗi ngày, Chủ nhật làm Full, ngày khác
   làm Differential) và QLBanHang_Backup_Log (mỗi giờ). Cần SQL Server Agent đang chạy
   (bản Express không có Agent: dùng Task Scheduler gọi sqlcmd thay thế).
   Job chạy bằng tài khoản dịch vụ Agent, tài khoản này cần quyền ghi vào thư mục sao lưu.
   Job log chỉ chạy được sau khi đã có ít nhất một bản Full (chạy mục 4.1 trước).
   ===================================================================== */
USE msdb;
GO

-- ---- Job 1: sao lưu hằng ngày (Chủ nhật Full, các ngày khác Differential) ----
DECLARE @JobName SYSNAME = N'QLBanHang_Backup_HangNgay';
DECLARE @Cmd NVARCHAR(MAX) = N'
DECLARE @Db SYSNAME = N''QLBanHang'';
DECLARE @Dir NVARCHAR(260) = N''C:\Backup\QLBanHang\'';
DECLARE @Ts NVARCHAR(20) = FORMAT(GETDATE(), ''yyyyMMdd_HHmmss'');
DECLARE @F NVARCHAR(400);
IF (DATEDIFF(DAY, ''19000107'', GETDATE()) % 7) = 0      -- 07/01/1900 là Chủ nhật
BEGIN
    SET @F = @Dir + @Db + N''_FULL_'' + @Ts + N''.bak'';
    BACKUP DATABASE @Db TO DISK = @F WITH CHECKSUM;
END
ELSE
BEGIN
    SET @F = @Dir + @Db + N''_DIFF_'' + @Ts + N''.bak'';
    BACKUP DATABASE @Db TO DISK = @F WITH DIFFERENTIAL, CHECKSUM;
END;';

IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE name = @JobName)
    EXEC msdb.dbo.sp_delete_job @job_name = @JobName, @delete_unused_schedule = 1;

EXEC msdb.dbo.sp_add_job
     @job_name = @JobName,
     @enabled = 1,
     @description = N'Sao lưu CSDL QLBanHang hằng ngày lúc 23:00: Chủ nhật Full, ngày khác Differential.';

EXEC msdb.dbo.sp_add_jobstep
     @job_name = @JobName,
     @step_name = N'Sao luu Full hoac Differential',
     @subsystem = N'TSQL',
     @database_name = N'master',
     @command = @Cmd;

EXEC msdb.dbo.sp_add_jobschedule
     @job_name = @JobName,
     @name = N'Hang ngay 23:00',
     @freq_type = 4,              -- hằng ngày
     @freq_interval = 1,
     @active_start_time = 230000; -- 23:00:00

EXEC msdb.dbo.sp_add_jobserver @job_name = @JobName, @server_name = N'(local)';
GO

-- ---- Job 2: sao lưu Transaction Log mỗi giờ trong giờ làm việc ----
DECLARE @JobName SYSNAME = N'QLBanHang_Backup_Log';
DECLARE @Cmd NVARCHAR(MAX) = N'
DECLARE @Db SYSNAME = N''QLBanHang'';
DECLARE @Dir NVARCHAR(260) = N''C:\Backup\QLBanHang\'';
DECLARE @F NVARCHAR(400) = @Dir + @Db + N''_LOG_'' + FORMAT(GETDATE(), ''yyyyMMdd_HHmmss'') + N''.trn'';
BACKUP LOG @Db TO DISK = @F WITH CHECKSUM;';

IF EXISTS (SELECT 1 FROM msdb.dbo.sysjobs WHERE name = @JobName)
    EXEC msdb.dbo.sp_delete_job @job_name = @JobName, @delete_unused_schedule = 1;

EXEC msdb.dbo.sp_add_job
     @job_name = @JobName,
     @enabled = 1,
     @description = N'Sao lưu Transaction Log CSDL QLBanHang mỗi giờ từ 08:00 đến 22:59.';

EXEC msdb.dbo.sp_add_jobstep
     @job_name = @JobName,
     @step_name = N'Sao luu Transaction Log',
     @subsystem = N'TSQL',
     @database_name = N'master',
     @command = @Cmd;

EXEC msdb.dbo.sp_add_jobschedule
     @job_name = @JobName,
     @name = N'Moi gio 08:00-22:59',
     @freq_type = 4,
     @freq_interval = 1,
     @freq_subday_type = 8,       -- theo giờ
     @freq_subday_interval = 1,   -- mỗi 1 giờ
     @active_start_time = 080000,
     @active_end_time = 225959;

EXEC msdb.dbo.sp_add_jobserver @job_name = @JobName, @server_name = N'(local)';
GO

-- Xem các job vừa tạo; chạy thử ngay: EXEC msdb.dbo.sp_start_job N'QLBanHang_Backup_HangNgay';
SELECT j.name AS TenJob, j.enabled AS DangBat, s.name AS Lich
FROM msdb.dbo.sysjobs j
LEFT JOIN msdb.dbo.sysjobschedules js ON js.job_id = j.job_id
LEFT JOIN msdb.dbo.sysschedules s     ON s.schedule_id = js.schedule_id
WHERE j.name LIKE N'QLBanHang[_]Backup%';
GO

USE QLBanHang;
GO

-- Tắt tạm (giữ job, bật lại được)
EXEC msdb.dbo.sp_update_job @job_name = N'QLBanHang_Backup_Log', @enabled = 0;

-- Bật lại
EXEC msdb.dbo.sp_update_job @job_name = N'QLBanHang_Backup_Log', @enabled = 1;

-- Xóa hẳn
EXEC msdb.dbo.sp_delete_job @job_name = N'QLBanHang_Backup_Log', @delete_unused_schedule = 1;