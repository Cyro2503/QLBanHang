﻿/* =====================================================================
   04_LapTrinh_Sua.sql - View, Function, Stored Procedure, Trigger
   Thiết kế:
   - HoaDon chỉ là phần đầu chứng từ bán.
   - PhieuNhap chỉ là phần đầu chứng từ nhập.
   - Thông tin từng sản phẩm nằm ở ChiTietHoaDon / ChiTietPhieuNhap.
   - MaNCC nằm ở ChiTietPhieuNhap.
   Chạy SAU 01_TaoBang_Sua.sql và sau khi đã có dữ liệu cơ bản.
   ===================================================================== */

USE QLBanHang;
GO

/* =====================================================================
   PHẦN A - VIEW
   ===================================================================== */

CREATE OR ALTER VIEW dbo.vw_ChiTietHoaDon
AS
SELECT hd.SoHD,
       hd.NgayLap,
       kh.MaKH,
       kh.HoTen AS TenKhachHang,
       nv.MaNV,
       nv.HoTen AS TenNhanVien,
       ct.MaSP,
       sp.TenSP,
       ct.SoLuong,
       ct.DonGiaBan,
       ct.PhanTramGiam,
       ct.SoLuong * ct.DonGiaBan * (1 - ct.PhanTramGiam / 100.0) AS ThanhTien,
       hd.TrangThai
FROM dbo.HoaDon hd
JOIN dbo.KhachHang kh ON kh.MaKH = hd.MaKH
JOIN dbo.NhanVien nv ON nv.MaNV = hd.MaNV
JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = hd.SoHD
JOIN dbo.SanPham sp ON sp.MaSP = ct.MaSP;
GO

CREATE OR ALTER VIEW dbo.vw_DoanhThuThang
AS
SELECT YEAR(hd.NgayLap) AS Nam,
       MONTH(hd.NgayLap) AS Thang,
       SUM(ct.SoLuong * ct.DonGiaBan * (1 - ct.PhanTramGiam / 100.0)) AS DoanhThu
FROM dbo.HoaDon hd
JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = hd.SoHD
WHERE hd.TrangThai = N'Đã thanh toán'
GROUP BY YEAR(hd.NgayLap), MONTH(hd.NgayLap);
GO

CREATE OR ALTER VIEW dbo.vw_SanPhamSapHet
AS
SELECT MaSP, TenSP, DonViTinh, GiaBan, SoLuongTon, MaLoai
FROM dbo.SanPham
WHERE SoLuongTon < 10
WITH CHECK OPTION;
GO

/* =====================================================================
   PHẦN B - FUNCTION
   ===================================================================== */

CREATE OR ALTER FUNCTION dbo.fn_TongTienHoaDon (@SoHD VARCHAR(10))
RETURNS DECIMAL(18,2)
AS
BEGIN
    DECLARE @Tong DECIMAL(18,2);

    SELECT @Tong =
        SUM(ct.SoLuong * ct.DonGiaBan *
            (1 - ct.PhanTramGiam / 100.0))
    FROM dbo.ChiTietHoaDon ct
    JOIN dbo.HoaDon hd ON hd.SoHD = ct.SoHD
    WHERE ct.SoHD = @SoHD
      AND hd.TrangThai = N'Đã thanh toán';

    RETURN ISNULL(@Tong, 0);
END;
GO

CREATE OR ALTER FUNCTION dbo.fn_XepHangKhachHang (@MaKH VARCHAR(10))
RETURNS NVARCHAR(10)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM dbo.KhachHang WHERE MaKH = @MaKH)
        RETURN NULL;

    DECLARE @Tong DECIMAL(18,2);

    SELECT @Tong = ISNULL(SUM(
        ct.SoLuong * ct.DonGiaBan *
        (1 - ct.PhanTramGiam / 100.0)), 0)
    FROM dbo.HoaDon hd
    JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = hd.SoHD
    WHERE hd.MaKH = @MaKH
      AND hd.TrangThai = N'Đã thanh toán';

    RETURN CASE
        WHEN @Tong >= 50000000 THEN N'Vàng'
        WHEN @Tong >= 20000000 THEN N'Bạc'
        ELSE N'Đồng'
    END;
END;
GO

CREATE OR ALTER FUNCTION dbo.fn_TopSanPham
(
    @N INT,
    @TuNgay DATE,
    @DenNgay DATE
)
RETURNS TABLE
AS
RETURN
(
    SELECT TOP (@N)
           sp.MaSP,
           sp.TenSP,
           SUM(ct.SoLuong) AS TongSoLuongBan
    FROM dbo.HoaDon hd
    JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = hd.SoHD
    JOIN dbo.SanPham sp ON sp.MaSP = ct.MaSP
    WHERE hd.TrangThai = N'Đã thanh toán'
      AND hd.NgayLap >= @TuNgay
      AND hd.NgayLap < DATEADD(DAY, 1, @DenNgay)
    GROUP BY sp.MaSP, sp.TenSP
    ORDER BY SUM(ct.SoLuong) DESC
);
GO

/* =====================================================================
   PHẦN C - TABLE TYPE CHO sp_LapHoaDon
   ===================================================================== */

IF TYPE_ID(N'dbo.TVP_ChiTietHoaDon') IS NULL
BEGIN
    EXEC(N'
    CREATE TYPE dbo.TVP_ChiTietHoaDon AS TABLE
    (
        MaSP VARCHAR(10) NOT NULL,
        SoLuong INT NOT NULL,
        DonGiaBan DECIMAL(18,2) NOT NULL,
        PhanTramGiam DECIMAL(5,2) NOT NULL DEFAULT (0),
        PRIMARY KEY (MaSP)
    )');
END;
GO

/* =====================================================================
   PHẦN E - STORED PROCEDURE
   ===================================================================== */

/* E1. Thêm khách hàng, tự sinh KH0001, KH0002... */
CREATE OR ALTER PROCEDURE dbo.sp_ThemKhachHang
    @HoTen NVARCHAR(100),
    @SoDienThoai VARCHAR(15),
    @Email VARCHAR(100) = NULL,
    @DiaChi NVARCHAR(255) = NULL,
    @NgayDangKy DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        IF NULLIF(LTRIM(RTRIM(@HoTen)), N'') IS NULL
            THROW 50101, N'Họ tên không được để trống.', 1;

        IF NULLIF(LTRIM(RTRIM(@SoDienThoai)), '') IS NULL
            THROW 50102, N'Số điện thoại không được để trống.', 1;

        IF EXISTS (
            SELECT 1 FROM dbo.KhachHang
            WHERE SoDienThoai = @SoDienThoai
        )
            THROW 50103, N'Số điện thoại đã tồn tại.', 1;

        DECLARE @STT INT =
        (
            SELECT ISNULL(MAX(TRY_CONVERT(INT, SUBSTRING(MaKH, 3, 8))), 0) + 1
            FROM dbo.KhachHang
            WHERE MaKH LIKE 'KH[0-9]%'
        );

        DECLARE @MaKH VARCHAR(10) =
            'KH' + RIGHT('0000' + CONVERT(VARCHAR(8), @STT), 4);

        INSERT dbo.KhachHang
        (
            MaKH, HoTen, SoDienThoai, Email, DiaChi, NgayDangKy
        )
        VALUES
        (
            @MaKH, @HoTen, @SoDienThoai, @Email, @DiaChi,
            ISNULL(@NgayDangKy, CAST(GETDATE() AS DATE))
        );

        SELECT @MaKH AS MaKH, N'Thêm khách hàng thành công.' AS ThongBao;
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH
END;
GO

/* E2. Lập hóa đơn bán bằng Table-Valued Parameter.
       Toàn bộ hóa đơn + chi tiết nằm trong một transaction. */
CREATE OR ALTER PROCEDURE dbo.sp_LapHoaDon
    @MaKH VARCHAR(10),
    @MaNV VARCHAR(10),
    @ChiTiet dbo.TVP_ChiTietHoaDon READONLY
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM dbo.KhachHang WHERE MaKH = @MaKH)
            THROW 50111, N'Khách hàng không tồn tại.', 1;

        IF NOT EXISTS (SELECT 1 FROM dbo.NhanVien WHERE MaNV = @MaNV)
            THROW 50112, N'Nhân viên không tồn tại.', 1;

        IF NOT EXISTS (SELECT 1 FROM @ChiTiet)
            THROW 50113, N'Danh sách sản phẩm không được rỗng.', 1;

        IF EXISTS (
            SELECT 1 FROM @ChiTiet
            WHERE SoLuong <= 0
               OR DonGiaBan <= 0
               OR PhanTramGiam NOT BETWEEN 0 AND 50
        )
            THROW 50114, N'Dữ liệu chi tiết hóa đơn không hợp lệ.', 1;

        IF EXISTS (
            SELECT ct.MaSP
            FROM @ChiTiet ct
            LEFT JOIN dbo.SanPham sp ON sp.MaSP = ct.MaSP
            WHERE sp.MaSP IS NULL
        )
            THROW 50115, N'Có sản phẩm không tồn tại.', 1;

        BEGIN TRANSACTION;

        DECLARE @SoHD VARCHAR(10);
        DECLARE @STT INT =
        (
            SELECT ISNULL(MAX(TRY_CONVERT(INT, SUBSTRING(SoHD, 3, 8))), 0) + 1
            FROM dbo.HoaDon
            WHERE SoHD LIKE 'HD[0-9]%'
        );

        SET @SoHD = 'HD' + RIGHT('00000000' + CONVERT(VARCHAR(8), @STT), 8);

        INSERT dbo.HoaDon(SoHD, MaKH, MaNV, TrangThai)
        VALUES(@SoHD, @MaKH, @MaNV, N'Chờ thanh toán');

        INSERT dbo.ChiTietHoaDon
        (
            SoHD, MaSP, SoLuong, DonGiaBan, PhanTramGiam
        )
        SELECT
            @SoHD, MaSP, SoLuong, DonGiaBan, PhanTramGiam
        FROM @ChiTiet;

        COMMIT TRANSACTION;

        SELECT @SoHD AS SoHD, dbo.fn_TongTienHoaDon(@SoHD) AS TongTien;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

/* E3. Báo cáo doanh thu theo khoảng ngày */
CREATE OR ALTER PROCEDURE dbo.sp_BaoCaoDoanhThu
    @TuNgay DATE,
    @DenNgay DATE,
    @TongDoanhThu DECIMAL(18,2) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        IF @TuNgay IS NULL OR @DenNgay IS NULL OR @TuNgay > @DenNgay
            THROW 50121, N'Khoảng ngày không hợp lệ.', 1;

        SELECT @TongDoanhThu =
            ISNULL(SUM(
                ct.SoLuong * ct.DonGiaBan *
                (1 - ct.PhanTramGiam / 100.0)), 0)
        FROM dbo.HoaDon hd
        JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = hd.SoHD
        WHERE hd.TrangThai = N'Đã thanh toán'
          AND hd.NgayLap >= @TuNgay
          AND hd.NgayLap < DATEADD(DAY, 1, @DenNgay);

        SELECT hd.SoHD,
               hd.NgayLap,
               kh.HoTen AS TenKhachHang,
               SUM(ct.SoLuong * ct.DonGiaBan *
                   (1 - ct.PhanTramGiam / 100.0)) AS ThanhTien
        FROM dbo.HoaDon hd
        JOIN dbo.KhachHang kh ON kh.MaKH = hd.MaKH
        JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = hd.SoHD
        WHERE hd.TrangThai = N'Đã thanh toán'
          AND hd.NgayLap >= @TuNgay
          AND hd.NgayLap < DATEADD(DAY, 1, @DenNgay)
        GROUP BY hd.SoHD, hd.NgayLap, kh.HoTen
        ORDER BY hd.NgayLap, hd.SoHD;
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH
END;
GO

/* E4. Cập nhật hạng thành viên bằng CURSOR */
CREATE OR ALTER PROCEDURE dbo.sp_CapNhatHangThanhVien_Cursor
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @MaKH VARCHAR(10);
    DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
        SELECT MaKH FROM dbo.KhachHang;

    OPEN cur;
    FETCH NEXT FROM cur INTO @MaKH;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        UPDATE dbo.KhachHang
        SET HangThanhVien = dbo.fn_XepHangKhachHang(@MaKH)
        WHERE MaKH = @MaKH;

        FETCH NEXT FROM cur INTO @MaKH;
    END;

    CLOSE cur;
    DEALLOCATE cur;
END;
GO

/* E5. Cách viết lại bằng một UPDATE duy nhất */
CREATE OR ALTER PROCEDURE dbo.sp_CapNhatHangThanhVien_Update
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH ChiTieu AS
    (
        SELECT kh.MaKH,
               ISNULL(SUM(
                   ct.SoLuong * ct.DonGiaBan *
                   (1 - ct.PhanTramGiam / 100.0)), 0) AS TongChiTieu
        FROM dbo.KhachHang kh
        LEFT JOIN dbo.HoaDon hd
            ON hd.MaKH = kh.MaKH
           AND hd.TrangThai = N'Đã thanh toán'
        LEFT JOIN dbo.ChiTietHoaDon ct
            ON ct.SoHD = hd.SoHD
        GROUP BY kh.MaKH
    )
    UPDATE kh
    SET HangThanhVien =
        CASE
            WHEN c.TongChiTieu >= 50000000 THEN N'Vàng'
            WHEN c.TongChiTieu >= 20000000 THEN N'Bạc'
            ELSE N'Đồng'
        END
    FROM dbo.KhachHang kh
    JOIN ChiTieu c ON c.MaKH = kh.MaKH;
END;
GO

/* =====================================================================
   PHẦN F - TRIGGER
   ===================================================================== */

/* F1. Bán hàng: thêm/sửa/xóa chi tiết -> cập nhật tồn.
       Trigger xử lý nhiều dòng trong cùng một câu lệnh. */
CREATE OR ALTER TRIGGER dbo.trg_BanHang
ON dbo.ChiTietHoaDon
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Delta TABLE
    (
        MaSP VARCHAR(10) PRIMARY KEY,
        Delta INT NOT NULL
    );

    INSERT @Delta(MaSP, Delta)
    SELECT MaSP, SUM(SL)
    FROM
    (
        SELECT MaSP, SoLuong AS SL FROM inserted
        UNION ALL
        SELECT MaSP, -SoLuong FROM deleted
    ) X
    GROUP BY MaSP
    HAVING SUM(SL) <> 0;

    IF EXISTS
    (
        SELECT 1
        FROM @Delta d
        JOIN dbo.SanPham sp ON sp.MaSP = d.MaSP
        WHERE d.Delta > 0
          AND sp.SoLuongTon < d.Delta
    )
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50201, N'Không đủ số lượng tồn để bán.', 1;
    END;

    UPDATE sp
    SET SoLuongTon = SoLuongTon - d.Delta
    FROM dbo.SanPham sp
    JOIN @Delta d ON d.MaSP = sp.MaSP;
END;
GO

/* F2. Nhập hàng: thêm/sửa/xóa chi tiết -> cập nhật tồn */
CREATE OR ALTER TRIGGER dbo.trg_NhapHang
ON dbo.ChiTietPhieuNhap
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Delta TABLE
    (
        MaSP VARCHAR(10) PRIMARY KEY,
        Delta INT NOT NULL
    );

    INSERT @Delta(MaSP, Delta)
    SELECT MaSP, SUM(SL)
    FROM
    (
        SELECT MaSP, SoLuong AS SL FROM inserted
        UNION ALL
        SELECT MaSP, -SoLuong FROM deleted
    ) X
    GROUP BY MaSP
    HAVING SUM(SL) <> 0;

    IF EXISTS
    (
        SELECT 1
        FROM @Delta d
        JOIN dbo.SanPham sp ON sp.MaSP = d.MaSP
        WHERE sp.SoLuongTon + d.Delta < 0
    )
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50202, N'Không thể giảm phiếu nhập vì tồn kho sẽ âm.', 1;
    END;

    UPDATE sp
    SET SoLuongTon = SoLuongTon + d.Delta
    FROM dbo.SanPham sp
    JOIN @Delta d ON d.MaSP = sp.MaSP;
END;
GO

/* F3. Hủy hóa đơn: hoàn lại tồn kho */
CREATE OR ALTER TRIGGER dbo.trg_HuyHoaDon
ON dbo.HoaDon
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT UPDATE(TrangThai)
        RETURN;

    IF EXISTS
    (
        SELECT 1
        FROM inserted i
        JOIN deleted d ON d.SoHD = i.SoHD
        WHERE d.TrangThai = N'Đã hủy'
          AND i.TrangThai <> N'Đã hủy'
    )
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50203, N'Hóa đơn đã hủy không thể khôi phục.', 1;
    END;

    UPDATE sp
    SET SoLuongTon = sp.SoLuongTon + X.SoLuongHoan
    FROM dbo.SanPham sp
    JOIN
    (
        SELECT ct.MaSP, SUM(ct.SoLuong) AS SoLuongHoan
        FROM inserted i
        JOIN deleted d ON d.SoHD = i.SoHD
        JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = i.SoHD
        WHERE d.TrangThai = N'Đã thanh toán'
          AND i.TrangThai = N'Đã hủy'
        GROUP BY ct.MaSP
    ) X ON X.MaSP = sp.MaSP;
END;
GO

/* F4. Giá bán không thấp hơn giá nhập gần nhất */
CREATE OR ALTER TRIGGER dbo.trg_GiaBan
ON dbo.SanPham
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT UPDATE(GiaBan)
        RETURN;

    IF EXISTS
    (
        SELECT 1
        FROM inserted i
        CROSS APPLY
        (
            SELECT TOP (1) cpn.GiaNhap
            FROM dbo.ChiTietPhieuNhap cpn
            JOIN dbo.PhieuNhap pn ON pn.SoPN = cpn.SoPN
            WHERE cpn.MaSP = i.MaSP
            ORDER BY pn.NgayNhap DESC, pn.SoPN DESC
        ) G
        WHERE i.GiaBan < G.GiaNhap
    )
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50204, N'Giá bán không được thấp hơn giá nhập gần nhất.', 1;
    END;
END;
GO

/* F5. INSTEAD OF DELETE trên view ChiTietHoaDon */
CREATE OR ALTER TRIGGER dbo.trg_XoaChiTietHoaDon
ON dbo.vw_ChiTietHoaDon
INSTEAD OF DELETE
AS
BEGIN
    SET NOCOUNT ON;

    DELETE ct
    FROM dbo.ChiTietHoaDon ct
    JOIN deleted d
      ON d.SoHD = ct.SoHD
     AND d.MaSP = ct.MaSP;
END;
GO

/* =====================================================================
   PHẦN G - CÁC LỆNH GỌI THỬ
   =====================================================================

-- SELECT dbo.fn_TongTienHoaDon('HD00000001');
-- SELECT dbo.fn_XepHangKhachHang('KH0001');
-- SELECT * FROM dbo.fn_TopSanPham(5,'2026-01-01','2026-12-31');

-- EXEC dbo.sp_ThemKhachHang
--      N'Nguyễn Văn Test','0988888888','test@gmail.com',N'Hải Phòng',NULL;

-- DECLARE @CT dbo.TVP_ChiTietHoaDon;
-- INSERT @CT VALUES
-- ('SP001',1,10000000,0),
-- ('SP002',2,5000000,10);
-- EXEC dbo.sp_LapHoaDon 'KH0001','NV001',@CT;

-- DECLARE @Tong DECIMAL(18,2);
-- EXEC dbo.sp_BaoCaoDoanhThu
--      '2026-01-01','2026-12-31',@Tong OUTPUT;
-- SELECT @Tong AS TongDoanhThu;

-- EXEC dbo.sp_CapNhatHangThanhVien_Cursor;
-- EXEC dbo.sp_CapNhatHangThanhVien_Update;

-- SELECT * FROM dbo.vw_ChiTietHoaDon;
-- SELECT * FROM dbo.vw_DoanhThuThang;
-- SELECT * FROM dbo.vw_SanPhamSapHet;
-- DELETE FROM dbo.vw_ChiTietHoaDon
-- WHERE SoHD='HD00000001' AND MaSP='SP001';
*/
GO
