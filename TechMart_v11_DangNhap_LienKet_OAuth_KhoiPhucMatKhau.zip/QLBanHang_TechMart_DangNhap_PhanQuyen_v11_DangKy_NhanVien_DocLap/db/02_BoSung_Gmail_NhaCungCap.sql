/* ================================================================
   02_BoSung_Gmail_NhaCungCap.sql
   Bổ sung Gmail/Email cho nhà cung cấp mà không xóa dữ liệu hiện có.

   Chạy trên database QLBanHang hiện tại.
   KHÔNG chạy lại 01_TaoBang_Sua.sql nếu không muốn tạo lại CSDL.
   ================================================================ */

USE QLBanHang;
GO

IF COL_LENGTH('dbo.NhaCungCap', 'Email') IS NULL
BEGIN
    ALTER TABLE dbo.NhaCungCap
    ADD Email VARCHAR(100) NULL;
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UX_NhaCungCap_Email'
      AND object_id = OBJECT_ID(N'dbo.NhaCungCap')
)
BEGIN
    CREATE UNIQUE INDEX UX_NhaCungCap_Email
        ON dbo.NhaCungCap(Email)
        WHERE Email IS NOT NULL;
END;
GO

/* Kiểm tra dữ liệu sau khi bổ sung */
SELECT
    MaNCC,
    TenNCC,
    SoDienThoai,
    Email,
    DiaChi
FROM dbo.NhaCungCap
ORDER BY MaNCC;
GO

/* Ví dụ dữ liệu Gmail - bỏ comment và đổi thông tin theo nhà cung cấp thật.

UPDATE dbo.NhaCungCap
SET Email = 'nhacungcap1@gmail.com'
WHERE MaNCC = 'NCC001';

UPDATE dbo.NhaCungCap
SET Email = 'nhacungcap2@gmail.com'
WHERE MaNCC = 'NCC002';

*/
