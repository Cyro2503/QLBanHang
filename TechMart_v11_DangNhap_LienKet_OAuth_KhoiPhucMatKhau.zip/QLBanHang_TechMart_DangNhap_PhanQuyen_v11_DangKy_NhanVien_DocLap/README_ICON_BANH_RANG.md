# Cập nhật icon bánh răng TechMart

- Dùng ảnh gốc trong `Icons/` làm nguồn.
- Đã loại bỏ nền caro/trắng, xuất `public/images/gear-solid.png` và `public/images/gear-outline.png` nền trong suốt.
- Icon Quản trị hệ thống trên sidebar dùng bản outline, không có nền/ô màu; màu nét được điều khiển bằng CSS để đồng bộ với icon menu.
- Các vị trí khác được nhận diện là icon Quản trị/Cài đặt cũng dùng cùng bộ icon outline.

Không thay đổi route, phân quyền hoặc cấu trúc database.


## Phiên bản v30 – tăng độ đậm icon Sidebar
- Tăng độ dày nét của `public/images/gear-outline.png`, vẫn giữ nền trong suốt.
- Tăng độ hiển thị icon bánh răng trong Sidebar lên opacity 1 để nét trắng rõ và đồng đều hơn với các icon điều hướng khác.
- Không thay đổi logic phân quyền, đăng nhập hoặc database.
