# TechMart - Node.js + SQL Server

## 1. Cài đặt

Dùng Node.js 20 trở lên (khuyến nghị Node.js 22/24). Mở Terminal tại thư mục có `package.json`: 

```powershell
npm install
```

## 2. Cấu hình SQL Server

Giữ cấu hình kết nối trong `.env` riêng trên máy. Khi giải nén bản nâng cấp, hãy chép `.env` từ thư mục dự án cũ sang thư mục mới (hoặc tạo từ `.env.example` rồi điền lại cấu hình). Không đưa `.env` lên Git hoặc public hosting. Cấu hình `DB_SERVER`, `DB_DATABASE`, `DB_USER`, `DB_PASSWORD`, `DB_PORT` theo SQL Server của bạn.

## 3. Cập nhật database

Với database đã có dữ liệu, KHÔNG chạy lại `01_TaoBang_Sua.sql` vì script tạo schema ban đầu có thể xóa/tạo lại bảng. Chạy các migration bổ sung phù hợp với phiên bản database hiện tại.

Đối với chức năng đăng nhập ngoài và khôi phục mật khẩu, chạy:

```text
db/08_Auth_External_Recovery.sql
```

Script này chỉ tạo các bảng liên kết OAuth, thông tin khôi phục và OTP; không xóa dữ liệu nghiệp vụ.

## 4. Chạy ứng dụng

```powershell
npm start
```

Mở `http://localhost:3000`.

## 5. Quy tắc tài khoản

- Không có đăng ký tài khoản nhân viên công khai. `/auth/register` chỉ chuyển về trang đăng nhập.
- Admin tạo hồ sơ nhân viên trong `dbo.NhanVien`, sau đó tạo tài khoản và cấp vai trò tại khu vực quản trị.
- Google/Facebook chỉ đăng nhập được sau khi nhân viên đã đăng nhập nội bộ và liên kết provider trong `/auth/security`. Không tự tạo tài khoản TechMart mới.
- Instagram không được giả lập thành phương thức đăng nhập chung. Có thể tích hợp Instagram Professional riêng cho tác vụ quản lý nội dung/tin nhắn nếu cần.

## 6. Bảo mật và khôi phục mật khẩu

- Nhân viên vào biểu tượng khóa/bảo mật trên thanh trên cùng để liên kết Gmail, số điện thoại và Google/Facebook.
- Email và số điện thoại phải được xác minh bằng OTP 6 số trước khi dùng để khôi phục.
- Mã OTP hết hạn sau 10 phút, chỉ dùng một lần, tối đa 5 lần nhập sai; giới hạn gửi 3 mã/tài khoản/kênh trong 15 phút và chờ 60 giây giữa các lần gửi.
- Mật khẩu được lưu dạng scrypt hash; OTP được lưu dạng HMAC hash.
- Sau khi đổi/khôi phục mật khẩu, các phiên đăng nhập đang hoạt động trong tiến trình hiện tại bị thu hồi.

## 7. Cấu hình Gmail SMTP

Trong `.env`, đặt `SMTP_USER` là địa chỉ Gmail gửi thư và `SMTP_PASS` là **Google App Password** (cần bật xác minh 2 bước và tạo App Password nếu tài khoản đủ điều kiện). Không dùng mật khẩu đăng nhập Gmail thông thường. Có thể thay SMTP bằng relay email của tổ chức.

## 8. Cấu hình SMS

Ví dụ hiện tại dùng Twilio REST API. Điền `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM_NUMBER`. Số gửi phải được nhà cung cấp cấp phép và tài khoản phải được phép gửi tới Việt Nam. Số điện thoại nhận được chuẩn hóa sang E.164, ví dụ `+849xxxxxxxx`. Có thể thay Twilio bằng SMS Gateway khác bằng cách thay hàm `sendSmsOtp` trong `routes/auth.js`.

## 9. Cấu hình Google OAuth

Tạo OAuth Client dạng Web Application trong Google Cloud Console, thêm Authorized redirect URI chính xác:

```text
http://localhost:3000/auth/oauth/google/callback
```

Điền `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_CALLBACK_URL`. Khi public, thay callback bằng HTTPS domain thật và đăng ký đúng URI đó trong Google Cloud Console.

## 10. Cấu hình Facebook Login

Tạo ứng dụng trong Meta for Developers, bật Facebook Login và khai báo Valid OAuth Redirect URI:

```text
http://localhost:3000/auth/oauth/facebook/callback
```

Điền `FACEBOOK_APP_ID`, `FACEBOOK_APP_SECRET`, `FACEBOOK_CALLBACK_URL` và kiểm tra `FACEBOOK_GRAPH_VERSION` còn được Meta hỗ trợ. Ứng dụng ở chế độ Development chỉ cho các tài khoản được thêm vai trò app test đăng nhập. Khi public cần hoàn tất các yêu cầu xét duyệt/chính sách của Meta.

## 11. Khóa bí mật và triển khai public

`OTP_HASH_SECRET` và `OAUTH_STATE_SECRET` trong `.env` phải là hai chuỗi ngẫu nhiên riêng biệt, tối thiểu 32 ký tự. Có thể tạo bằng lệnh `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` và chạy hai lần. Tệp `.env.example` chỉ là mẫu; giữ bí mật `.env`. Khi public phải dùng HTTPS, đặt `NODE_ENV=production`, `COOKIE_SECURE=true`, `APP_BASE_URL=https://ten-mien-cua-ban` và cập nhật callback URLs.

Phiên đăng nhập hiện tại được lưu trong Map trong bộ nhớ, phù hợp chạy một tiến trình local. Trước khi triển khai production nhiều tiến trình/máy chủ, cần chuyển session sang kho lưu trữ bền vững (ví dụ SQL/Redis) và bổ sung CSRF protection, reverse-proxy hardening, logging/monitoring.

## 12. Tệp cấu hình mẫu

Xem `.env.example`. Không chia sẻ ảnh chụp hoặc nội dung `.env` có chứa mật khẩu database, OAuth secret, SMTP password, Twilio token hoặc signing secret.
