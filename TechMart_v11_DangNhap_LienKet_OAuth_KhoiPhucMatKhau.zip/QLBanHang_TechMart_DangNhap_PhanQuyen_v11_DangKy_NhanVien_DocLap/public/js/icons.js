(function(){
 'use strict';
 const icons={
  home:'<path d="m3 10 9-7 9 7"/><path d="M5 9v11h14V9M9 20v-7h6v7"/>',
  products:'<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Z"/><path d="m4.3 7.7 7.7 4.4 7.7-4.4M12 21v-8.9"/>',
  categories:'<rect x="3" y="4" width="8" height="7" rx="1.5"/><rect x="13" y="4" width="8" height="7" rx="1.5"/><rect x="3" y="13" width="8" height="7" rx="1.5"/><rect x="13" y="13" width="8" height="7" rx="1.5"/>',
  customers:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
  employees:'<rect x="3" y="5" width="18" height="15" rx="2"/><circle cx="9" cy="11" r="2.5"/><path d="M5.5 17a3.5 3.5 0 0 1 7 0M15 10h3M15 14h3"/>',
  suppliers:'<path d="M3 21V8l9-5 9 5v13M3 10h18M8 21v-6h8v6"/><path d="M7 11h2m3 0h2m3 0h1"/>',
  invoices:'<path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 12h7M9 16h7"/>',
  purchases:'<path d="M12 3v12m-5-5 5 5 5-5"/><path d="M4 17v4h16v-4"/>',
  reports:'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  settings:'<path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-1.7 2.94-.08-.03a1.7 1.7 0 0 0-1.84.32l-.07.06h-3.4l-.01-.09a1.7 1.7 0 0 0-1.2-1.47l-.09-.03-1.7-2.94.07-.06a1.7 1.7 0 0 0 .33-1.84l-.04-.09 1.7-2.94.09.01a1.7 1.7 0 0 0 1.47-1.2l.03-.09h3.4l.03.09a1.7 1.7 0 0 0 1.47 1.2l.09-.01 1.7 2.94-.06.09Z"/>',
  add:'<path d="M12 5v14M5 12h14"/>', edit:'<path d="m15 5 4 4M4 20l4-.8L19 8a2.1 2.1 0 0 0-3-3L5 16l-1 4Z"/>',
  delete:'<path d="M3 6h18M8 6V4h8v2m3 0-1 15H6L5 6M10 10v7m4-7v7"/>',
  save:'<path d="M5 3h12l4 4v14H3V3h2Z"/><path d="M7 3v6h9V3M7 21v-7h10v7"/>',
  search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
  lock:'<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  logout:'<path d="M10 17l5-5-5-5M15 12H3"/><path d="M12 3h7a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-7"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  dashboard:'<rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="5" rx="1.5"/><rect x="13" y="10" width="8" height="11" rx="1.5"/><rect x="3" y="13" width="8" height="8" rx="1.5"/>',
  calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
  chart:'<path d="M3 3v18h18M7 14l4-4 4 3 6-7"/>',
  back:'<path d="m15 18-6-6 6-6M9 12h12"/>',
  key:'<circle cx="8" cy="15" r="4"/><path d="m11 12 8-8 2 2-2 2 2 2-3 3-2-2-2 2"/>',
  mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  box:'<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="M3 8v9l9 5 9-5V8M12 13v9"/>'
 };
 const svg=(name)=> name==='settings'
  ? '<img class="tm-gear-icon" src="/images/gear-solid.png" alt="" aria-hidden="true">'
  : `<svg class="tm-icon-svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${icons[name]||icons.dashboard}</svg>`;
 function pick(text,href='',explicit=''){
  if(explicit && Object.prototype.hasOwnProperty.call(icons, explicit)) return explicit;
  const s=(text+' '+href).toLowerCase();
  if(/đăng xuất|logout/.test(s))return 'logout'; if(/đổi mật khẩu|đặt mk|mật khẩu/.test(s))return 'key';
  if(/thêm|tạo tài khoản|tạo hồ sơ|tạo mới/.test(s))return 'add'; if(/sửa|chỉnh sửa|cập nhật/.test(s))return 'edit'; if(/xóa|xoá/.test(s))return 'delete'; if(/lưu|cập nhật quyền/.test(s))return 'save'; if(/tìm kiếm|tìm theo|lọc/.test(s))return 'search'; if(/loại sản phẩm|danh mục/.test(s))return 'categories'; if(/nhân viên|hồ sơ nhân sự/.test(s))return 'employees'; if(/khách hàng/.test(s))return 'customers'; if(/nhà cung cấp/.test(s))return 'suppliers'; if(/sản phẩm|tồn kho/.test(s))return 'products'; if(/hóa đơn|hoá đơn/.test(s))return 'invoices'; if(/phiếu nhập|nhập hàng/.test(s))return 'purchases'; if(/báo cáo|doanh thu|thống kê/.test(s))return 'reports'; if(/quản trị|tài khoản|phân quyền|vai trò/.test(s))return 'settings'; if(/đăng nhập/.test(s))return 'user'; if(/quay lại|trở về|về tổng quan|trang chủ|trung tâm quản trị/.test(s))return 'back'; if(/ngày|khoảng thời gian/.test(s))return 'calendar'; if(/tiềm năng|phân tích|xu hướng/.test(s))return 'chart'; if(/email|gmail/.test(s))return 'mail'; return null;
 }
 function init(){
  document.querySelectorAll('.portal-nav-link').forEach(a=>{const span=a.querySelector('.nav-icon');if(!span)return;let name=pick(a.textContent,a.getAttribute('href')||'',a.dataset.icon||'');if(a.getAttribute('href')==='/')name='home';span.innerHTML=svg(name||'dashboard');span.classList.add('tm-icon-holder');});
  document.querySelectorAll('h1,h2,h3').forEach(h=>{if(h.querySelector('.tm-heading-icon'))return;const name=pick(h.textContent);if(name){const span=document.createElement('span');span.className='tm-heading-icon';span.innerHTML=svg(name);h.prepend(span);}});
  document.querySelectorAll('a.btn,button.btn,.portal-icon-btn').forEach(el=>{if(el.querySelector('.tm-button-icon'))return;const name=pick(el.textContent,(el.getAttribute('href')||'')+' '+(el.getAttribute('title')||el.getAttribute('aria-label')||''),el.dataset.icon||'');if(!name)return;const span=document.createElement('span');span.className='tm-button-icon';span.innerHTML=svg(name);el.prepend(span);});
  document.querySelectorAll('.card h2,.section-head h1').forEach(h=>h.classList.add('tm-icon-heading'));
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
