(function () {
  'use strict';

  const ready = (fn) => {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', fn, { once: true });
    } else {
      fn();
    }
  };

  ready(() => {
    const topbar = document.querySelector('.topbar');
    const navLinks = Array.from(document.querySelectorAll('.nav a'));
    const timeEl = document.querySelector('[data-live-time]');

    // Đánh dấu menu hiện tại để người dùng luôn biết mình đang ở đâu.
    const currentPath = window.location.pathname.replace(/\/$/, '') || '/';
    navLinks.forEach((link) => {
      try {
        const linkPath = new URL(link.href, window.location.origin).pathname.replace(/\/$/, '') || '/';
        const isHome = linkPath === '/' && currentPath === '/';
        const isNested = linkPath !== '/' && currentPath.startsWith(linkPath);
        link.classList.toggle('is-active', isHome || isNested);
      } catch {
        // Bỏ qua link không hợp lệ thay vì làm hỏng toàn bộ hiệu ứng.
      }
    });

    // Đồng hồ nhẹ ở góc phải thanh điều hướng.
    const updateClock = () => {
      if (!timeEl) return;
      const now = new Date();
      timeEl.textContent = new Intl.DateTimeFormat('vi-VN', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      }).format(now);
    };
    updateClock();
    window.setInterval(updateClock, 1000);

    // Thanh menu đổi độ đậm khi cuộn.
    const handleScroll = () => {
      if (topbar) topbar.classList.toggle('is-scrolled', window.scrollY > 8);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });

    // Hiệu ứng ánh sáng chạy theo chuột trên card.
    document.querySelectorAll('.card, .stat, .quick-card, .workflow-step').forEach((card) => {
      card.addEventListener('pointermove', (event) => {
        const rect = card.getBoundingClientRect();
        card.style.setProperty('--mx', `${event.clientX - rect.left}px`);
        card.style.setProperty('--my', `${event.clientY - rect.top}px`);
      });
    });

    // Ripple khi bấm nút/liên kết hành động.
    document.querySelectorAll('.btn').forEach((button) => {
      button.addEventListener('click', (event) => {
        const rect = button.getBoundingClientRect();
        const ripple = document.createElement('span');
        ripple.className = 'ripple';
        ripple.style.left = `${event.clientX - rect.left}px`;
        ripple.style.top = `${event.clientY - rect.top}px`;
        button.appendChild(ripple);
        window.setTimeout(() => ripple.remove(), 550);
      });
    });

    // Các khu vực xuất hiện mềm mại khi lướt xuống.
    const revealTargets = document.querySelectorAll('.hero, .stats, .stock-alerts, .grid-2, .card, .quick-grid, .workflow, .tip-strip');
    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver((entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            obs.unobserve(entry.target);
          }
        });
      }, { threshold: 0.08 });
      revealTargets.forEach((el) => {
        el.classList.add('reveal-on-scroll');
        observer.observe(el);
      });
    } else {
      revealTargets.forEach((el) => el.classList.add('is-visible'));
    }

    // Xác nhận đăng xuất. Form đăng xuất được đánh dấu data-no-loading để
    // không bị đổi thành "Đang xử lý..." trong thanh header trước khi chuyển trang.
    document.querySelectorAll('form[data-confirm-logout]').forEach((form) => {
      form.addEventListener('submit', (event) => {
        event.preventDefault();

        const confirmed = window.confirm('Bạn có chắc muốn đăng xuất khỏi TechMart không?');
        if (!confirmed) return;

        const button = form.querySelector('button[type="submit"]');
        if (button) {
          button.disabled = true;
          button.setAttribute('aria-busy', 'true');
          button.title = 'Đang đăng xuất...';
        }

        // Submit native form để gửi POST /auth/logout mà không kích hoạt
        // handler loading chung của site.js.
        HTMLFormElement.prototype.submit.call(form);
      });
    });

    // Chặn double-submit cho form, nhưng vẫn cho phép nút Thêm dòng (type=button).
    document.querySelectorAll('form').forEach((form) => {
      form.addEventListener('submit', () => {
        const submitter = form.querySelector('button[type="submit"]:not([data-no-loading])');
        if (!submitter) return;
        if (submitter.dataset.loadingApplied === '1') return;
        submitter.dataset.loadingApplied = '1';
        submitter.disabled = true;
        submitter.classList.add('is-loading');
        submitter.dataset.originalText = submitter.textContent.trim();
        submitter.textContent = 'Đang xử lý...';
      });
    });

    // Nút về đầu trang chỉ xuất hiện khi đã kéo xuống.
    const backTop = document.createElement('button');
    backTop.type = 'button';
    backTop.className = 'back-top';
    backTop.setAttribute('aria-label', 'Về đầu trang');
    backTop.innerHTML = '↑';
    document.body.appendChild(backTop);

    const toggleBackTop = () => {
      backTop.classList.toggle('is-visible', window.scrollY > 420);
    };
    toggleBackTop();
    window.addEventListener('scroll', toggleBackTop, { passive: true });
    backTop.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  });
})();
