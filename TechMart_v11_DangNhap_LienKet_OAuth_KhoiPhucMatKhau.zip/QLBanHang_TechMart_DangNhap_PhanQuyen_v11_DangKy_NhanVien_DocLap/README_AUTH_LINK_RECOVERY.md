# Hướng dẫn bật đăng nhập liên kết và khôi phục mật khẩu

## Luồng sử dụng

1. Admin tạo hồ sơ nhân viên và tài khoản nội bộ trong TechMart.
2. Nhân viên đăng nhập bằng tài khoản nội bộ.
3. Mở **Bảo mật và liên kết tài khoản** ở biểu tượng khóa trên thanh công cụ.
4. Nhập Gmail và/hoặc số điện thoại; nhận mã 6 số qua email/SMS rồi xác minh.
5. Liên kết Google/Facebook bằng OAuth.
6. Khi quên mật khẩu, vào `/auth/forgot-password`, chọn email hoặc SMS đã xác minh, nhập OTP và đặt mật khẩu mới.

## Bước bắt buộc trước khi chạy

1. Mở SQL Server Management Studio, chọn database `QLBanHang`, chạy `db/08_Auth_External_Recovery.sql`.
2. Chạy `npm install` trong thư mục dự án để cài Nodemailer.
3. Chạy `node scripts/generate-auth-secrets.js`, sao chép hai dòng kết quả vào `.env`.
4. Điền các biến SMTP/Twilio/Google/Facebook trong `.env` theo `.env.example`.
5. Khởi động lại Node.js.

## Cấu hình local callback

- Google: `http://localhost:3000/auth/oauth/google/callback`
- Facebook: `http://localhost:3000/auth/oauth/facebook/callback`

Nếu dùng port khác, sửa đồng nhất `APP_BASE_URL`, callback trong `.env` và callback URI ở trang quản trị ứng dụng tương ứng.

## Kiểm tra nhanh

- Chưa cấu hình OAuth: nút Google/Facebook hiển thị trạng thái chưa cấu hình.
- Chưa chạy migration 08: trang bảo mật báo cần cập nhật database.
- Chưa cấu hình SMTP/Twilio: chức năng gửi mã không hoạt động; không có OTP giả hiển thị trên trình duyệt.
- Chưa liên kết provider: đăng nhập bằng provider bị từ chối và không tạo tài khoản nội bộ mới.
- Email/SMS không xác minh: không được phép dùng khôi phục mật khẩu.

## Ghi chú

Instagram không được bật như nút đăng nhập phổ thông. Không có API đăng nhập tổng quát cho mọi tài khoản Instagram cá nhân; tích hợp Instagram Professional là một module khác.
