function required(value) {
  return value !== undefined && value !== null && String(value).trim() !== '';
}

function positiveNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0;
}

function nonNegativeNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) && n >= 0;
}

function positiveInt(value) {
  const n = Number(value);
  return Number.isInteger(n) && n > 0;
}

module.exports = { required, positiveNumber, nonNegativeNumber, positiveInt };
