const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const { testConnection, describeConfig } = require('../config/db');

(async () => {
  console.log('========================================');
  console.log(' KIỂM TRA KẾT NỐI QLBanHang');
  console.log('========================================');
  console.log(`SQL Server mục tiêu: ${describeConfig()}`);

  try {
    const info = await testConnection();
    console.log('OK - Kết nối thành công.');
    console.table(info);
  } catch (error) {
    console.error('FAIL - Không kết nối được SQL Server.');
    console.error('Code:', error.code || '(không có)');
    console.error('Message:', error.message);
    if (error.originalError) {
      console.error('Original:', error.originalError.message || error.originalError);
    }
    process.exitCode = 1;
  }
})();
