const crypto = require('crypto');

console.log('# Sao chép hai dòng dưới đây vào .env. Không dùng chung hai giá trị.');
console.log(`OTP_HASH_SECRET=${crypto.randomBytes(48).toString('hex')}`);
console.log(`OAUTH_STATE_SECRET=${crypto.randomBytes(48).toString('hex')}`);
