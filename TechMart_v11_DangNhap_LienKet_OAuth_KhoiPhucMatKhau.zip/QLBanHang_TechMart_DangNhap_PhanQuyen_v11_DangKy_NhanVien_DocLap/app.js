const path = require('path');
const express = require('express');

require('dotenv').config({ path: path.join(__dirname, '.env') });

const { closePool, describeConfig, testConnection } = require('./config/db');
const homeRoutes = require('./routes/home');
const productRoutes = require('./routes/products');
const categoryRoutes = require('./routes/categories');
const customerRoutes = require('./routes/customers');
const employeeRoutes = require('./routes/employees');
const supplierRoutes = require('./routes/suppliers');
const invoiceRoutes = require('./routes/invoices');
const purchaseRoutes = require('./routes/purchases');
const reportRoutes = require('./routes/reports');
const healthRoutes = require('./routes/health');
const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');
const { requireAuth, authorizeRequest } = require('./middleware/auth');

const app = express();
if (String(process.env.TRUST_PROXY || '').toLowerCase() === 'true') app.set('trust proxy', 1);
const port = Number(process.env.PORT || 3000);

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.locals.formatMoney = value => new Intl.NumberFormat('vi-VN', {
  style: 'currency',
  currency: 'VND',
  maximumFractionDigits: 0
}).format(Number(value || 0));

app.locals.formatDateTime = value => {
  if (!value) return '';
  return new Date(value).toLocaleString('vi-VN');
};

app.locals.formatDate = value => {
  if (!value) return '';
  return new Date(value).toLocaleDateString('vi-VN');
};

// Giá trị mặc định để các view như trang lỗi/health có thể render trước khi middleware đăng nhập chạy.
app.locals.currentUser = null;
app.locals.can = () => false;

app.use('/health', healthRoutes);
app.use('/auth', authRoutes);

// Mọi module quản lý đều yêu cầu đăng nhập và được kiểm tra quyền ở backend.
app.use(requireAuth);
app.use(authorizeRequest);

app.use('/', homeRoutes);
app.use('/products', productRoutes);
app.use('/categories', categoryRoutes);
app.use('/customers', customerRoutes);
app.use('/employees', employeeRoutes);
app.use('/suppliers', supplierRoutes);
app.use('/invoices', invoiceRoutes);
app.use('/purchases', purchaseRoutes);
app.use('/reports', reportRoutes);
app.use('/admin', adminRoutes);

app.use((req, res) => res.status(404).render('error', {
  title: 'Không tìm thấy trang',
  message: `Đường dẫn ${req.originalUrl} không tồn tại.`
}));

app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  return res.status(500).render('error', {
    title: 'Lỗi ứng dụng',
    message: err.message || 'Có lỗi xảy ra.'
  });
});

const server = app.listen(port, async () => {
  console.log(`QLBanHangWeb đang chạy: http://localhost:${port}`);
  console.log(`SQL Server mục tiêu: ${describeConfig()}`);
  try {
    const info = await testConnection();
    console.log(`Kết nối CSDL OK: ${info.DatabaseName} | Instance: ${info.ServiceName} | TCP: ${info.LocalTcpPort ?? 'Browser/không trả về'}`);
  } catch (error) {
    console.error('KẾT NỐI SQL SERVER THẤT BẠI.');
    console.error('Mở http://localhost:' + port + '/health/db để xem lỗi chi tiết.');
    console.error(error);
  }
});

async function shutdown() {
  await closePool();
  server.close(() => process.exit(0));
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
