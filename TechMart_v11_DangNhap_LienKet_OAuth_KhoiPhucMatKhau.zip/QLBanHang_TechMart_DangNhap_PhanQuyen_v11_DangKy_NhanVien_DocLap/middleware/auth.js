const { getSession } = require('../utils/auth');

function permissionForRequest(req) {
  const path = req.path || '/';
  const method = req.method.toUpperCase();

  if (path === '/') return 'dashboard.view';
  if (path.startsWith('/admin/roles')) return 'roles.manage';
  if (path.startsWith('/admin/accounts')) return 'accounts.manage';
  if (path === '/admin' || path.startsWith('/admin/')) return 'accounts.manage';

  const modules = {
    products: 'products',
    categories: 'categories',
    customers: 'customers',
    employees: 'employees',
    suppliers: 'suppliers',
    invoices: 'invoices',
    purchases: 'purchases',
    reports: 'reports'
  };

  const first = path.split('/').filter(Boolean)[0];
  const key = modules[first];
  if (!key) return null;

  const rest = path.slice(`/${first}`.length);
  if (key === 'reports') return 'reports.view';
  if (key === 'invoices' && /\/[^/]+\/cancel$/.test(rest)) return 'invoices.cancel';
  if (rest === '/create') return `${key}.create`;
  if (/^\/edit\/[^/]+$/.test(rest)) return `${key}.edit`;
  if (/^\/delete\/[^/]+$/.test(rest) && method === 'POST') return `${key}.delete`;
  if (key === 'invoices' && method === 'POST' && /^\/[^/]+\/cancel$/.test(rest)) return 'invoices.cancel';
  if (key === 'invoices' && method === 'POST' && rest === '/create') return 'invoices.create';
  if (key === 'purchases' && method === 'POST' && rest === '/create') return 'purchases.create';
  if (method === 'POST' && rest.startsWith('/create')) return `${key}.create`;
  if (method === 'POST' && rest.startsWith('/edit/')) return `${key}.edit`;
  return `${key}.view`;
}

function requireAuth(req, res, next) {
  const session = getSession(req);
  if (!session) {
    if (req.path === '/' || !req.path.startsWith('/auth')) {
      return res.redirect(`/auth/login?returnUrl=${encodeURIComponent(req.originalUrl)}`);
    }
    return res.redirect('/auth/login');
  }
  req.user = session.user;
  res.locals.currentUser = req.user;
  res.locals.can = permission => req.user?.permissions?.includes(permission) || false;
  return next();
}

function authorizeRequest(req, res, next) {
  const permission = permissionForRequest(req);
  if (!permission) return next();
  if (req.user?.permissions?.includes(permission)) return next();
  return res.status(403).render('forbidden', {
    title: 'Không có quyền truy cập',
    permission
  });
}

module.exports = { requireAuth, authorizeRequest, permissionForRequest };
