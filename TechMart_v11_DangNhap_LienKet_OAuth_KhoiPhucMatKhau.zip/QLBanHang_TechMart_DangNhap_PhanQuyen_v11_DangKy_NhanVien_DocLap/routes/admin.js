const express = require('express');
const { sql, query, getPool } = require('../config/db');
const { hashPassword, destroySessionsForAccount, destroySessionsForRole } = require('../utils/auth');

const router = express.Router();

async function stats() {
  const r = await query(`
    SELECT
      COUNT(*) AS TongTaiKhoan,
      SUM(CASE WHEN TrangThai='CHO_DUYET' AND MaNV IS NULL THEN 1 ELSE 0 END) AS ChoDuyet,
      SUM(CASE WHEN TrangThai='HOAT_DONG' THEN 1 ELSE 0 END) AS HoatDong,
      SUM(CASE WHEN TrangThai='KHOA' THEN 1 ELSE 0 END) AS BiKhoa
    FROM dbo.TaiKhoan;
  `);
  const rr = await query('SELECT COUNT(*) AS TongVaiTro FROM dbo.VaiTro');
  return { ...r[0].recordset[0], TongVaiTro: rr[0].recordset[0].TongVaiTro };
}

async function loadRoleOptions() {
  return (await query('SELECT MaVaiTro,TenVaiTro,MoTa FROM dbo.VaiTro ORDER BY CASE WHEN MaVaiTro=\'ADMIN\' THEN 0 ELSE 1 END, TenVaiTro'))[0].recordset;
}

function isISODate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(value || ''))) return false;
  const d = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === value;
}

function ageAt(birthDate, onDate) {
  const birth = new Date(`${birthDate}T00:00:00Z`);
  const at = new Date(`${onDate}T00:00:00Z`);
  let age = at.getUTCFullYear() - birth.getUTCFullYear();
  const monthDiff = at.getUTCMonth() - birth.getUTCMonth();
  if (monthDiff < 0 || (monthDiff === 0 && at.getUTCDate() < birth.getUTCDate())) age -= 1;
  return age;
}

async function setRoleInTransaction(tx, accountId, role) {
  const request = new sql.Request(tx);
  request.input('accountId', sql.Int, accountId);
  request.input('role', sql.VarChar(30), role);
  const roleCheck = await request.query('SELECT TOP 1 MaVaiTro FROM dbo.VaiTro WHERE MaVaiTro=@role');
  if (!roleCheck.recordset.length) {
    const error = new Error('Vai trò được chọn không tồn tại.');
    error.userMessage = true;
    throw error;
  }
  const assignRequest = new sql.Request(tx);
  assignRequest.input('accountId', sql.Int, accountId);
  assignRequest.input('role', sql.VarChar(30), role);
  await assignRequest.query(`
    IF EXISTS (SELECT 1 FROM dbo.TaiKhoanVaiTro WHERE TaiKhoanId=@accountId)
      UPDATE dbo.TaiKhoanVaiTro SET MaVaiTro=@role WHERE TaiKhoanId=@accountId;
    ELSE
      INSERT dbo.TaiKhoanVaiTro(TaiKhoanId,MaVaiTro) VALUES(@accountId,@role);
  `);
}

function renderAdminEmployeeForm(res, { row = {}, error = null } = {}) {
  return res.status(error ? 400 : 200).render('admin/employee-create', {
    title: 'Thêm hồ sơ nhân viên',
    row,
    error,
    today: new Date().toISOString().slice(0, 10)
  });
}

router.get('/', async (req, res, next) => {
  try {
    const s = await stats();
    return res.render('admin/index', { title: 'Trung tâm quản trị', stats: s });
  } catch (e) { return next(e); }
});

router.get('/employees/new', (req, res) => renderAdminEmployeeForm(res, {
  row: { NgaySinh: '1995-01-01', NgayVaoLam: new Date().toISOString().slice(0, 10), GioiTinh: 'Nam', ChucVu: 'Nhân viên', LuongCoBan: 0 }
}));

router.post('/employees/new', async (req, res) => {
  const row = {
    MaNV: String(req.body.MaNV || '').trim(),
    HoTen: String(req.body.HoTen || '').trim(),
    NgaySinh: String(req.body.NgaySinh || '').trim(),
    GioiTinh: String(req.body.GioiTinh || '').trim(),
    ChucVu: String(req.body.ChucVu || '').trim(),
    NgayVaoLam: String(req.body.NgayVaoLam || '').trim(),
    LuongCoBan: String(req.body.LuongCoBan ?? '').trim()
  };
  if (!/^[A-Za-z0-9_-]{1,10}$/.test(row.MaNV) || !row.HoTen || row.HoTen.length > 100 ||
      !isISODate(row.NgaySinh) || !isISODate(row.NgayVaoLam) || !['Nam', 'Nữ'].includes(row.GioiTinh) ||
      !row.ChucVu || row.ChucVu.length > 50 || row.LuongCoBan === '' || !Number.isFinite(Number(row.LuongCoBan)) || Number(row.LuongCoBan) < 0) {
    return renderAdminEmployeeForm(res, { row, error: 'Vui lòng nhập đủ thông tin hợp lệ. Mã nhân viên tối đa 10 ký tự và lương không âm.' });
  }
  if (new Date(`${row.NgayVaoLam}T00:00:00Z`) < new Date(`${row.NgaySinh}T00:00:00Z`) || ageAt(row.NgaySinh, row.NgayVaoLam) < 18) {
    return renderAdminEmployeeForm(res, { row, error: 'Nhân viên phải đủ 18 tuổi tại ngày vào làm.' });
  }
  try {
    await query(`
      INSERT dbo.NhanVien(MaNV,HoTen,NgaySinh,GioiTinh,ChucVu,LuongCoBan,NgayVaoLam)
      VALUES(@MaNV,@HoTen,@NgaySinh,@GioiTinh,@ChucVu,@Luong,@NgayVaoLam)
    `, [
      { name: 'MaNV', type: sql.VarChar(10), value: row.MaNV },
      { name: 'HoTen', type: sql.NVarChar(100), value: row.HoTen },
      { name: 'NgaySinh', type: sql.Date, value: row.NgaySinh },
      { name: 'GioiTinh', type: sql.NVarChar(3), value: row.GioiTinh },
      { name: 'ChucVu', type: sql.NVarChar(50), value: row.ChucVu },
      { name: 'Luong', type: sql.Decimal(18, 2), value: Number(row.LuongCoBan) },
      { name: 'NgayVaoLam', type: sql.Date, value: row.NgayVaoLam }
    ]);
    return res.redirect('/admin/accounts?employeeCreated=1');
  } catch (e) {
    if (e.number === 2627 || e.number === 2601) {
      return renderAdminEmployeeForm(res, { row, error: 'Mã nhân viên đã tồn tại. Hãy nhập mã khác.' });
    }
    console.error(e);
    return renderAdminEmployeeForm(res, { row, error: 'Không thể thêm nhân viên. Vui lòng kiểm tra dữ liệu và cấu trúc database.' });
  }
});

async function loadUnlinkedEmployees() {
  return (await query(`
    SELECT nv.MaNV, nv.HoTen, nv.ChucVu
    FROM dbo.NhanVien nv
    LEFT JOIN dbo.TaiKhoan tk ON tk.MaNV=nv.MaNV
    WHERE tk.TaiKhoanId IS NULL
    ORDER BY nv.HoTen, nv.MaNV
  `))[0].recordset;
}

router.get('/accounts/new', async (req, res, next) => {
  try {
    const employees = await loadUnlinkedEmployees();
    return res.render('admin/account-create', {
      title: 'Tạo tài khoản nhân viên',
      employees,
      roles: await loadRoleOptions(),
      row: { TrangThai: 'HOAT_DONG' },
      error: null
    });
  } catch (e) { return next(e); }
});

router.post('/accounts/new', async (req, res, next) => {
  const row = {
    MaNV: String(req.body.MaNV || '').trim(),
    TenDangNhap: String(req.body.TenDangNhap || '').trim(),
    MatKhau: String(req.body.MatKhau || ''),
    XacNhanMatKhau: String(req.body.XacNhanMatKhau || ''),
    MaVaiTro: String(req.body.MaVaiTro || '').trim().toUpperCase(),
    TrangThai: String(req.body.TrangThai || 'HOAT_DONG').trim().toUpperCase()
  };
  const renderForm = async (error, status = 400) => res.status(status).render('admin/account-create', {
    title: 'Tạo tài khoản nhân viên',
    employees: await loadUnlinkedEmployees(),
    roles: await loadRoleOptions(), row, error
  });

  if (!/^[A-Za-z0-9._-]{4,50}$/.test(row.TenDangNhap)) return renderForm('Tên đăng nhập phải dài 4–50 ký tự, chỉ gồm chữ không dấu, số, dấu chấm, gạch ngang hoặc gạch dưới.');
  if (row.MatKhau.length < 8) return renderForm('Mật khẩu phải có ít nhất 8 ký tự.');
  if (row.MatKhau !== row.XacNhanMatKhau) return renderForm('Mật khẩu xác nhận không khớp.');
  if (!row.MaNV || !row.MaVaiTro || !['HOAT_DONG', 'KHOA'].includes(row.TrangThai)) return renderForm('Hãy chọn nhân viên, vai trò và trạng thái hợp lệ.');

  let tx;
  try {
    const pool = await getPool();
    tx = new sql.Transaction(pool);
    await tx.begin();

    const employeeRequest = new sql.Request(tx);
    employeeRequest.input('maNV', sql.VarChar(10), row.MaNV);
    const employeeResult = await employeeRequest.query(`
      SELECT nv.MaNV FROM dbo.NhanVien nv WITH (UPDLOCK, HOLDLOCK)
      LEFT JOIN dbo.TaiKhoan tk ON tk.MaNV=nv.MaNV
      WHERE nv.MaNV=@maNV AND tk.TaiKhoanId IS NULL
    `);
    if (!employeeResult.recordset.length) {
      const error = new Error('Nhân viên không tồn tại hoặc đã có tài khoản. Hãy chọn hồ sơ khác.'); error.userMessage = true; throw error;
    }

    const insertRequest = new sql.Request(tx);
    insertRequest.input('username', sql.VarChar(50), row.TenDangNhap);
    insertRequest.input('passwordHash', sql.VarChar(300), hashPassword(row.MatKhau));
    insertRequest.input('maNV', sql.VarChar(10), row.MaNV);
    insertRequest.input('status', sql.VarChar(20), row.TrangThai);
    const inserted = await insertRequest.query(`
      INSERT dbo.TaiKhoan(TenDangNhap, MatKhauHash, MaNV, TrangThai)
      OUTPUT INSERTED.TaiKhoanId
      VALUES(@username, @passwordHash, @maNV, @status)
    `);
    const accountId = inserted.recordset[0].TaiKhoanId;
    await setRoleInTransaction(tx, accountId, row.MaVaiTro);
    await tx.commit();
    return res.redirect('/admin/accounts?accountCreated=1');
  } catch (e) {
    if (tx) { try { await tx.rollback(); } catch (error) { void error; } }
    if (e.userMessage) return renderForm(e.message);
    if (e.number === 2627 || e.number === 2601) return renderForm('Tên đăng nhập hoặc hồ sơ nhân viên đã được sử dụng.');
    console.error(e);
    return next(e);
  }
});

router.get('/accounts', async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim();
    const result = await query(`
      SELECT tk.TaiKhoanId, tk.TenDangNhap, tk.MaNV, tk.TrangThai, tk.NgayTao, tk.LanDangNhapCuoi,
             nv.HoTen, nv.ChucVu,
             vt.MaVaiTro, vt.TenVaiTro, COUNT(vq.MaQuyen) AS SoQuyen
      FROM dbo.TaiKhoan tk
      LEFT JOIN dbo.NhanVien nv ON nv.MaNV=tk.MaNV
      LEFT JOIN dbo.TaiKhoanVaiTro tv ON tv.TaiKhoanId=tk.TaiKhoanId
      LEFT JOIN dbo.VaiTro vt ON vt.MaVaiTro=tv.MaVaiTro
      LEFT JOIN dbo.VaiTroQuyen vq ON vq.MaVaiTro=vt.MaVaiTro
      WHERE (@q='' OR tk.TenDangNhap LIKE '%' + @q + '%' OR tk.MaNV LIKE '%' + @q + '%' OR nv.HoTen LIKE N'%' + @q + N'%')
      GROUP BY tk.TaiKhoanId, tk.TenDangNhap, tk.MaNV, tk.TrangThai, tk.NgayTao, tk.LanDangNhapCuoi,
               nv.HoTen, nv.ChucVu, vt.MaVaiTro, vt.TenVaiTro
      ORDER BY CASE tk.TrangThai WHEN 'HOAT_DONG' THEN 0 WHEN 'KHOA' THEN 1 ELSE 2 END, tk.TenDangNhap
    `, [{ name: 'q', type: sql.NVarChar(100), value: q }]);
    return res.render('admin/accounts', {
      title: 'Quản lý tài khoản',
      rows: result[0].recordset,
      roles: await loadRoleOptions(),
      stats: await stats(),
      q,
      currentAccountId: req.user.TaiKhoanId,
      employeeCreated: req.query.employeeCreated === '1',
      accountCreated: req.query.accountCreated === '1'
    });
  } catch (e) { return next(e); }
});

router.post('/accounts/:id/role', async (req, res, next) => {
  const id = Number(req.params.id);
  const role = String(req.body.MaVaiTro || '').trim();
  if (!Number.isInteger(id) || !role) return res.status(400).send('Dữ liệu không hợp lệ.');

  // Không cho Admin tự đổi vai trò của chính mình: route phía dưới sẽ thu hồi
  // session của tài khoản được sửa để buộc tài khoản đó đăng nhập lại.
  if (id === Number(req.user?.TaiKhoanId)) {
    return res.status(400).render('error', {
      title: 'Không thể tự đổi vai trò',
      message: 'Bạn đang đăng nhập bằng tài khoản này. Để tránh mất phiên đăng nhập hoặc tự thu hồi quyền quản trị, hãy dùng một tài khoản Admin khác để đổi vai trò.'
    });
  }

  try {
    const accountResult = await query(`SELECT MaNV,TrangThai FROM dbo.TaiKhoan WHERE TaiKhoanId=@id`, [
      { name: 'id', type: sql.Int, value: id }
    ]);
    const account = accountResult[0].recordset[0];
    if (!account || !account.MaNV || account.TrangThai === 'CHO_DUYET') {
      return res.status(400).render('error', {
        title: 'Không thể gán vai trò',
        message: 'Tài khoản cũ chưa gắn hồ sơ nhân viên không thể được kích hoạt. Hãy tạo hồ sơ nhân viên và tạo tài khoản mới từ khu vực Admin.'
      });
    }
    await query(`
      IF EXISTS (SELECT 1 FROM dbo.TaiKhoanVaiTro WHERE TaiKhoanId=@id)
        UPDATE dbo.TaiKhoanVaiTro SET MaVaiTro=@role WHERE TaiKhoanId=@id;
      ELSE
        INSERT dbo.TaiKhoanVaiTro(TaiKhoanId,MaVaiTro) VALUES(@id,@role);
    `, [
      { name: 'id', type: sql.Int, value: id },
      { name: 'role', type: sql.VarChar(30), value: role }
    ]);
    destroySessionsForAccount(id);
    return res.redirect('/admin/accounts');
  } catch (e) { return next(e); }
});

router.post('/accounts/:id/status', async (req, res, next) => {
  const id = Number(req.params.id);
  const status = String(req.body.TrangThai || '').trim();
  if (!Number.isInteger(id) || !['HOAT_DONG', 'KHOA'].includes(status)) return res.status(400).send('Trạng thái không hợp lệ.');
  if (id === Number(req.user.TaiKhoanId) && status === 'KHOA') {
    return res.status(400).render('error', { title: 'Không thể khóa', message: 'Bạn không thể tự khóa tài khoản đang đăng nhập.' });
  }
  try {
    const changed = await query("UPDATE dbo.TaiKhoan SET TrangThai=@status WHERE TaiKhoanId=@id AND MaNV IS NOT NULL AND TrangThai<>'CHO_DUYET'", [
      { name: 'status', type: sql.VarChar(20), value: status },
      { name: 'id', type: sql.Int, value: id }
    ]);
    if (!changed[0].rowsAffected?.[0]) return res.status(400).render('error', { title: 'Không thể thay đổi trạng thái', message: 'Tài khoản chưa được liên kết với hồ sơ nhân viên. Hãy tạo tài khoản mới từ khu vực Admin.' });
    destroySessionsForAccount(id);
    return res.redirect('/admin/accounts');
  } catch (e) { return next(e); }
});

router.post('/accounts/:id/reset-password', async (req, res, next) => {
  const id = Number(req.params.id);
  const newPassword = String(req.body.MatKhauMoi || '');
  if (!Number.isInteger(id) || newPassword.length < 8) return res.status(400).send('Mật khẩu mới phải có ít nhất 8 ký tự.');
  try {
    const changed = await query(`UPDATE dbo.TaiKhoan SET MatKhauHash=@h WHERE TaiKhoanId=@id AND MaNV IS NOT NULL AND TrangThai<>'CHO_DUYET'`, [
      { name: 'h', type: sql.VarChar(300), value: hashPassword(newPassword) },
      { name: 'id', type: sql.Int, value: id }
    ]);
    if (!changed[0].rowsAffected?.[0]) return res.status(400).render('error', {
      title: 'Không thể đặt lại mật khẩu',
      message: 'Tài khoản cũ chưa gắn hồ sơ nhân viên. Hãy tạo tài khoản mới từ khu vực Admin.'
    });
    destroySessionsForAccount(id);
    return res.redirect('/admin/accounts');
  } catch (e) { return next(e); }
});

router.get('/roles', async (req, res, next) => {
  try {
    const roles = await loadRoleOptions();
    const selectedCode = roles.some(r => r.MaVaiTro === req.query.role) ? req.query.role : roles[0]?.MaVaiTro;
    const permissions = (await query('SELECT MaQuyen,TenQuyen,NhomQuyen,MoTa FROM dbo.Quyen ORDER BY NhomQuyen,MaQuyen'))[0].recordset;
    const selected = (await query('SELECT MaQuyen FROM dbo.VaiTroQuyen WHERE MaVaiTro=@role', [
      { name: 'role', type: sql.VarChar(30), value: selectedCode }
    ]))[0].recordset.map(x => x.MaQuyen);
    return res.render('admin/roles', {
      title: 'Phân quyền',
      roles,
      permissions,
      selectedCode,
      selectedPermissions: selected
    });
  } catch (e) { return next(e); }
});

router.post('/roles/create', async (req, res, next) => {
  const code = String(req.body.MaVaiTro || '').trim().toUpperCase();
  const name = String(req.body.TenVaiTro || '').trim();
  const desc = String(req.body.MoTa || '').trim();
  if (!/^[A-Z0-9_-]{2,30}$/.test(code) || !name) return res.status(400).send('Mã vai trò không hợp lệ hoặc chưa nhập tên.');
  try {
    await query('INSERT dbo.VaiTro(MaVaiTro,TenVaiTro,MoTa) VALUES(@code,@name,@desc)', [
      { name: 'code', type: sql.VarChar(30), value: code },
      { name: 'name', type: sql.NVarChar(80), value: name },
      { name: 'desc', type: sql.NVarChar(255), value: desc || null }
    ]);
    return res.redirect(`/admin/roles?role=${encodeURIComponent(code)}`);
  } catch (e) { return next(e); }
});

router.post('/roles/:code/permissions', async (req, res, next) => {
  const code = String(req.params.code || '').trim().toUpperCase();
  const selected = Array.isArray(req.body.permissions) ? req.body.permissions : (req.body.permissions ? [req.body.permissions] : []);
  // Mọi vai trò hoạt động đều giữ quyền tổng quan để sau đăng nhập luôn có trang đích.
  if (!selected.includes('dashboard.view')) selected.push('dashboard.view');
  if (code === 'ADMIN' && !selected.includes('accounts.manage')) selected.push('accounts.manage');
  if (code === 'ADMIN' && !selected.includes('roles.manage')) selected.push('roles.manage');

  try {
    const pool = await getPool();
    const tx = new sql.Transaction(pool);
    await tx.begin();
    try {
      const del = new sql.Request(tx);
      del.input('role', sql.VarChar(30), code);
      await del.query('DELETE FROM dbo.VaiTroQuyen WHERE MaVaiTro=@role');
      for (const permission of selected) {
        const ins = new sql.Request(tx);
        ins.input('role', sql.VarChar(30), code);
        ins.input('perm', sql.VarChar(80), permission);
        await ins.query('INSERT dbo.VaiTroQuyen(MaVaiTro,MaQuyen) SELECT @role,@perm WHERE EXISTS(SELECT 1 FROM dbo.Quyen WHERE MaQuyen=@perm)');
      }
      await tx.commit();
    } catch (e) {
      await tx.rollback();
      throw e;
    }
    destroySessionsForRole(code);
    return res.redirect(`/admin/roles?role=${encodeURIComponent(code)}&saved=1`);
  } catch (e) { return next(e); }
});

module.exports = router;
