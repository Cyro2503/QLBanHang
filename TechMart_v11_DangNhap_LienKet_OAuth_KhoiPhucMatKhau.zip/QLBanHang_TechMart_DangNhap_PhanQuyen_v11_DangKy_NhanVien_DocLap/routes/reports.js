const express = require('express');
const { sql, query, getPool } = require('../config/db');

const router = express.Router();

function compactStatusText(columnExpr) {
  return `LOWER(REPLACE(REPLACE(REPLACE(REPLACE(CAST(${columnExpr} AS NVARCHAR(200)), N' ', N''), N'?', N''), N'Đ', N'd'), N'đ', N'd'))`;
}

function paidStatusSql(columnName) {
  const compact = compactStatusText(columnName);
  return `(
    ${columnName} = N'Đã thanh toán'
    OR ${compact} LIKE N'%dathanhtoan%'
  )`;
}

function cancelledStatusSql(columnName) {
  const compact = compactStatusText(columnName);
  return `(
    ${columnName} = N'Đã hủy'
    OR ${compact} LIKE N'%dahuy%'
  )`;
}

function pad2(value) {
  return String(value).padStart(2, '0');
}

function toDateInput(date) {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

function defaultPeriod() {
  const to = new Date();
  const from = new Date(to);
  from.setDate(from.getDate() - 29);
  return { from: toDateInput(from), to: toDateInput(to) };
}

function rowsOf(result) {
  if (Array.isArray(result) && result[0] && Array.isArray(result[0].recordset)) {
    return result[0].recordset;
  }
  if (result && Array.isArray(result.recordset)) {
    return result.recordset;
  }
  if (Array.isArray(result)) {
    return result;
  }
  return [];
}

function getDateRange(req) {
  const defaults = defaultPeriod();
  const from = req.query.from || defaults.from;
  const to = req.query.to || defaults.to;

  if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) {
    return { error: 'Ngày phải có dạng YYYY-MM-DD.' };
  }

  if (from > to) {
    return { error: 'Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc.' };
  }

  return { from, to };
}

router.get('/', async (req, res, next) => {
  try {
    const range = getDateRange(req);

    if (range.error) {
      return res.status(400).render('error', {
        title: 'Khoảng ngày không hợp lệ',
        message: range.error
      });
    }

    const { from, to } = range;
    let top = Number(req.query.top || 10);
    if (!Number.isInteger(top)) top = 10;
    top = Math.min(Math.max(top, 1), 20);

    const paidInvoiceWhere = paidStatusSql('hd.TrangThai');
    const cancelledInvoiceWhere = cancelledStatusSql('hd.TrangThai');

    const dateParams = [
      { name: 'TuNgay', type: sql.Date, value: from },
      { name: 'DenNgay', type: sql.Date, value: to }
    ];

    const [summaryResult, averageResult, dailyResult, monthlyResult, productsResult, hotQuantityResult, hotRevenueResult, potentialResult] = await Promise.all([
      query(`
        SELECT
          COUNT(DISTINCT CASE WHEN ${paidInvoiceWhere} THEN hd.SoHD END) AS SoHoaDonThanhToan,
          COUNT(DISTINCT CASE WHEN ${cancelledInvoiceWhere} THEN hd.SoHD END) AS SoHoaDonHuy,
          COUNT(DISTINCT CASE WHEN ${paidInvoiceWhere} THEN hd.MaKH END) AS SoKhachMua,
          ISNULL(SUM(CASE
            WHEN ${paidInvoiceWhere} THEN ct.SoLuong ELSE 0 END), 0) AS SoLuongBan,
          ISNULL(SUM(CASE
            WHEN ${paidInvoiceWhere} THEN ct.SoLuong * ct.DonGiaBan * (1 - ct.PhanTramGiam / 100.0)
            ELSE 0 END), 0) AS DoanhThu
        FROM dbo.HoaDon hd
        LEFT JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = hd.SoHD
        WHERE hd.NgayLap >= @TuNgay
          AND hd.NgayLap < DATEADD(DAY, 1, @DenNgay)
      `, dateParams),

      query(`
        SELECT ISNULL(AVG(x.TongTien), 0) AS HoaDonTrungBinh
        FROM (
          SELECT
            hd.SoHD,
            SUM(ct.SoLuong * ct.DonGiaBan * (1 - ct.PhanTramGiam / 100.0)) AS TongTien
          FROM dbo.HoaDon hd
          JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = hd.SoHD
          WHERE ${paidInvoiceWhere}
            AND hd.NgayLap >= @TuNgay
            AND hd.NgayLap < DATEADD(DAY, 1, @DenNgay)
          GROUP BY hd.SoHD
        ) x
      `, dateParams),

      query(`
        SELECT
          CAST(hd.NgayLap AS DATE) AS Ngay,
          COUNT(DISTINCT hd.SoHD) AS SoHoaDon,
          SUM(ct.SoLuong) AS SoLuongBan,
          SUM(ct.SoLuong * ct.DonGiaBan * (1 - ct.PhanTramGiam / 100.0)) AS DoanhThu
        FROM dbo.HoaDon hd
        JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = hd.SoHD
        WHERE ${paidInvoiceWhere}
          AND hd.NgayLap >= @TuNgay
          AND hd.NgayLap < DATEADD(DAY, 1, @DenNgay)
        GROUP BY CAST(hd.NgayLap AS DATE)
        ORDER BY Ngay DESC
      `, dateParams),

      query(`
        SELECT
          YEAR(hd.NgayLap) AS Nam,
          MONTH(hd.NgayLap) AS Thang,
          COUNT(DISTINCT hd.SoHD) AS SoHoaDon,
          SUM(ct.SoLuong) AS SoLuongBan,
          SUM(ct.SoLuong * ct.DonGiaBan * (1 - ct.PhanTramGiam / 100.0)) AS DoanhThu
        FROM dbo.HoaDon hd
        JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = hd.SoHD
        WHERE ${paidInvoiceWhere}
          AND hd.NgayLap >= @TuNgay
          AND hd.NgayLap < DATEADD(DAY, 1, @DenNgay)
        GROUP BY YEAR(hd.NgayLap), MONTH(hd.NgayLap)
        ORDER BY Nam DESC, Thang DESC
      `, dateParams),

      query(`
        SELECT
          sp.MaSP,
          sp.TenSP,
          sp.SoLuongTon,
          SUM(ct.SoLuong) AS SoLuongBan,
          SUM(ct.SoLuong * ct.DonGiaBan * (1 - ct.PhanTramGiam / 100.0)) AS DoanhThu
        FROM dbo.ChiTietHoaDon ct
        JOIN dbo.HoaDon hd ON hd.SoHD = ct.SoHD
        JOIN dbo.SanPham sp ON sp.MaSP = ct.MaSP
        WHERE ${paidInvoiceWhere}
          AND hd.NgayLap >= @TuNgay
          AND hd.NgayLap < DATEADD(DAY, 1, @DenNgay)
        GROUP BY sp.MaSP, sp.TenSP, sp.SoLuongTon
        ORDER BY DoanhThu DESC, SoLuongBan DESC
      `, dateParams),

      query(`
        SELECT TOP (@N)
          sp.MaSP,
          sp.TenSP,
          sp.SoLuongTon,
          SUM(ct.SoLuong) AS SoLuongBan,
          SUM(ct.SoLuong * ct.DonGiaBan * (1 - ct.PhanTramGiam / 100.0)) AS DoanhThu
        FROM dbo.ChiTietHoaDon ct
        JOIN dbo.HoaDon hd ON hd.SoHD = ct.SoHD
        JOIN dbo.SanPham sp ON sp.MaSP = ct.MaSP
        WHERE ${paidInvoiceWhere}
          AND hd.NgayLap >= @TuNgay
          AND hd.NgayLap < DATEADD(DAY, 1, @DenNgay)
        GROUP BY sp.MaSP, sp.TenSP, sp.SoLuongTon
        ORDER BY SoLuongBan DESC, DoanhThu DESC
      `, [{ name: 'N', type: sql.Int, value: top }, ...dateParams]),

      query(`
        SELECT TOP (@N)
          sp.MaSP,
          sp.TenSP,
          sp.SoLuongTon,
          SUM(ct.SoLuong) AS SoLuongBan,
          SUM(ct.SoLuong * ct.DonGiaBan * (1 - ct.PhanTramGiam / 100.0)) AS DoanhThu
        FROM dbo.ChiTietHoaDon ct
        JOIN dbo.HoaDon hd ON hd.SoHD = ct.SoHD
        JOIN dbo.SanPham sp ON sp.MaSP = ct.MaSP
        WHERE ${paidInvoiceWhere}
          AND hd.NgayLap >= @TuNgay
          AND hd.NgayLap < DATEADD(DAY, 1, @DenNgay)
        GROUP BY sp.MaSP, sp.TenSP, sp.SoLuongTon
        ORDER BY DoanhThu DESC, SoLuongBan DESC
      `, [{ name: 'N', type: sql.Int, value: top }, ...dateParams]),

      query(`
        WITH Sales AS (
          SELECT
            sp.MaSP,
            sp.TenSP,
            sp.SoLuongTon,
            SUM(ct.SoLuong) AS SoLuongBan,
            SUM(ct.SoLuong * ct.DonGiaBan * (1 - ct.PhanTramGiam / 100.0)) AS DoanhThu
          FROM dbo.ChiTietHoaDon ct
          JOIN dbo.HoaDon hd ON hd.SoHD = ct.SoHD
          JOIN dbo.SanPham sp ON sp.MaSP = ct.MaSP
          WHERE ${paidInvoiceWhere}
            AND hd.NgayLap >= @TuNgay
            AND hd.NgayLap < DATEADD(DAY, 1, @DenNgay)
          GROUP BY sp.MaSP, sp.TenSP, sp.SoLuongTon
        ), Ranked AS (
          SELECT
            *,
            CAST(
              100.0 * SoLuongBan / NULLIF(MAX(SoLuongBan) OVER (), 0) * 0.60
              + 100.0 * DoanhThu / NULLIF(MAX(DoanhThu) OVER (), 0) * 0.40
              AS DECIMAL(6,2)
            ) AS DiemTiemNang
          FROM Sales
          WHERE SoLuongBan > 0
            AND SoLuongTon > 0
        )
        SELECT TOP (@N)
          MaSP,
          TenSP,
          SoLuongTon,
          SoLuongBan,
          DoanhThu,
          DiemTiemNang,
          CASE
            WHEN SoLuongTon <= 10 THEN N'Bán tốt - nên nhập thêm'
            WHEN SoLuongTon <= 50 THEN N'Có nhu cầu - theo dõi tồn'
            ELSE N'Dư địa tốt'
          END AS DanhGia
        FROM Ranked
        ORDER BY DiemTiemNang DESC, SoLuongBan DESC, DoanhThu DESC
      `, [{ name: 'N', type: sql.Int, value: top }, ...dateParams])
    ]);

    const summary = rowsOf(summaryResult)[0] || {
      SoHoaDonThanhToan: 0,
      SoHoaDonHuy: 0,
      SoKhachMua: 0,
      SoLuongBan: 0,
      DoanhThu: 0
    };

    summary.HoaDonTrungBinh = rowsOf(averageResult)[0]?.HoaDonTrungBinh || 0;

    const daily = rowsOf(dailyResult);
    const monthly = rowsOf(monthlyResult);
    const products = rowsOf(productsResult);
    const hotByQuantityRaw = rowsOf(hotQuantityResult);
    const hotByRevenueRaw = rowsOf(hotRevenueResult);
    const potential = rowsOf(potentialResult);

    const maxHotQuantity = Math.max(
      ...Array.isArray(hotByQuantityRaw) ? hotByQuantityRaw.map(x => Number(x?.SoLuongBan) || 0) : [0],
      1
    );

    const maxHotRevenue = Math.max(
      ...Array.isArray(hotByRevenueRaw) ? hotByRevenueRaw.map(x => Number(x?.DoanhThu) || 0) : [0],
      1
    );

    const decorate = rows => (Array.isArray(rows) ? rows : []).map(row => ({
      ...row,
      quantityPercent: Math.round((Number(row?.SoLuongBan) || 0) / maxHotQuantity * 100),
      revenuePercent: Math.round((Number(row?.DoanhThu) || 0) / maxHotRevenue * 100)
    }));

    return res.render('reports/index', {
      title: 'Báo cáo kinh doanh',
      from,
      to,
      topN: top,
      summary,
      daily,
      monthly,
      products,
      hotByQuantity: decorate(hotByQuantityRaw),
      hotByRevenue: decorate(hotByRevenueRaw),
      potential
    });
  } catch (error) {
    console.error('REPORT ERROR:', error);
    next(error);
  }
});

router.get('/range', async (req, res, next) => {
  try {
    const range = getDateRange(req);

    if (range.error) {
      return res.status(400).render('error', {
        title: 'Khoảng ngày không hợp lệ',
        message: range.error
      });
    }

    const { from, to } = range;
    const pool = await getPool();
    const request = pool.request();

    request.input('TuNgay', sql.Date, from);
    request.input('DenNgay', sql.Date, to);
    request.output('TongDoanhThu', sql.Decimal(18, 2));

    const result = await request.execute('dbo.sp_BaoCaoDoanhThu');

    return res.render('reports/range', {
      title: 'Doanh thu theo khoảng ngày',
      from,
      to,
      total: result.output?.TongDoanhThu || 0,
      rows: result.recordset || []
    });
  } catch (error) {
    console.error('REPORT RANGE ERROR:', error);
    next(error);
  }
});

module.exports = router;
