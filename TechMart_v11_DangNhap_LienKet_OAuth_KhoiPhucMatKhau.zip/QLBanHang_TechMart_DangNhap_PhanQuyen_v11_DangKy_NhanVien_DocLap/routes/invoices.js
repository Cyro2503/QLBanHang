const express = require('express');
const { sql, getPool, query } = require('../config/db');
const { required, positiveInt, positiveNumber, nonNegativeNumber } = require('../utils/validation');

const router = express.Router();

function normalizeInvoiceStatus(value) {
  return String(value ?? '')
    .trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .replace(/[^a-zA-Z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .toLowerCase();
}

function classifyInvoiceStatus(value) {
  const text = normalizeInvoiceStatus(value);
  if (!text) return 'unknown';
  if (text.includes('cho') && text.includes('thanh') && (text.includes('toan') || text.includes('to'))) return 'pending';
  if (text.includes('da') && text.includes('thanh') && text.includes('toan')) return 'paid';
  if ((text.includes('da') && text.includes('huy')) || text.includes('huy')) return 'cancelled';
  return 'unknown';
}

async function loadLists() {
  const [customers, employees, products] = await Promise.all([
    query('SELECT MaKH,HoTen FROM dbo.KhachHang ORDER BY MaKH'),
    query('SELECT MaNV,HoTen FROM dbo.NhanVien ORDER BY MaNV'),
    query('SELECT MaSP,TenSP,GiaBan,SoLuongTon FROM dbo.SanPham ORDER BY MaSP')
  ]);
  return { customers: customers[0].recordset, employees: employees[0].recordset, products: products[0].recordset };
}

router.get('/', async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim();
    const status = String(req.query.status || '').trim();
    const from = /^\d{4}-\d{2}-\d{2}$/.test(req.query.from || '') ? req.query.from : '';
    const to = /^\d{4}-\d{2}-\d{2}$/.test(req.query.to || '') ? req.query.to : '';
    const pageSize = [20, 50, 100].includes(Number(req.query.size)) ? Number(req.query.size) : 20;
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const params = [
      { name: 'q', type: sql.NVarChar(200), value: `%${q}%` },
      { name: 'status', type: sql.NVarChar(30), value: status },
      { name: 'fromDate', type: sql.Date, value: from || null },
      { name: 'toDate', type: sql.Date, value: to || null }
    ];
    const joins = `FROM dbo.HoaDon hd JOIN dbo.KhachHang kh ON kh.MaKH=hd.MaKH JOIN dbo.NhanVien nv ON nv.MaNV=hd.MaNV`;
    const where = `WHERE (@q='%%' OR hd.SoHD LIKE @q OR kh.HoTen LIKE @q OR kh.MaKH LIKE @q OR nv.HoTen LIKE @q OR nv.MaNV LIKE @q) AND (@status='' OR hd.TrangThai=@status) AND (@fromDate IS NULL OR hd.NgayLap >= @fromDate) AND (@toDate IS NULL OR hd.NgayLap < DATEADD(day,1,@toDate))`;
    const count = await query(`SELECT COUNT(*) AS Total ${joins} ${where}`, params);
    const total = Number(count[0].recordset[0].Total || 0);
    const pages = Math.max(1, Math.ceil(total / pageSize));
    const currentPage = Math.min(page, pages);
    const r = await query(`
      SELECT hd.SoHD,hd.NgayLap,hd.MaKH,kh.HoTen AS TenKhachHang,hd.MaNV,nv.HoTen AS TenNhanVien,hd.TrangThai,
             ISNULL(t.TongTien,0) AS TongTien
      ${joins}
      OUTER APPLY (SELECT SUM(ct.SoLuong*ct.DonGiaBan*(1-ct.PhanTramGiam/100.0)) AS TongTien FROM dbo.ChiTietHoaDon ct WHERE ct.SoHD=hd.SoHD) t
      ${where}
      ORDER BY hd.NgayLap DESC,hd.SoHD DESC OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY
    `, [...params, { name: 'Offset', type: sql.Int, value: (currentPage - 1) * pageSize }, { name: 'PageSize', type: sql.Int, value: pageSize }]);
    res.render('invoices/index', { title: 'Hóa đơn', rows: r[0].recordset, q, status, from, to, page: currentPage, pages, pageSize, total });
  } catch (e) { next(e); }
});

router.get('/create', async (req, res, next) => {
  try {
    const lists = await loadLists();
    res.render('invoices/create', { title: 'Lập hóa đơn', ...lists, error: null, form: { MaKH: '', MaNV: '', Lines: [{}] } });
  } catch (e) { next(e); }
});

router.post('/create', async (req, res) => {
  const lists = await loadLists();
  const form = req.body;
  let lines = form.MaSP || [];
  if (!Array.isArray(lines)) lines = [lines];
  const qty = Array.isArray(form.SoLuong) ? form.SoLuong : [form.SoLuong];
  const prices = Array.isArray(form.DonGiaBan) ? form.DonGiaBan : [form.DonGiaBan];
  const discounts = Array.isArray(form.PhanTramGiam) ? form.PhanTramGiam : [form.PhanTramGiam];
  const detailLines = lines.map((MaSP, i) => ({ MaSP, SoLuong: qty[i], DonGiaBan: prices[i], PhanTramGiam: discounts[i] })).filter(x => required(x.MaSP));
  form.Lines = detailLines;

  if (!required(form.MaKH) || !required(form.MaNV) || detailLines.length === 0) {
    return res.render('invoices/create', { title: 'Lập hóa đơn', ...lists, error: 'Phải chọn khách hàng, nhân viên và ít nhất một sản phẩm.', form });
  }

  for (const line of detailLines) {
    if (!positiveInt(line.SoLuong) || !positiveNumber(line.DonGiaBan) || !nonNegativeNumber(line.PhanTramGiam) || Number(line.PhanTramGiam) > 50) {
      return res.render('invoices/create', { title: 'Lập hóa đơn', ...lists, error: 'Chi tiết hóa đơn không hợp lệ: số lượng > 0, giá > 0, giảm giá 0–50%.', form });
    }
  }

  try {
    const pool = await getPool();
    const request = pool.request();
    request.input('MaKH', sql.VarChar(10), form.MaKH);
    request.input('MaNV', sql.VarChar(10), form.MaNV);

    const tvp = new sql.Table('dbo.TVP_ChiTietHoaDon');
    tvp.columns.add('MaSP', sql.VarChar(10), { nullable: false });
    tvp.columns.add('SoLuong', sql.Int, { nullable: false });
    tvp.columns.add('DonGiaBan', sql.Decimal(18, 2), { nullable: false });
    tvp.columns.add('PhanTramGiam', sql.Decimal(5, 2), { nullable: false });

    for (const line of detailLines) {
      tvp.rows.add(line.MaSP, Number(line.SoLuong), Number(line.DonGiaBan), Number(line.PhanTramGiam || 0));
    }

    request.input('ChiTiet', tvp);
    const result = await request.execute('dbo.sp_LapHoaDon');
    const row = result.recordset?.[0];
    if (row?.SoHD) return res.redirect(`/invoices/${encodeURIComponent(row.SoHD)}`);
    return res.redirect('/invoices');
  } catch (e) {
    return res.render('invoices/create', { title: 'Lập hóa đơn', ...lists, error: e.message, form });
  }
});

router.get('/:id', async (req, res, next) => {
  try {
    const h = await query(`
      SELECT hd.SoHD,hd.NgayLap,hd.MaKH,kh.HoTen AS TenKhachHang,
             hd.MaNV,nv.HoTen AS TenNhanVien,hd.TrangThai,
             ISNULL(SUM(ct.SoLuong*ct.DonGiaBan*(1-ct.PhanTramGiam/100.0)),0) AS TongTien
      FROM dbo.HoaDon hd
      JOIN dbo.KhachHang kh ON kh.MaKH=hd.MaKH
      JOIN dbo.NhanVien nv ON nv.MaNV=hd.MaNV
      LEFT JOIN dbo.ChiTietHoaDon ct ON ct.SoHD=hd.SoHD
      WHERE hd.SoHD=@id
      GROUP BY hd.SoHD,hd.NgayLap,hd.MaKH,kh.HoTen,hd.MaNV,nv.HoTen,hd.TrangThai
    `, [{ name: 'id', type: sql.VarChar(10), value: req.params.id }]);

    const invoice = h[0].recordset[0];
    if (!invoice) return res.status(404).render('error', { title: 'Không tìm thấy', message: 'Hóa đơn không tồn tại.' });

    const lines = await query(`
      SELECT ct.SoHD,ct.MaSP,sp.TenSP,ct.SoLuong,ct.DonGiaBan,ct.PhanTramGiam,
             ct.SoLuong*ct.DonGiaBan*(1-ct.PhanTramGiam/100.0) AS ThanhTien
      FROM dbo.ChiTietHoaDon ct
      JOIN dbo.SanPham sp ON sp.MaSP=ct.MaSP
      WHERE ct.SoHD=@id
      ORDER BY ct.MaSP
    `, [{ name: 'id', type: sql.VarChar(10), value: req.params.id }]);

    res.render('invoices/details', { title: `Hóa đơn ${invoice.SoHD}`, invoice, lines: lines[0].recordset });
  } catch (e) { next(e); }
});

router.post('/:id/pay', async (req, res) => {
  try {
    const invoiceRow = await query(`SELECT SoHD, TrangThai FROM dbo.HoaDon WHERE SoHD=@id`, [
      { name: 'id', type: sql.VarChar(10), value: req.params.id }
    ]);
    const invoice = invoiceRow?.[0]?.recordset?.[0];
    if (!invoice) {
      return res.status(404).render('error', { title: 'Không tìm thấy', message: 'Hóa đơn không tồn tại.' });
    }
    if (classifyInvoiceStatus(invoice.TrangThai) !== 'pending') {
      return res.redirect(`/invoices/${encodeURIComponent(req.params.id)}`);
    }

    await query(`UPDATE dbo.HoaDon SET TrangThai=N'Đã thanh toán' WHERE SoHD=@id`, [
      { name: 'id', type: sql.VarChar(10), value: req.params.id }
    ]);
    res.redirect(`/invoices/${encodeURIComponent(req.params.id)}`);
  } catch (e) {
    res.render('error', { title: 'Không thể xác nhận thanh toán', message: e.message });
  }
});

router.post('/:id/cancel', async (req, res) => {
  try {
    const invoiceRow = await query(`SELECT SoHD, TrangThai FROM dbo.HoaDon WHERE SoHD=@id`, [
      { name: 'id', type: sql.VarChar(10), value: req.params.id }
    ]);
    const invoice = invoiceRow?.[0]?.recordset?.[0];
    if (!invoice) {
      return res.status(404).render('error', { title: 'Không tìm thấy', message: 'Hóa đơn không tồn tại.' });
    }
    if (classifyInvoiceStatus(invoice.TrangThai) === 'cancelled') {
      return res.redirect(`/invoices/${encodeURIComponent(req.params.id)}`);
    }

    await query(`UPDATE dbo.HoaDon SET TrangThai=N'Đã hủy' WHERE SoHD=@id`, [
      { name: 'id', type: sql.VarChar(10), value: req.params.id }
    ]);
    res.redirect(`/invoices/${encodeURIComponent(req.params.id)}`);
  } catch (e) {
    res.render('error', { title: 'Không thể hủy hóa đơn', message: e.message });
  }
});

module.exports = router;
