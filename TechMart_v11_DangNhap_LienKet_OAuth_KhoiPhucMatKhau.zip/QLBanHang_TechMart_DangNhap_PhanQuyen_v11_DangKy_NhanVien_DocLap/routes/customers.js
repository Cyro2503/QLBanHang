const express = require('express');
const { sql, query, procedure } = require('../config/db');
const { required } = require('../utils/validation');

const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim();
    const pageSize = [20, 50, 100].includes(Number(req.query.size)) ? Number(req.query.size) : 20;
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const params = [{ name: 'q', type: sql.NVarChar(200), value: `%${q}%` }];
    const where = `WHERE (@q = '%%' OR MaKH LIKE @q OR HoTen LIKE @q OR SoDienThoai LIKE @q OR ISNULL(Email,'') LIKE @q OR ISNULL(DiaChi,'') LIKE @q)`;
    const count = await query(`SELECT COUNT(*) AS Total FROM dbo.KhachHang ${where}`, params);
    const total = Number(count[0].recordset[0].Total || 0);
    const pages = Math.max(1, Math.ceil(total / pageSize));
    const currentPage = Math.min(page, pages);
    const r = await query(`SELECT MaKH,HoTen,SoDienThoai,Email,DiaChi,NgayDangKy,HangThanhVien FROM dbo.KhachHang ${where} ORDER BY HoTen,MaKH OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY`, [
      ...params,
      { name: 'Offset', type: sql.Int, value: (currentPage - 1) * pageSize },
      { name: 'PageSize', type: sql.Int, value: pageSize }
    ]);
    res.render('customers/index', { title: 'Khách hàng', rows: r[0].recordset, q, page: currentPage, pages, pageSize, total });
  } catch (e) { next(e); }
});

router.get('/create', (req, res) => res.render('customers/form', { title: 'Thêm khách hàng', action: '/customers/create', row: {}, error: null }));

router.post('/create', async (req, res) => {
  const { HoTen, SoDienThoai, Email, DiaChi, NgayDangKy } = req.body;
  if (!required(HoTen) || !required(SoDienThoai)) {
    return res.render('customers/form', { title: 'Thêm khách hàng', action: '/customers/create', row: req.body, error: 'Họ tên và số điện thoại là bắt buộc.' });
  }
  try {
    await procedure('dbo.sp_ThemKhachHang', [
      { name: 'HoTen', type: sql.NVarChar(100), value: HoTen },
      { name: 'SoDienThoai', type: sql.VarChar(15), value: SoDienThoai },
      { name: 'Email', type: sql.VarChar(100), value: Email || null },
      { name: 'DiaChi', type: sql.NVarChar(255), value: DiaChi || null },
      { name: 'NgayDangKy', type: sql.Date, value: NgayDangKy || null }
    ]);
    res.redirect('/customers');
  } catch (e) {
    res.render('customers/form', { title: 'Thêm khách hàng', action: '/customers/create', row: req.body, error: e.message });
  }
});

router.get('/edit/:id', async (req, res, next) => {
  try {
    const r = await query('SELECT MaKH,HoTen,SoDienThoai,Email,DiaChi,NgayDangKy FROM dbo.KhachHang WHERE MaKH=@id', [
      { name: 'id', type: sql.VarChar(10), value: req.params.id }
    ]);
    const row = r[0].recordset[0];
    if (!row) return res.status(404).render('error', { title: 'Không tìm thấy', message: 'Khách hàng không tồn tại.' });
    res.render('customers/form', { title: 'Sửa khách hàng', action: `/customers/edit/${encodeURIComponent(req.params.id)}`, row, error: null });
  } catch (e) { next(e); }
});

router.post('/edit/:id', async (req, res) => {
  try {
    await query(`UPDATE dbo.KhachHang SET HoTen=@HoTen,SoDienThoai=@Phone,Email=@Email,DiaChi=@Addr,NgayDangKy=ISNULL(@NgayDangKy,NgayDangKy) WHERE MaKH=@MaKH`, [
      { name: 'HoTen', type: sql.NVarChar(100), value: req.body.HoTen },
      { name: 'Phone', type: sql.VarChar(15), value: req.body.SoDienThoai },
      { name: 'Email', type: sql.VarChar(100), value: req.body.Email || null },
      { name: 'Addr', type: sql.NVarChar(255), value: req.body.DiaChi || null },
      { name: 'NgayDangKy', type: sql.Date, value: req.body.NgayDangKy || null },
      { name: 'MaKH', type: sql.VarChar(10), value: req.params.id }
    ]);
    res.redirect('/customers');
  } catch (e) {
    res.render('customers/form', { title: 'Sửa khách hàng', action: `/customers/edit/${encodeURIComponent(req.params.id)}`, row: { ...req.body, MaKH: req.params.id }, error: e.message });
  }
});

router.post('/delete/:id', async (req, res) => {
  try {
    await query('DELETE dbo.KhachHang WHERE MaKH=@id', [
      { name: 'id', type: sql.VarChar(10), value: req.params.id }
    ]);
    res.redirect('/customers');
  } catch (e) {
    res.render('error', { title: 'Không thể xóa', message: e.message });
  }
});

module.exports = router;
