const express = require('express');
const { testConnection, describeConfig } = require('../config/db');

const router = express.Router();

router.get('/db', async (req, res) => {
  try {
    const info = await testConnection();
    return res.json({
      ok: true,
      message: 'Kết nối SQL Server thành công.',
      target: describeConfig(),
      server: info.ServerName,
      service: info.ServiceName,
      database: info.DatabaseName,
      localTcpPort: info.LocalTcpPort
    });
  } catch (error) {
    return res.status(503).json({
      ok: false,
      message: 'Không kết nối được SQL Server.',
      target: describeConfig(),
      error: error.message,
      code: error.code || null,
      originalError: error.originalError?.message || null
    });
  }
});

module.exports = router;
