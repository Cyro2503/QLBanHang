const express = require('express');
const crypto = require('crypto');
const { sql, query, getPool } = require('../config/db');
const {
  hashPassword,
  verifyPassword,
  createSession,
  getSession,
  destroySession,
  destroySessionsForAccount
} = require('../utils/auth');

const router = express.Router();
const OTP_TTL_MINUTES = 10;
const OTP_MAX_ATTEMPTS = 5;
const OTP_MAX_SENDS_15M = 3;
const OTP_COOLDOWN_SECONDS = 60;
const OAUTH_STATE_COOKIE_MAX_AGE = 10 * 60;

function sanitizeReturnUrl(value) {
  const url = String(value || '/');
  return url.startsWith('/') && !url.startsWith('//') ? url : '/';
}

function rows(result) {
  return result?.[0]?.recordset || result?.recordset || [];
}

function getCookie(req, name) {
  const raw = req.headers.cookie || '';
  for (const piece of raw.split(';')) {
    const [key, ...rest] = piece.trim().split('=');
    if (key === name) return decodeURIComponent(rest.join('='));
  }
  return null;
}

function appendCookie(res, cookie) {
  const current = res.getHeader('Set-Cookie');
  if (!current) res.setHeader('Set-Cookie', [cookie]);
  else res.setHeader('Set-Cookie', Array.isArray(current) ? [...current, cookie] : [current, cookie]);
}

function cookieOptions(req, maxAge) {
  const secure = process.env.NODE_ENV === 'production' || String(process.env.COOKIE_SECURE || '').toLowerCase() === 'true';
  return `Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secure ? '; Secure' : ''}`;
}

function oauthEnabled() {
  return {
    google: Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET && process.env.OAUTH_STATE_SECRET),
    facebook: Boolean(process.env.FACEBOOK_APP_ID && process.env.FACEBOOK_APP_SECRET && process.env.OAUTH_STATE_SECRET)
  };
}

function renderLogin(res, { error = null, success = null, returnUrl = '/', registration = null } = {}) {
  return res.render('auth/login', {
    title: 'Đăng nhập TechMart',
    error,
    success,
    registration,
    returnUrl: sanitizeReturnUrl(returnUrl),
    oauthEnabled: oauthEnabled()
  });
}

async function loadUserById(id) {
  const accountResult = await query(`
    SELECT tk.TaiKhoanId, tk.TenDangNhap, tk.MatKhauHash, tk.MaNV, tk.TrangThai,
           nv.HoTen, nv.ChucVu, vt.MaVaiTro, vt.TenVaiTro
    FROM dbo.TaiKhoan tk
    LEFT JOIN dbo.NhanVien nv ON nv.MaNV=tk.MaNV
    LEFT JOIN dbo.TaiKhoanVaiTro tv ON tv.TaiKhoanId=tk.TaiKhoanId
    LEFT JOIN dbo.VaiTro vt ON vt.MaVaiTro=tv.MaVaiTro
    WHERE tk.TaiKhoanId=@id
  `, [{ name: 'id', type: sql.Int, value: Number(id) }]);
  const row = rows(accountResult)[0];
  if (!row) return null;

  const permissionsResult = await query(`
    SELECT q.MaQuyen
    FROM dbo.TaiKhoanVaiTro tv
    INNER JOIN dbo.VaiTroQuyen vq ON vq.MaVaiTro=tv.MaVaiTro
    INNER JOIN dbo.Quyen q ON q.MaQuyen=vq.MaQuyen
    WHERE tv.TaiKhoanId=@id
    ORDER BY q.MaQuyen
  `, [{ name: 'id', type: sql.Int, value: Number(id) }]);

  return {
    TaiKhoanId: row.TaiKhoanId,
    TenDangNhap: row.TenDangNhap,
    MaNV: row.MaNV,
    HoTen: row.HoTen || 'Quản trị hệ thống',
    ChucVu: row.ChucVu || row.TenVaiTro || 'Quản trị viên',
    MaVaiTro: row.MaVaiTro,
    TenVaiTro: row.TenVaiTro || 'Chưa phân quyền',
    TrangThai: row.TrangThai,
    permissions: rows(permissionsResult).map(x => x.MaQuyen)
  };
}

async function completeLogin(accountId, res, returnUrl = '/') {
  const accountResult = await query(`
    SELECT TaiKhoanId, TrangThai, MaNV
    FROM dbo.TaiKhoan WHERE TaiKhoanId=@id
  `, [{ name: 'id', type: sql.Int, value: Number(accountId) }]);
  const account = rows(accountResult)[0];
  if (!account || account.TrangThai !== 'HOAT_DONG') {
    return { ok: false, message: 'Tài khoản không hoạt động hoặc chưa được Admin kích hoạt.' };
  }

  const user = await loadUserById(account.TaiKhoanId);
  if (!user || !user.MaVaiTro || !user.permissions.length) {
    return { ok: false, message: 'Tài khoản chưa được Admin phân quyền đầy đủ.' };
  }
  await query('UPDATE dbo.TaiKhoan SET LanDangNhapCuoi=SYSDATETIME() WHERE TaiKhoanId=@id', [
    { name: 'id', type: sql.Int, value: account.TaiKhoanId }
  ]);
  createSession(res, user);
  return { ok: true, redirect: sanitizeReturnUrl(returnUrl) };
}

function normalizeEmail(value) {
  const email = String(value || '').trim().toLowerCase();
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return null;
  return email;
}

function normalizePhone(value) {
  let phone = String(value || '').trim().replace(/[\s().-]/g, '');
  if (/^0\d{9}$/.test(phone)) phone = `+84${phone.slice(1)}`;
  if (!/^\+[1-9]\d{7,14}$/.test(phone)) return null;
  return phone;
}

function otpSecret() {
  const secret = String(process.env.OTP_HASH_SECRET || '');
  if (secret.length < 32) throw new Error('OTP_HASH_SECRET phải có ít nhất 32 ký tự trong .env.');
  return secret;
}

function hashOtp(code) {
  return crypto.createHmac('sha256', otpSecret()).update(String(code)).digest('hex');
}

function hashIp(ip) {
  return crypto.createHmac('sha256', otpSecret()).update(String(ip || '')).digest('hex');
}

function safeEqualHex(a, b) {
  try {
    const aa = Buffer.from(String(a || ''), 'hex');
    const bb = Buffer.from(String(b || ''), 'hex');
    return aa.length === bb.length && aa.length > 0 && crypto.timingSafeEqual(aa, bb);
  } catch { return false; }
}

function maskDestination(channel, value) {
  const text = String(value || '');
  if (channel === 'EMAIL') {
    const [local, domain] = text.split('@');
    return `${(local || '').slice(0, 2)}***@${domain || ''}`;
  }
  return `${text.slice(0, 4)}****${text.slice(-3)}`;
}

async function sendEmailOtp(destination, code) {
  const host = process.env.SMTP_HOST || 'smtp.gmail.com';
  const port = Number(process.env.SMTP_PORT || 587);
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  if (!user || !pass) throw new Error('Chưa cấu hình SMTP_USER/SMTP_PASS để gửi email OTP.');
  const nodemailer = require('nodemailer');
  const transporter = nodemailer.createTransport({
    host,
    port,
    secure: String(process.env.SMTP_SECURE || 'false').toLowerCase() === 'true',
    auth: { user, pass },
    tls: { minVersion: 'TLSv1.2' }
  });
  await transporter.sendMail({
    from: process.env.SMTP_FROM || `TechMart <${user}>`,
    to: destination,
    subject: 'Mã xác minh tài khoản TechMart',
    text: `Mã xác minh TechMart của bạn là ${code}. Mã có hiệu lực trong ${OTP_TTL_MINUTES} phút và chỉ sử dụng một lần. Nếu bạn không thực hiện yêu cầu này, hãy bỏ qua email.`,
    html: `<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:24px;color:#24324b"><h2>TechMart · Xác minh tài khoản</h2><p>Mã xác minh của bạn:</p><div style="font-size:32px;font-weight:800;letter-spacing:8px;padding:16px;background:#f1f5ff;border-radius:12px;text-align:center">${code}</div><p>Mã có hiệu lực ${OTP_TTL_MINUTES} phút, chỉ sử dụng một lần.</p><p>Nếu bạn không yêu cầu mã này, hãy bỏ qua email.</p></div>`
  });
}

async function sendSmsOtp(destination, code) {
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const from = process.env.TWILIO_FROM_NUMBER;
  if (!sid || !token || !from) throw new Error('Chưa cấu hình TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN và TWILIO_FROM_NUMBER.');
  const endpoint = `https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(sid)}/Messages.json`;
  const body = new URLSearchParams({
    To: destination,
    From: from,
    Body: `TechMart: Ma xac minh cua ban la ${code}. Ma co hieu luc ${OTP_TTL_MINUTES} phut. Khong chia se ma nay voi bat ky ai.`
  });
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${Buffer.from(`${sid}:${token}`).toString('base64')}`,
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body
  });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`SMS Gateway từ chối gửi mã (${response.status}): ${detail.slice(0, 300)}`);
  }
}

async function createAndSendOtp({ accountId, purpose, channel, destination, ip }) {
  await query(`DELETE FROM dbo.MaXacMinhTaiKhoan WHERE TaoLuc < DATEADD(DAY,-30,SYSDATETIME())`);
  const destinationHash = hashOtp(`DEST:${destination}`);
  const countResult = await query(`
    SELECT COUNT(*) AS Total, MAX(TaoLuc) AS LastSent
    FROM dbo.MaXacMinhTaiKhoan
    WHERE TaiKhoanId=@id AND MucDich=@purpose AND Kenh=@channel
      AND TaoLuc >= DATEADD(MINUTE,-15,SYSDATETIME())
  `, [
    { name: 'id', type: sql.Int, value: accountId },
    { name: 'purpose', type: sql.VarChar(20), value: purpose },
    { name: 'channel', type: sql.VarChar(10), value: channel }
  ]);
  const rate = rows(countResult)[0] || {};
  if (Number(rate.Total || 0) >= OTP_MAX_SENDS_15M) throw new Error('Bạn đã yêu cầu quá nhiều mã. Vui lòng thử lại sau 15 phút.');
  if (rate.LastSent && Date.now() - new Date(rate.LastSent).getTime() < OTP_COOLDOWN_SECONDS * 1000) {
    throw new Error('Vui lòng đợi 60 giây trước khi yêu cầu mã mới.');
  }
  const requestIpHash = hashIp(ip);
  const ipRateResult = await query(`
    SELECT COUNT(*) AS Total FROM dbo.MaXacMinhTaiKhoan
    WHERE IpHash=@ipHash AND TaoLuc >= DATEADD(MINUTE,-15,SYSDATETIME())
  `, [{ name: 'ipHash', type: sql.Char(64), value: requestIpHash }]);
  if (Number(rows(ipRateResult)[0]?.Total || 0) >= 10) throw new Error('Địa chỉ mạng đã yêu cầu quá nhiều mã. Vui lòng thử lại sau 15 phút.');

  const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
  const inserted = await query(`
    INSERT dbo.MaXacMinhTaiKhoan(TaiKhoanId,MucDich,Kenh,DoiTuongHash,MaHash,HetHanLuc,IpHash)
    OUTPUT INSERTED.OtpId
    VALUES(@id,@purpose,@channel,@destinationHash,@hash,DATEADD(MINUTE,@ttl,SYSDATETIME()),@ipHash)
  `, [
    { name: 'id', type: sql.Int, value: accountId },
    { name: 'purpose', type: sql.VarChar(20), value: purpose },
    { name: 'channel', type: sql.VarChar(10), value: channel },
    { name: 'destinationHash', type: sql.Char(64), value: destinationHash },
    { name: 'hash', type: sql.Char(64), value: hashOtp(code) },
    { name: 'ttl', type: sql.Int, value: OTP_TTL_MINUTES },
    { name: 'ipHash', type: sql.Char(64), value: requestIpHash }
  ]);
  const otpId = rows(inserted)[0]?.OtpId;

  try {
    if (channel === 'EMAIL') await sendEmailOtp(destination, code);
    else await sendSmsOtp(destination, code);
  } catch (error) {
    if (otpId) await query('UPDATE dbo.MaXacMinhTaiKhoan SET DaSuDungLuc=SYSDATETIME() WHERE OtpId=@id', [
      { name: 'id', type: sql.BigInt, value: otpId }
    ]);
    throw error;
  }
}

async function consumeOtp({ accountId, purpose, channel, destination, code, apply }) {
  const pool = await getPool();
  const tx = new sql.Transaction(pool);
  await tx.begin();
  try {
    const request = new sql.Request(tx);
    request.input('id', sql.Int, accountId);
    request.input('purpose', sql.VarChar(20), purpose);
    request.input('channel', sql.VarChar(10), channel);
    request.input('destinationHash', sql.Char(64), hashOtp(`DEST:${destination}`));
    const found = await request.query(`
      SELECT TOP 1 OtpId,MaHash,HetHanLuc,SoLanSai,DaSuDungLuc
      FROM dbo.MaXacMinhTaiKhoan WITH (UPDLOCK,ROWLOCK)
      WHERE TaiKhoanId=@id AND MucDich=@purpose AND Kenh=@channel
        AND DoiTuongHash=@destinationHash AND DaSuDungLuc IS NULL
      ORDER BY TaoLuc DESC,OtpId DESC
    `);
    const otp = found.recordset[0];
    if (!otp || otp.DaSuDungLuc || new Date(otp.HetHanLuc).getTime() <= Date.now() || Number(otp.SoLanSai) >= OTP_MAX_ATTEMPTS) {
      await tx.rollback();
      return false;
    }

    if (!safeEqualHex(otp.MaHash, hashOtp(code))) {
      const wrong = new sql.Request(tx);
      wrong.input('otpId', sql.BigInt, otp.OtpId);
      await wrong.query(`UPDATE dbo.MaXacMinhTaiKhoan SET SoLanSai=SoLanSai+1,
        DaSuDungLuc=CASE WHEN SoLanSai+1 >= ${OTP_MAX_ATTEMPTS} THEN SYSDATETIME() ELSE NULL END
        WHERE OtpId=@otpId`);
      await tx.commit();
      return false;
    }

    await apply(tx, otp);
    const used = new sql.Request(tx);
    used.input('otpId', sql.BigInt, otp.OtpId);
    await used.query('UPDATE dbo.MaXacMinhTaiKhoan SET DaSuDungLuc=SYSDATETIME() WHERE OtpId=@otpId');
    await tx.commit();
    return true;
  } catch (error) {
    try { await tx.rollback(); } catch { /* giao dịch có thể đã kết thúc */ }
    throw error;
  }
}

async function renderSecurity(req, res, { error = null, success = null, pending = null } = {}) {
  const session = getSession(req);
  if (!session) return res.redirect('/auth/login');
  if (!success && req.query.linked === '1') success = 'Đã liên kết tài khoản mạng xã hội thành công.';
  try {
    const recoveryResult = await query(`
      SELECT Email,EmailXacMinhLuc,SoDienThoai,SDTXacMinhLuc
      FROM dbo.ThongTinKhoiPhucTaiKhoan WHERE TaiKhoanId=@id
    `, [{ name: 'id', type: sql.Int, value: session.user.TaiKhoanId }]);
    const linksResult = await query(`
      SELECT Provider,ProviderEmail,NgayLienKet
      FROM dbo.TaiKhoanLienKet WHERE TaiKhoanId=@id ORDER BY Provider
    `, [{ name: 'id', type: sql.Int, value: session.user.TaiKhoanId }]);
    const recovery = rows(recoveryResult)[0] || {};
    const linked = rows(linksResult);
    return res.render('auth/security', {
      title: 'Bảo mật và liên kết tài khoản',
      currentUser: session.user,
      recovery,
      linked,
      oauthEnabled: oauthEnabled(),
      error,
      success,
      pending
    });
  } catch (e) {
    console.error(e);
    return res.status(500).render('error', { title: 'Lỗi bảo mật tài khoản', message: 'Không thể tải thông tin bảo mật. Hãy kiểm tra migration 08_Auth_External_Recovery.sql.' });
  }
}

function oauthStateSecret() {
  const value = String(process.env.OAUTH_STATE_SECRET || '');
  if (value.length < 32) throw new Error('OAUTH_STATE_SECRET phải có ít nhất 32 ký tự.');
  return value;
}

function signOAuthState(payload) {
  const data = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', oauthStateSecret()).update(data).digest('base64url');
  return `${data}.${sig}`;
}

function verifyOAuthState(value) {
  const [data, signature] = String(value || '').split('.');
  if (!data || !signature) return null;
  const expected = crypto.createHmac('sha256', oauthStateSecret()).update(data).digest('base64url');
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(data, 'base64url').toString('utf8'));
    if (!payload.exp || payload.exp < Date.now()) return null;
    return payload;
  } catch { return null; }
}

function providerConfig(provider) {
  if (provider === 'google') {
    return {
      provider: 'GOOGLE',
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackUrl: process.env.GOOGLE_CALLBACK_URL || `${process.env.APP_BASE_URL || 'http://localhost:3000'}/auth/oauth/google/callback`
    };
  }
  if (provider === 'facebook') {
    return {
      provider: 'FACEBOOK',
      clientId: process.env.FACEBOOK_APP_ID,
      clientSecret: process.env.FACEBOOK_APP_SECRET,
      callbackUrl: process.env.FACEBOOK_CALLBACK_URL || `${process.env.APP_BASE_URL || 'http://localhost:3000'}/auth/oauth/facebook/callback`
    };
  }
  return null;
}

router.get('/login', (req, res) => {
  const session = getSession(req);
  if (session) return res.redirect('/');
  return renderLogin(res, {
    registration: req.query.registration === 'disabled' ? 'disabled' : null,
    returnUrl: sanitizeReturnUrl(req.query.returnUrl),
    success: req.query.passwordChanged === '1' ? 'Mật khẩu đã được thay đổi. Hãy đăng nhập lại.' : null,
    error: req.query.socialError ? 'Không thể đăng nhập bằng tài khoản liên kết. Hãy thử lại hoặc đăng nhập nội bộ.' : null
  });
});

router.post('/login', async (req, res) => {
  const body = req.body || {};
  const username = String(body.TenDangNhap || '').trim();
  const password = String(body.MatKhau || '');
  const returnUrl = sanitizeReturnUrl(body.returnUrl);
  const privacyConsent = String(body.privacyConsent || '').toLowerCase();

  if (!username || !password) return renderLogin(res, { error: 'Vui lòng nhập tên đăng nhập và mật khẩu.', returnUrl });
  if (!['true', 'on', '1'].includes(privacyConsent)) {
    return renderLogin(res, { error: 'Bạn cần xác nhận đồng ý với chính sách bảo vệ dữ liệu cá nhân để tiếp tục đăng nhập.', returnUrl });
  }

  try {
    const result = await query(`SELECT TaiKhoanId,MatKhauHash,TrangThai,MaNV FROM dbo.TaiKhoan WHERE TenDangNhap=@username`, [
      { name: 'username', type: sql.VarChar(50), value: username }
    ]);
    const account = rows(result)[0];
    if (!account || !verifyPassword(password, account.MatKhauHash)) {
      return renderLogin(res, { error: 'Tên đăng nhập hoặc mật khẩu không đúng.', returnUrl });
    }
    if (account.TrangThai === 'KHOA') return renderLogin(res, { error: 'Tài khoản đang bị khóa. Hãy liên hệ Admin.', returnUrl });
    if (account.TrangThai !== 'HOAT_DONG') {
      return renderLogin(res, { error: 'Tài khoản chưa được Admin tạo và kích hoạt đầy đủ.', returnUrl });
    }
    const login = await completeLogin(account.TaiKhoanId, res, returnUrl);
    if (!login.ok) return renderLogin(res, { error: login.message, returnUrl });
    return res.redirect(login.redirect);
  } catch (error) {
    console.error('Lỗi đăng nhập nội bộ:', error);
    return renderLogin(res, { error: 'Không thể đăng nhập. Kiểm tra kết nối CSDL và cấu hình hệ thống.', returnUrl });
  }
});

// Không có đăng ký công khai. Tài khoản chỉ được tạo từ khu vực quản trị Admin.
router.get('/register', (req, res) => res.redirect('/auth/login?registration=disabled'));
router.post('/register', (req, res) => res.redirect('/auth/login?registration=disabled'));

router.get('/forgot-password', (req, res) => {
  return res.render('auth/forgot-password', { title: 'Khôi phục mật khẩu', error: null, success: null, stage: 'request', channel: 'EMAIL', destination: '' });
});

router.post('/forgot-password/send-code', async (req, res) => {
  const channel = String(req.body.channel || '').toUpperCase();
  const destination = channel === 'EMAIL' ? normalizeEmail(req.body.destination) : channel === 'SMS' ? normalizePhone(req.body.destination) : null;
  if (!destination) return res.status(400).render('auth/forgot-password', {
    title: 'Khôi phục mật khẩu', error: 'Thông tin email hoặc số điện thoại chưa hợp lệ.', success: null, stage: 'request', channel, destination: String(req.body.destination || '')
  });

  try {
    const verifiedColumn = channel === 'EMAIL' ? 'EmailXacMinhLuc' : 'SDTXacMinhLuc';
    const contactColumn = channel === 'EMAIL' ? 'Email' : 'SoDienThoai';
    const found = await query(`
      SELECT TOP 1 t.TaiKhoanId
      FROM dbo.ThongTinKhoiPhucTaiKhoan r
      INNER JOIN dbo.TaiKhoan t ON t.TaiKhoanId=r.TaiKhoanId
      WHERE r.${contactColumn}=@destination AND r.${verifiedColumn} IS NOT NULL
        AND t.TrangThai='HOAT_DONG'
    `, [{ name: 'destination', type: sql.NVarChar(254), value: destination }]);
    const account = rows(found)[0];
    if (account) {
      try {
        await createAndSendOtp({
          accountId: account.TaiKhoanId,
          purpose: 'RESET_PASSWORD',
          channel,
          destination,
          ip: req.ip
        });
      } catch (sendError) {
        console.error('Không gửi được OTP khôi phục:', sendError.message);
      }
    }
    // Phản hồi giống nhau dù thông tin có tồn tại hay không, tránh dò tài khoản.
    return res.render('auth/forgot-password', {
      title: 'Khôi phục mật khẩu', error: null,
      success: 'Nếu thông tin khớp với một tài khoản đã xác minh, mã 6 chữ số sẽ được gửi. Mã có hiệu lực 10 phút.',
      stage: 'reset', channel, destination
    });
  } catch (error) {
    console.error('Lỗi yêu cầu OTP khôi phục:', error);
    return res.status(500).render('auth/forgot-password', {
      title: 'Khôi phục mật khẩu', error: 'Dịch vụ xác minh hiện chưa sẵn sàng. Vui lòng liên hệ Admin.', success: null,
      stage: 'request', channel, destination
    });
  }
});

router.post('/forgot-password/reset', async (req, res) => {
  const channel = String(req.body.channel || '').toUpperCase();
  const destination = channel === 'EMAIL' ? normalizeEmail(req.body.destination) : channel === 'SMS' ? normalizePhone(req.body.destination) : null;
  const code = String(req.body.code || '').replace(/\s/g, '');
  const password = String(req.body.password || '');
  const confirm = String(req.body.confirmPassword || '');
  const render = (error, success = null) => res.status(error ? 400 : 200).render('auth/forgot-password', {
    title: 'Khôi phục mật khẩu', error, success, stage: 'reset', channel, destination: destination || String(req.body.destination || '')
  });

  if (!destination || !/^\d{6}$/.test(code)) return render('Vui lòng nhập đúng mã xác minh gồm 6 chữ số.');
  if (password.length < 8) return render('Mật khẩu mới phải có ít nhất 8 ký tự.');
  if (password !== confirm) return render('Mật khẩu xác nhận không khớp.');

  try {
    const verifiedColumn = channel === 'EMAIL' ? 'EmailXacMinhLuc' : 'SDTXacMinhLuc';
    const contactColumn = channel === 'EMAIL' ? 'Email' : 'SoDienThoai';
    const found = await query(`
      SELECT TOP 1 t.TaiKhoanId
      FROM dbo.ThongTinKhoiPhucTaiKhoan r
      INNER JOIN dbo.TaiKhoan t ON t.TaiKhoanId=r.TaiKhoanId
      WHERE r.${contactColumn}=@destination AND r.${verifiedColumn} IS NOT NULL
        AND t.TrangThai='HOAT_DONG'
    `, [{ name: 'destination', type: sql.NVarChar(254), value: destination }]);
    const account = rows(found)[0];
    if (!account) return render('Mã xác minh không hợp lệ hoặc đã hết hạn.');

    const ok = await consumeOtp({
      accountId: account.TaiKhoanId,
      purpose: 'RESET_PASSWORD',
      channel,
      destination,
      code,
      apply: async tx => {
        const update = new sql.Request(tx);
        update.input('id', sql.Int, account.TaiKhoanId);
        update.input('hash', sql.VarChar(300), hashPassword(password));
        await update.query('UPDATE dbo.TaiKhoan SET MatKhauHash=@hash WHERE TaiKhoanId=@id AND TrangThai=\'HOAT_DONG\'');
      }
    });
    if (!ok) return render('Mã xác minh không đúng, đã hết hạn hoặc đã được sử dụng.');
    destroySessionsForAccount(account.TaiKhoanId);
    return res.render('auth/forgot-password', {
      title: 'Khôi phục mật khẩu', error: null,
      success: 'Đổi mật khẩu thành công. Bạn có thể đăng nhập bằng mật khẩu mới.',
      stage: 'complete', channel, destination
    });
  } catch (error) {
    console.error('Lỗi đặt lại mật khẩu:', error);
    return render('Không thể đặt lại mật khẩu. Vui lòng thử lại hoặc liên hệ Admin.');
  }
});

router.get('/security', (req, res) => renderSecurity(req, res));

router.post('/security/email/send-code', async (req, res) => {
  const session = getSession(req);
  if (!session) return res.redirect('/auth/login');
  const email = normalizeEmail(req.body.email);
  if (!email) return renderSecurity(req, res, { error: 'Địa chỉ Gmail/email chưa hợp lệ.' });
  try {
    const conflict = await query('SELECT TaiKhoanId FROM dbo.ThongTinKhoiPhucTaiKhoan WHERE Email=@email AND TaiKhoanId<>@id', [
      { name: 'email', type: sql.NVarChar(254), value: email },
      { name: 'id', type: sql.Int, value: session.user.TaiKhoanId }
    ]);
    if (rows(conflict).length) return renderSecurity(req, res, { error: 'Email này đã được liên kết với tài khoản TechMart khác.' });
    await createAndSendOtp({ accountId: session.user.TaiKhoanId, purpose: 'VERIFY_EMAIL', channel: 'EMAIL', destination: email, ip: req.ip });
    return renderSecurity(req, res, { success: `Đã gửi mã xác minh đến ${maskDestination('EMAIL', email)}.`, pending: { channel: 'EMAIL', destination: email } });
  } catch (error) {
    console.error('Lỗi gửi mã liên kết email:', error.message);
    return renderSecurity(req, res, { error: error.message.includes('quá nhiều') || error.message.includes('đợi 60') ? error.message : 'Không thể gửi email xác minh. Kiểm tra cấu hình SMTP hoặc liên hệ Admin.' });
  }
});

router.post('/security/phone/send-code', async (req, res) => {
  const session = getSession(req);
  if (!session) return res.redirect('/auth/login');
  const phone = normalizePhone(req.body.phone);
  if (!phone) return renderSecurity(req, res, { error: 'Số điện thoại chưa đúng định dạng. Dùng +84 hoặc số di động Việt Nam 10 chữ số.' });
  try {
    const conflict = await query('SELECT TaiKhoanId FROM dbo.ThongTinKhoiPhucTaiKhoan WHERE SoDienThoai=@phone AND TaiKhoanId<>@id', [
      { name: 'phone', type: sql.VarChar(20), value: phone },
      { name: 'id', type: sql.Int, value: session.user.TaiKhoanId }
    ]);
    if (rows(conflict).length) return renderSecurity(req, res, { error: 'Số điện thoại này đã được liên kết với tài khoản TechMart khác.' });
    await createAndSendOtp({ accountId: session.user.TaiKhoanId, purpose: 'VERIFY_PHONE', channel: 'SMS', destination: phone, ip: req.ip });
    return renderSecurity(req, res, { success: `Đã gửi mã SMS đến ${maskDestination('SMS', phone)}.`, pending: { channel: 'SMS', destination: phone } });
  } catch (error) {
    console.error('Lỗi gửi mã liên kết số điện thoại:', error.message);
    return renderSecurity(req, res, { error: error.message.includes('quá nhiều') || error.message.includes('đợi 60') ? error.message : 'Không thể gửi SMS xác minh. Kiểm tra cấu hình SMS Gateway hoặc liên hệ Admin.' });
  }
});

router.post('/security/verify-code', async (req, res) => {
  const session = getSession(req);
  if (!session) return res.redirect('/auth/login');
  const channel = String(req.body.channel || '').toUpperCase();
  const destination = channel === 'EMAIL' ? normalizeEmail(req.body.destination) : channel === 'SMS' ? normalizePhone(req.body.destination) : null;
  const code = String(req.body.code || '').replace(/\s/g, '');
  if (!destination || !/^\d{6}$/.test(code) || !['EMAIL', 'SMS'].includes(channel)) {
    return renderSecurity(req, res, { error: 'Thông tin xác minh không hợp lệ.' });
  }
  try {
    const isEmail = channel === 'EMAIL';
    const ok = await consumeOtp({
      accountId: session.user.TaiKhoanId,
      purpose: isEmail ? 'VERIFY_EMAIL' : 'VERIFY_PHONE',
      channel,
      destination,
      code,
      apply: async tx => {
        const request = new sql.Request(tx);
        request.input('id', sql.Int, session.user.TaiKhoanId);
        request.input('destination', isEmail ? sql.NVarChar(254) : sql.VarChar(20), destination);
        if (isEmail) {
          await request.query(`
            IF EXISTS(SELECT 1 FROM dbo.ThongTinKhoiPhucTaiKhoan WHERE TaiKhoanId=@id)
              UPDATE dbo.ThongTinKhoiPhucTaiKhoan SET Email=@destination,EmailXacMinhLuc=SYSDATETIME(),CapNhatLuc=SYSDATETIME() WHERE TaiKhoanId=@id;
            ELSE INSERT dbo.ThongTinKhoiPhucTaiKhoan(TaiKhoanId,Email,EmailXacMinhLuc) VALUES(@id,@destination,SYSDATETIME());
          `);
        } else {
          await request.query(`
            IF EXISTS(SELECT 1 FROM dbo.ThongTinKhoiPhucTaiKhoan WHERE TaiKhoanId=@id)
              UPDATE dbo.ThongTinKhoiPhucTaiKhoan SET SoDienThoai=@destination,SDTXacMinhLuc=SYSDATETIME(),CapNhatLuc=SYSDATETIME() WHERE TaiKhoanId=@id;
            ELSE INSERT dbo.ThongTinKhoiPhucTaiKhoan(TaiKhoanId,SoDienThoai,SDTXacMinhLuc) VALUES(@id,@destination,SYSDATETIME());
          `);
        }
      }
    });
    if (!ok) return renderSecurity(req, res, { error: 'Mã xác minh không đúng, đã hết hạn hoặc đã được sử dụng.' });
    return renderSecurity(req, res, { success: `${channel === 'EMAIL' ? 'Email' : 'Số điện thoại'} đã được xác minh và liên kết thành công.` });
  } catch (error) {
    console.error('Lỗi xác minh thông tin khôi phục:', error);
    if (error.number === 2601 || error.number === 2627) return renderSecurity(req, res, { error: 'Thông tin này đã được liên kết với tài khoản khác.' });
    return renderSecurity(req, res, { error: 'Không thể xác minh thông tin. Vui lòng thử lại.' });
  }
});

router.post('/security/unlink/:provider', async (req, res) => {
  const session = getSession(req);
  if (!session) return res.redirect('/auth/login');
  const provider = String(req.params.provider || '').toUpperCase();
  if (!['GOOGLE', 'FACEBOOK'].includes(provider)) return renderSecurity(req, res, { error: 'Nhà cung cấp không hợp lệ.' });
  try {
    await query('DELETE FROM dbo.TaiKhoanLienKet WHERE TaiKhoanId=@id AND Provider=@provider', [
      { name: 'id', type: sql.Int, value: session.user.TaiKhoanId },
      { name: 'provider', type: sql.VarChar(20), value: provider }
    ]);
    return renderSecurity(req, res, { success: `Đã hủy liên kết ${provider === 'GOOGLE' ? 'Google' : 'Facebook'}. Tài khoản nội bộ vẫn hoạt động bình thường.` });
  } catch (error) {
    console.error('Lỗi hủy liên kết mạng xã hội:', error);
    return renderSecurity(req, res, { error: 'Không thể hủy liên kết lúc này.' });
  }
});

router.get('/oauth/:provider/start', (req, res) => {
  const provider = String(req.params.provider || '').toLowerCase();
  const config = providerConfig(provider);
  if (!config || !config.clientId || !config.clientSecret || !process.env.OAUTH_STATE_SECRET) {
    if (getSession(req)) return renderSecurity(req, res, { error: 'Nhà cung cấp đăng nhập chưa được cấu hình bởi Admin.' });
    return renderLogin(res, { error: 'Phương thức đăng nhập này chưa được cấu hình.' });
  }
  try {
    const session = getSession(req);
    const state = signOAuthState({
      provider,
      mode: session ? 'link' : 'login',
      accountId: session?.user?.TaiKhoanId || null,
      exp: Date.now() + OAUTH_STATE_COOKIE_MAX_AGE * 1000,
      nonce: crypto.randomBytes(18).toString('hex')
    });
    const cookieName = `tm_oauth_${provider}`;
    res.setHeader('Set-Cookie', `${cookieName}=${encodeURIComponent(state)}; ${cookieOptions(req, OAUTH_STATE_COOKIE_MAX_AGE)}`);
    const params = new URLSearchParams({ client_id: config.clientId, redirect_uri: config.callbackUrl, response_type: 'code', state });
    let authorizationUrl;
    if (provider === 'google') {
      params.set('scope', 'openid email profile');
      params.set('access_type', 'online');
      params.set('prompt', 'select_account');
      authorizationUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
    } else {
      params.set('scope', 'public_profile,email');
      authorizationUrl = `https://www.facebook.com/${process.env.FACEBOOK_GRAPH_VERSION || 'v25.0'}/dialog/oauth?${params.toString()}`;
    }
    return res.redirect(authorizationUrl);
  } catch (error) {
    console.error('Không thể bắt đầu OAuth:', error.message);
    return getSession(req) ? renderSecurity(req, res, { error: 'Không thể bắt đầu liên kết tài khoản.' }) : renderLogin(res, { error: 'Không thể bắt đầu đăng nhập mạng xã hội.' });
  }
});

router.get('/oauth/:provider/callback', async (req, res) => {
  const provider = String(req.params.provider || '').toLowerCase();
  const config = providerConfig(provider);
  const cookieName = `tm_oauth_${provider}`;
  const cookieState = getCookie(req, cookieName);
  appendCookie(res, `${cookieName}=; ${cookieOptions(req, 0)}`);
  if (!config || !config.clientId || !config.clientSecret || !cookieState || !req.query.state || cookieState !== req.query.state || req.query.error) {
    return renderLogin(res, { error: 'Xác thực mạng xã hội bị hủy hoặc không hợp lệ.' });
  }

  try {
    const state = verifyOAuthState(String(req.query.state));
    if (!state || state.provider !== provider) return renderLogin(res, { error: 'Phiên xác thực đã hết hạn. Vui lòng thử lại.' });
    const code = String(req.query.code || '');
    if (!code) return renderLogin(res, { error: 'Nhà cung cấp không trả về mã xác thực.' });

    let profile;
    if (provider === 'google') {
      const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          code, client_id: config.clientId, client_secret: config.clientSecret,
          redirect_uri: config.callbackUrl, grant_type: 'authorization_code'
        })
      });
      const tokenData = await tokenResponse.json();
      if (!tokenResponse.ok || !tokenData.access_token) throw new Error('Google không cấp access token hợp lệ.');
      const userResponse = await fetch('https://openidconnect.googleapis.com/v1/userinfo', {
        headers: { Authorization: `Bearer ${tokenData.access_token}` }
      });
      profile = await userResponse.json();
      if (!userResponse.ok || !profile.sub || profile.email_verified !== true) throw new Error('Không xác minh được danh tính Google/email.');
    } else {
      const tokenUrl = new URL(`https://graph.facebook.com/${process.env.FACEBOOK_GRAPH_VERSION || 'v25.0'}/oauth/access_token`);
      tokenUrl.search = new URLSearchParams({
        client_id: config.clientId, client_secret: config.clientSecret,
        redirect_uri: config.callbackUrl, code
      }).toString();
      const tokenResponse = await fetch(tokenUrl);
      const tokenData = await tokenResponse.json();
      if (!tokenResponse.ok || !tokenData.access_token) throw new Error('Facebook không cấp access token hợp lệ.');
      const profileUrl = new URL(`https://graph.facebook.com/${process.env.FACEBOOK_GRAPH_VERSION || 'v25.0'}/me`);
      profileUrl.search = new URLSearchParams({ fields: 'id,name,email', access_token: tokenData.access_token }).toString();
      const userResponse = await fetch(profileUrl);
      profile = await userResponse.json();
      if (!userResponse.ok || !profile.id) throw new Error('Không xác minh được tài khoản Facebook.');
    }

    const providerCode = config.provider;
    const providerUserId = String(provider === 'google' ? profile.sub : profile.id);
    const providerEmail = normalizeEmail(profile.email) || null;

    if (state.mode === 'link') {
      const session = getSession(req);
      if (!session || Number(session.user.TaiKhoanId) !== Number(state.accountId)) {
        return renderLogin(res, { error: 'Phiên TechMart đã hết hạn. Hãy đăng nhập lại trước khi liên kết.' });
      }
      const conflict = await query(`
        SELECT TaiKhoanId FROM dbo.TaiKhoanLienKet
        WHERE Provider=@provider AND ProviderUserId=@providerId
      `, [
        { name: 'provider', type: sql.VarChar(20), value: providerCode },
        { name: 'providerId', type: sql.NVarChar(191), value: providerUserId }
      ]);
      const linkedAccount = rows(conflict)[0];
      if (linkedAccount && Number(linkedAccount.TaiKhoanId) !== Number(session.user.TaiKhoanId)) {
        return renderSecurity(req, res, { error: 'Tài khoản mạng xã hội này đã liên kết với một tài khoản TechMart khác.' });
      }
      await query(`
        IF EXISTS(SELECT 1 FROM dbo.TaiKhoanLienKet WHERE TaiKhoanId=@accountId AND Provider=@provider)
          UPDATE dbo.TaiKhoanLienKet SET ProviderUserId=@providerId,ProviderEmail=@email,NgayLienKet=SYSDATETIME() WHERE TaiKhoanId=@accountId AND Provider=@provider;
        ELSE INSERT dbo.TaiKhoanLienKet(TaiKhoanId,Provider,ProviderUserId,ProviderEmail) VALUES(@accountId,@provider,@providerId,@email);
      `, [
        { name: 'accountId', type: sql.Int, value: session.user.TaiKhoanId },
        { name: 'provider', type: sql.VarChar(20), value: providerCode },
        { name: 'providerId', type: sql.NVarChar(191), value: providerUserId },
        { name: 'email', type: sql.NVarChar(254), value: providerEmail }
      ]);
      return res.redirect('/auth/security?linked=1');
    }

    const linked = await query(`
      SELECT l.TaiKhoanId
      FROM dbo.TaiKhoanLienKet l
      INNER JOIN dbo.TaiKhoan t ON t.TaiKhoanId=l.TaiKhoanId
      WHERE l.Provider=@provider AND l.ProviderUserId=@providerId
        AND t.TrangThai='HOAT_DONG'
    `, [
      { name: 'provider', type: sql.VarChar(20), value: providerCode },
      { name: 'providerId', type: sql.NVarChar(191), value: providerUserId }
    ]);
    const linkedAccount = rows(linked)[0];
    if (!linkedAccount) return renderLogin(res, { error: 'Tài khoản mạng xã hội này chưa được liên kết. Hãy đăng nhập nội bộ và liên kết trong mục Bảo mật tài khoản.', returnUrl: '/' });
    const login = await completeLogin(linkedAccount.TaiKhoanId, res, '/');
    if (!login.ok) return renderLogin(res, { error: login.message });
    return res.redirect(login.redirect);
  } catch (error) {
    console.error(`OAuth ${provider} error:`, error.message);
    return renderLogin(res, { error: 'Không thể xác thực tài khoản mạng xã hội. Hãy thử lại hoặc đăng nhập nội bộ.' });
  }
});

function renderChangePassword(req, res, { error = null, success = null } = {}) {
  const session = getSession(req);
  if (!session) return res.redirect('/auth/login');
  return res.render('auth/change-password', {
    title: 'Đổi mật khẩu', error, success, currentUser: session.user
  });
}

router.get('/change-password', (req, res) => renderChangePassword(req, res));
router.post('/change-password', async (req, res) => {
  const session = getSession(req);
  if (!session) return res.redirect('/auth/login');
  const current = String(req.body.MatKhauCu || '');
  const next = String(req.body.MatKhauMoi || '');
  const confirm = String(req.body.XacNhanMatKhau || '');
  try {
    const result = await query('SELECT MatKhauHash FROM dbo.TaiKhoan WHERE TaiKhoanId=@id', [
      { name: 'id', type: sql.Int, value: session.user.TaiKhoanId }
    ]);
    const row = rows(result)[0];
    if (!row || !verifyPassword(current, row.MatKhauHash)) return renderChangePassword(req, res, { error: 'Mật khẩu hiện tại không đúng.' });
    if (next.length < 8) return renderChangePassword(req, res, { error: 'Mật khẩu mới phải có ít nhất 8 ký tự.' });
    if (next !== confirm) return renderChangePassword(req, res, { error: 'Mật khẩu xác nhận không khớp.' });
    if (next === current) return renderChangePassword(req, res, { error: 'Mật khẩu mới phải khác mật khẩu hiện tại.' });
    await query('UPDATE dbo.TaiKhoan SET MatKhauHash=@h WHERE TaiKhoanId=@id', [
      { name: 'h', type: sql.VarChar(300), value: hashPassword(next) },
      { name: 'id', type: sql.Int, value: session.user.TaiKhoanId }
    ]);
    destroySessionsForAccount(session.user.TaiKhoanId);
    destroySession(req, res);
    return res.redirect('/auth/login?passwordChanged=1');
  } catch (error) {
    console.error(error);
    return renderChangePassword(req, res, { error: 'Không thể đổi mật khẩu.' });
  }
});

router.post('/logout', (req, res) => {
  destroySession(req, res);
  return res.redirect('/auth/login');
});

module.exports = router;
