const express = require('express');
const { sql, getPool, query } = require('../config/db');
const { required, positiveInt, positiveNumber } = require('../utils/validation');

const router = express.Router();

async function loadLists() {
  const [employees, products, suppliers] = await Promise.all([
    query('SELECT MaNV,HoTen FROM dbo.NhanVien ORDER BY MaNV'),
    query('SELECT MaSP,TenSP FROM dbo.SanPham ORDER BY MaSP'),
    query('SELECT MaNCC,TenNCC FROM dbo.NhaCungCap ORDER BY MaNCC')
  ]);
  return { employees: employees[0].recordset, products: products[0].recordset, suppliers: suppliers[0].recordset };
}

router.get('/', async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim();
    const from = /^\d{4}-\d{2}-\d{2}$/.test(req.query.from || '') ? req.query.from : '';
    const to = /^\d{4}-\d{2}-\d{2}$/.test(req.query.to || '') ? req.query.to : '';
    const pageSize = [20, 50, 100].includes(Number(req.query.size)) ? Number(req.query.size) : 20;
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const params = [
      { name: 'q', type: sql.NVarChar(200), value: `%${q}%` },
      { name: 'fromDate', type: sql.Date, value: from || null },
      { name: 'toDate', type: sql.Date, value: to || null }
    ];
    const joins = `FROM dbo.PhieuNhap pn JOIN dbo.NhanVien nv ON nv.MaNV=pn.MaNV`;
    const where = `WHERE (@q='%%' OR pn.SoPN LIKE @q OR nv.HoTen LIKE @q OR nv.MaNV LIKE @q OR EXISTS (SELECT 1 FROM dbo.ChiTietPhieuNhap ctp JOIN dbo.NhaCungCap ncc ON ncc.MaNCC=ctp.MaNCC WHERE ctp.SoPN=pn.SoPN AND (ncc.TenNCC LIKE @q OR ncc.MaNCC LIKE @q))) AND (@fromDate IS NULL OR pn.NgayNhap >= @fromDate) AND (@toDate IS NULL OR pn.NgayNhap < DATEADD(day,1,@toDate))`;
    const count = await query(`SELECT COUNT(*) AS Total ${joins} ${where}`, params);
    const total = Number(count[0].recordset[0].Total || 0);
    const pages = Math.max(1, Math.ceil(total / pageSize));
    const currentPage = Math.min(page, pages);
    const r = await query(`
      SELECT pn.SoPN,pn.NgayNhap,pn.MaNV,nv.HoTen AS TenNhanVien,ISNULL(t.TongTien,0) AS TongTien
      ${joins}
      OUTER APPLY (SELECT SUM(ct.SoLuong*ct.GiaNhap) AS TongTien FROM dbo.ChiTietPhieuNhap ct WHERE ct.SoPN=pn.SoPN) t
      ${where}
      ORDER BY pn.NgayNhap DESC,pn.SoPN DESC OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY
    `, [...params, { name: 'Offset', type: sql.Int, value: (currentPage - 1) * pageSize }, { name: 'PageSize', type: sql.Int, value: pageSize }]);
    res.render('purchases/index', { title: 'Phiếu nhập', rows: r[0].recordset, q, from, to, page: currentPage, pages, pageSize, total });
  } catch (e) { next(e); }
});

router.get('/create', async (req, res, next) => {
  try {
    res.render('purchases/create', { title: 'Lập phiếu nhập', ...(await loadLists()), error: null, form: { MaNV: '', Lines: [{}] } });
  } catch (e) { next(e); }
});

router.post('/create', async (req, res) => {
  const lists = await loadLists();
  const form = req.body;
  let products = form.MaSP || [];
  let suppliers = form.MaNCC || [];
  if (!Array.isArray(products)) products = [products];
  if (!Array.isArray(suppliers)) suppliers = [suppliers];
  const qty = Array.isArray(form.SoLuong) ? form.SoLuong : [form.SoLuong];
  const prices = Array.isArray(form.GiaNhap) ? form.GiaNhap : [form.GiaNhap];
  const lines = products.map((MaSP, i) => ({ MaSP, MaNCC: suppliers[i], SoLuong: qty[i], GiaNhap: prices[i] })).filter(x => required(x.MaSP) && required(x.MaNCC));
  form.Lines = lines;

  if (!required(form.MaNV) || lines.length === 0) {
    return res.render('purchases/create', { title: 'Lập phiếu nhập', ...lists, error: 'Phải chọn nhân viên và ít nhất một dòng nhập.', form });
  }
  for (const line of lines) {
    if (!positiveInt(line.SoLuong) || !positiveNumber(line.GiaNhap)) {
      return res.render('purchases/create', { title: 'Lập phiếu nhập', ...lists, error: 'Số lượng và giá nhập phải lớn hơn 0.', form });
    }
  }

  try {
    const pool = await getPool();
    const tx = new sql.Transaction(pool);
    await tx.begin();
    try {
      const reqNo = new sql.Request(tx);
      const noResult = await reqNo.query(`
        SELECT 'PN' + RIGHT('00000000' + CONVERT(varchar(8), ISNULL(MAX(TRY_CONVERT(int,SUBSTRING(SoPN,3,8))),0)+1),8) AS SoPN
        FROM dbo.PhieuNhap
        WHERE SoPN LIKE 'PN[0-9]%'
      `);
      const soPN = noResult.recordset[0].SoPN;

      const insertHead = new sql.Request(tx);
      insertHead.input('SoPN', sql.VarChar(10), soPN);
      insertHead.input('MaNV', sql.VarChar(10), form.MaNV);
      await insertHead.query('INSERT dbo.PhieuNhap(SoPN,MaNV) VALUES(@SoPN,@MaNV)');

      for (const line of lines) {
        const d = new sql.Request(tx);
        d.input('SoPN', sql.VarChar(10), soPN);
        d.input('MaSP', sql.VarChar(10), line.MaSP);
        d.input('MaNCC', sql.VarChar(10), line.MaNCC);
        d.input('SL', sql.Int, Number(line.SoLuong));
        d.input('Gia', sql.Decimal(18, 2), Number(line.GiaNhap));
        await d.query(`INSERT dbo.ChiTietPhieuNhap(SoPN,MaSP,MaNCC,SoLuong,GiaNhap) VALUES(@SoPN,@MaSP,@MaNCC,@SL,@Gia)`);
      }

      await tx.commit();
      return res.redirect(`/purchases/${encodeURIComponent(soPN)}`);
    } catch (e) {
      await tx.rollback();
      throw e;
    }
  } catch (e) {
    return res.render('purchases/create', { title: 'Lập phiếu nhập', ...lists, error: e.message, form });
  }
});

router.get('/:id', async (req, res, next) => {
  try {
    const p = await query(`
      SELECT pn.SoPN,pn.NgayNhap,pn.MaNV,nv.HoTen AS TenNhanVien,
             ISNULL(SUM(ct.SoLuong*ct.GiaNhap),0) AS TongTien
      FROM dbo.PhieuNhap pn
      JOIN dbo.NhanVien nv ON nv.MaNV=pn.MaNV
      LEFT JOIN dbo.ChiTietPhieuNhap ct ON ct.SoPN=pn.SoPN
      WHERE pn.SoPN=@id
      GROUP BY pn.SoPN,pn.NgayNhap,pn.MaNV,nv.HoTen
    `, [{ name: 'id', type: sql.VarChar(10), value: req.params.id }]);
    const purchase = p[0].recordset[0];
    if (!purchase) return res.status(404).render('error', { title: 'Không tìm thấy', message: 'Phiếu nhập không tồn tại.' });

    const lines = await query(`
      SELECT ct.SoPN,ct.MaSP,sp.TenSP,ct.MaNCC,ncc.TenNCC,ct.SoLuong,ct.GiaNhap,
             ct.SoLuong*ct.GiaNhap AS ThanhTien
      FROM dbo.ChiTietPhieuNhap ct
      JOIN dbo.SanPham sp ON sp.MaSP=ct.MaSP
      JOIN dbo.NhaCungCap ncc ON ncc.MaNCC=ct.MaNCC
      WHERE ct.SoPN=@id
      ORDER BY ct.MaSP
    `, [{ name: 'id', type: sql.VarChar(10), value: req.params.id }]);

    res.render('purchases/details', { title: `Phiếu nhập ${purchase.SoPN}`, purchase, lines: lines[0].recordset });
  } catch (e) { next(e); }
});

module.exports = router;
