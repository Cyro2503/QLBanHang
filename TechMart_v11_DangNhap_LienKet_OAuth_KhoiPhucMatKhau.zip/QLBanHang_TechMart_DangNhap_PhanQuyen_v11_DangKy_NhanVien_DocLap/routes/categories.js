const express = require('express');
const { sql, query } = require('../config/db');
const { required } = require('../utils/validation');

const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim();
    const pageSize = [20, 50, 100].includes(Number(req.query.size)) ? Number(req.query.size) : 20;
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const params = [{ name: 'q', type: sql.NVarChar(200), value: `%${q}%` }];
    const where = `WHERE (@q = '%%' OR MaLoai LIKE @q OR TenLoai LIKE @q)`;
    const count = await query(`SELECT COUNT(*) AS Total FROM dbo.LoaiSanPham ${where}`, params);
    const total = Number(count[0].recordset[0].Total || 0);
    const pages = Math.max(1, Math.ceil(total / pageSize));
    const currentPage = Math.min(page, pages);
    const result = await query(`SELECT MaLoai,TenLoai FROM dbo.LoaiSanPham ${where}
      ORDER BY MaLoai OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY`, [
      ...params,
      { name: 'Offset', type: sql.Int, value: (currentPage - 1) * pageSize },
      { name: 'PageSize', type: sql.Int, value: pageSize }
    ]);
    res.render('categories/index', {
      title: 'Loại sản phẩm', rows: result[0].recordset,
      q, page: currentPage, pages, pageSize, total
    });
  } catch (e) { next(e); }
});

router.get('/create', (req, res) => res.render('categories/form', {
  title: 'Thêm loại sản phẩm',
  action: '/categories/create',
  row: {},
  create: true,
  error: null
}));

router.post('/create', async (req, res) => {
  const { MaLoai, TenLoai } = req.body;
  if (!required(MaLoai) || !required(TenLoai)) {
    return res.render('categories/form', { title: 'Thêm loại sản phẩm', action: '/categories/create', row: req.body, create: true, error: 'Mã loại và tên loại không được để trống.' });
  }
  try {
    await query('INSERT dbo.LoaiSanPham(MaLoai, TenLoai) VALUES(@MaLoai,@TenLoai)', [
      { name: 'MaLoai', type: sql.VarChar(10), value: MaLoai.trim() },
      { name: 'TenLoai', type: sql.NVarChar(100), value: TenLoai.trim() }
    ]);
    res.redirect('/categories');
  } catch (e) {
    res.render('categories/form', { title: 'Thêm loại sản phẩm', action: '/categories/create', row: req.body, create: true, error: e.message });
  }
});

router.get('/edit/:id', async (req, res, next) => {
  try {
    const r = await query('SELECT MaLoai, TenLoai FROM dbo.LoaiSanPham WHERE MaLoai=@id', [
      { name: 'id', type: sql.VarChar(10), value: req.params.id }
    ]);
    const row = r[0].recordset[0];
    if (!row) return res.status(404).render('error', { title: 'Không tìm thấy', message: 'Loại sản phẩm không tồn tại.' });
    res.render('categories/form', { title: 'Sửa loại sản phẩm', action: `/categories/edit/${encodeURIComponent(req.params.id)}`, row, create: false, error: null });
  } catch (e) { next(e); }
});

router.post('/edit/:id', async (req, res) => {
  const { TenLoai } = req.body;
  try {
    await query('UPDATE dbo.LoaiSanPham SET TenLoai=@TenLoai WHERE MaLoai=@MaLoai', [
      { name: 'TenLoai', type: sql.NVarChar(100), value: TenLoai },
      { name: 'MaLoai', type: sql.VarChar(10), value: req.params.id }
    ]);
    res.redirect('/categories');
  } catch (e) {
    res.render('categories/form', { title: 'Sửa loại sản phẩm', action: `/categories/edit/${encodeURIComponent(req.params.id)}`, row: { MaLoai: req.params.id, TenLoai }, create: false, error: e.message });
  }
});

router.post('/delete/:id', async (req, res) => {
  try {
    await query('DELETE dbo.LoaiSanPham WHERE MaLoai=@id', [
      { name: 'id', type: sql.VarChar(10), value: req.params.id }
    ]);
    res.redirect('/categories');
  } catch (e) {
    res.render('error', { title: 'Không thể xóa', message: e.message });
  }
});

module.exports = router;
