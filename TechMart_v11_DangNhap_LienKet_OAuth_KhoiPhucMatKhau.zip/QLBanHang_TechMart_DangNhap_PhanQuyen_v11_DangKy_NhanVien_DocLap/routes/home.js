const express = require('express');
const { sql, query } = require('../config/db');

const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const stats = {};
    stats.soSanPham = (await query('SELECT COUNT(*) AS value FROM dbo.SanPham'))[0]?.recordset[0]?.value || 0;
    stats.soKhachHang = (await query('SELECT COUNT(*) AS value FROM dbo.KhachHang'))[0]?.recordset[0]?.value || 0;
    stats.soNhanVien = (await query('SELECT COUNT(*) AS value FROM dbo.NhanVien'))[0]?.recordset[0]?.value || 0;
    stats.soHoaDon = (await query('SELECT COUNT(*) AS value FROM dbo.HoaDon'))[0]?.recordset[0]?.value || 0;

    const orangeThreshold = Number(process.env.LOW_STOCK_ORANGE_THRESHOLD || 50);
    const redThreshold = Number(process.env.LOW_STOCK_RED_THRESHOLD || 10);

    const result = await query(`
      SELECT TOP 10 MaSP, TenSP, DonViTinh, GiaBan, SoLuongTon, MaLoai
      FROM dbo.SanPham
      WHERE SoLuongTon <= @orangeThreshold
      ORDER BY
        CASE WHEN SoLuongTon <= @redThreshold THEN 0 ELSE 1 END,
        SoLuongTon, MaSP
    `, [
      { name: 'orangeThreshold', type: sql.Int, value: orangeThreshold },
      { name: 'redThreshold', type: sql.Int, value: redThreshold }
    ]);

    const lowStockCountResult = await query(`
      SELECT
        SUM(CASE WHEN SoLuongTon <= @orangeThreshold THEN 1 ELSE 0 END) AS SoSanPhamCanhBao,
        SUM(CASE WHEN SoLuongTon <= @redThreshold THEN 1 ELSE 0 END) AS SoSanPhamMucDoDo,
        SUM(CASE WHEN SoLuongTon > @redThreshold AND SoLuongTon <= @orangeThreshold THEN 1 ELSE 0 END) AS SoSanPhamMucDoCam
      FROM dbo.SanPham
    `, [
      { name: 'orangeThreshold', type: sql.Int, value: orangeThreshold },
      { name: 'redThreshold', type: sql.Int, value: redThreshold }
    ]);
    const lowStockSummary = lowStockCountResult[0].recordset[0] || {
      SoSanPhamCanhBao: 0,
      SoSanPhamMucDoDo: 0,
      SoSanPhamMucDoCam: 0
    };

    const recent = await query(`
      SELECT TOP 8
        hd.SoHD, hd.NgayLap, hd.MaKH, kh.HoTen AS TenKhachHang,
        hd.MaNV, nv.HoTen AS TenNhanVien, hd.TrangThai,
        ISNULL(SUM(ct.SoLuong * ct.DonGiaBan * (1 - ct.PhanTramGiam / 100.0)), 0) AS TongTien
      FROM dbo.HoaDon hd
      JOIN dbo.KhachHang kh ON kh.MaKH = hd.MaKH
      JOIN dbo.NhanVien nv ON nv.MaNV = hd.MaNV
      LEFT JOIN dbo.ChiTietHoaDon ct ON ct.SoHD = hd.SoHD
      GROUP BY hd.SoHD, hd.NgayLap, hd.MaKH, kh.HoTen, hd.MaNV, nv.HoTen, hd.TrangThai
      ORDER BY hd.NgayLap DESC, hd.SoHD DESC
    `);

    const revenue = await query(`
      SELECT ISNULL(SUM(DoanhThu), 0) AS DoanhThu
      FROM bc.vw_DoanhThuTheoThang
      WHERE Nam = YEAR(GETDATE()) AND Thang = MONTH(GETDATE())
    `);

    const revenueTrendData = await query(`
      WITH months AS (
        SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL
        SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9 UNION ALL
        SELECT 10 UNION ALL SELECT 11
      )
      SELECT
        YEAR(DATEADD(MONTH, m.n, DATEADD(MONTH, -11, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)))) AS Nam,
        MONTH(DATEADD(MONTH, m.n, DATEADD(MONTH, -11, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)))) AS Thang,
        ISNULL(t.DoanhThu, 0) AS DoanhThu
      FROM months m
      LEFT JOIN bc.vw_DoanhThuTheoThang t
        ON t.Nam = YEAR(DATEADD(MONTH, m.n, DATEADD(MONTH, -11, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))))
       AND t.Thang = MONTH(DATEADD(MONTH, m.n, DATEADD(MONTH, -11, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1))))
      ORDER BY Nam, Thang
    `);

    const currentYear = new Date().getFullYear();
    const revenueTrendMap = new Map(
      (revenueTrendData[0]?.recordset || []).map(item => [
        `${Number(item.Nam || currentYear)}-${Number(item.Thang || 1)}`,
        Number(item.DoanhThu || 0)
      ])
    );

    const revenueTrend = Array.from({ length: 12 }, (_, index) => {
      const monthNumber = index + 1;
      const monthYear = currentYear;
      const monthKey = `${monthYear}-${monthNumber}`;
      return {
        Nam: monthYear,
        Thang: monthNumber,
        DoanhThu: revenueTrendMap.get(monthKey) || 0,
        label: `Th${monthNumber}`
      };
    }).sort((a, b) => Number(a.Thang) - Number(b.Thang));

    const revenueTrendMax = Math.max(1, ...revenueTrend.map(item => item.DoanhThu));

    const currentUser = req.user || {
      HoTen: 'Người dùng',
      TenVaiTro: 'Chưa phân quyền'
    };

    res.render('home/index', {
      title: 'Tổng quan',
      currentUser,
      stats,
      lowStock: result[0].recordset,
      lowStockCount: Number(lowStockSummary.SoSanPhamCanhBao || 0),
      redStockCount: Number(lowStockSummary.SoSanPhamMucDoDo || 0),
      orangeStockCount: Number(lowStockSummary.SoSanPhamMucDoCam || 0),
      lowStockOrangeThreshold: orangeThreshold,
      lowStockRedThreshold: redThreshold,
      recentInvoices: recent[0].recordset,
      monthRevenue: revenue[0].recordset[0]?.DoanhThu || 0,
      revenueTrend: Array.isArray(revenueTrend) ? revenueTrend : [],
      revenueTrendMax: Number(revenueTrendMax) > 0 ? Number(revenueTrendMax) : 1
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
