const express = require('express');
const { sql, query } = require('../config/db');
const { required, nonNegativeNumber } = require('../utils/validation');

const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim();
    const pageSize = [20, 50, 100].includes(Number(req.query.size)) ? Number(req.query.size) : 20;
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const params = [{ name: 'q', type: sql.NVarChar(200), value: `%${q}%` }];
    const where = `WHERE (@q = '%%' OR MaNV LIKE @q OR HoTen LIKE @q OR ChucVu LIKE @q OR GioiTinh LIKE @q)`;
    const count = await query(`SELECT COUNT(*) AS Total FROM dbo.NhanVien ${where}`, params);
    const total = Number(count[0].recordset[0].Total || 0);
    const pages = Math.max(1, Math.ceil(total / pageSize));
    const currentPage = Math.min(page, pages);
    const r = await query(`SELECT MaNV,HoTen,NgaySinh,GioiTinh,ChucVu,LuongCoBan,NgayVaoLam FROM dbo.NhanVien ${where} ORDER BY HoTen,MaNV OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY`, [
      ...params,
      { name: 'Offset', type: sql.Int, value: (currentPage - 1) * pageSize },
      { name: 'PageSize', type: sql.Int, value: pageSize }
    ]);
    res.render('employees/index', { title: 'Nhân viên', rows: r[0].recordset, q, page: currentPage, pages, pageSize, total });
  } catch (e) { next(e); }
});

router.get('/create', (req, res) => res.render('employees/form', {
  title: 'Thêm nhân viên', action: '/employees/create', create: true, error: null,
  row: { NgaySinh: '2000-01-01', NgayVaoLam: new Date().toISOString().slice(0, 10), GioiTinh: 'Nam', LuongCoBan: 0 }
}));

router.post('/create', async (req, res) => {
  const row = req.body;
  if (!required(row.MaNV) || !required(row.HoTen) || !required(row.NgaySinh) || !required(row.GioiTinh) || !required(row.ChucVu) || !required(row.NgayVaoLam) || !nonNegativeNumber(row.LuongCoBan)) {
    return res.render('employees/form', { title: 'Thêm nhân viên', action: '/employees/create', create: true, error: 'Vui lòng nhập đầy đủ và lương không âm.', row });
  }
  try {
    await query(`INSERT dbo.NhanVien(MaNV,HoTen,NgaySinh,GioiTinh,ChucVu,LuongCoBan,NgayVaoLam) VALUES(@MaNV,@HoTen,@NS,@GT,@CV,@Luong,@Vao)`, [
      { name: 'MaNV', type: sql.VarChar(10), value: row.MaNV },
      { name: 'HoTen', type: sql.NVarChar(100), value: row.HoTen },
      { name: 'NS', type: sql.Date, value: row.NgaySinh },
      { name: 'GT', type: sql.NVarChar(3), value: row.GioiTinh },
      { name: 'CV', type: sql.NVarChar(50), value: row.ChucVu },
      { name: 'Luong', type: sql.Decimal(18, 2), value: Number(row.LuongCoBan) },
      { name: 'Vao', type: sql.Date, value: row.NgayVaoLam }
    ]);
    res.redirect('/employees');
  } catch (e) {
    res.render('employees/form', { title: 'Thêm nhân viên', action: '/employees/create', create: true, error: e.message, row });
  }
});

router.get('/edit/:id', async (req, res, next) => {
  try {
    const r = await query('SELECT MaNV,HoTen,NgaySinh,GioiTinh,ChucVu,LuongCoBan,NgayVaoLam FROM dbo.NhanVien WHERE MaNV=@id', [
      { name: 'id', type: sql.VarChar(10), value: req.params.id }
    ]);
    const row = r[0].recordset[0];
    if (!row) return res.status(404).render('error', { title: 'Không tìm thấy', message: 'Nhân viên không tồn tại.' });
    row.NgaySinh = row.NgaySinh?.toISOString().slice(0, 10);
    row.NgayVaoLam = row.NgayVaoLam?.toISOString().slice(0, 10);
    res.render('employees/form', { title: 'Sửa nhân viên', action: `/employees/edit/${encodeURIComponent(req.params.id)}`, create: false, error: null, row });
  } catch (e) { next(e); }
});

router.post('/edit/:id', async (req, res) => {
  const row = { ...req.body, MaNV: req.params.id };
  try {
    await query(`UPDATE dbo.NhanVien SET HoTen=@HoTen,NgaySinh=@NS,GioiTinh=@GT,ChucVu=@CV,LuongCoBan=@Luong,NgayVaoLam=@Vao WHERE MaNV=@MaNV`, [
      { name: 'HoTen', type: sql.NVarChar(100), value: row.HoTen },
      { name: 'NS', type: sql.Date, value: row.NgaySinh },
      { name: 'GT', type: sql.NVarChar(3), value: row.GioiTinh },
      { name: 'CV', type: sql.NVarChar(50), value: row.ChucVu },
      { name: 'Luong', type: sql.Decimal(18, 2), value: Number(row.LuongCoBan) },
      { name: 'Vao', type: sql.Date, value: row.NgayVaoLam },
      { name: 'MaNV', type: sql.VarChar(10), value: row.MaNV }
    ]);
    res.redirect('/employees');
  } catch (e) {
    res.render('employees/form', { title: 'Sửa nhân viên', action: `/employees/edit/${encodeURIComponent(req.params.id)}`, create: false, error: e.message, row });
  }
});

router.post('/delete/:id', async (req, res) => {
  try {
    await query('DELETE dbo.NhanVien WHERE MaNV=@id', [{ name: 'id', type: sql.VarChar(10), value: req.params.id }]);
    res.redirect('/employees');
  } catch (e) { res.render('error', { title: 'Không thể xóa', message: e.message }); }
});

module.exports = router;
