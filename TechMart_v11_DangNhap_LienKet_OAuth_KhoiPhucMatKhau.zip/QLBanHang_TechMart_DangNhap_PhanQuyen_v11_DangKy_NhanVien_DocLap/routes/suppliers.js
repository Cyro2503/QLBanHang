const express = require('express');
const { sql, query } = require('../config/db');
const { required } = require('../utils/validation');

const router = express.Router();

function isEmail(value) {
  if (!value) return true;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

router.get('/', async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim();
    const pageSize = [20, 50, 100].includes(Number(req.query.size)) ? Number(req.query.size) : 20;
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const params = [{ name: 'q', type: sql.NVarChar(200), value: `%${q}%` }];
    const where = `WHERE (@q = '%%' OR MaNCC LIKE @q OR TenNCC LIKE @q
      OR ISNULL(SoDienThoai,'') LIKE @q OR ISNULL(Email,'') LIKE @q OR ISNULL(DiaChi,'') LIKE @q)`;
    const count = await query(`SELECT COUNT(*) AS Total FROM dbo.NhaCungCap ${where}`, params);
    const total = Number(count[0].recordset[0].Total || 0);
    const pages = Math.max(1, Math.ceil(total / pageSize));
    const currentPage = Math.min(page, pages);
    const result = await query(`SELECT MaNCC,TenNCC,SoDienThoai,Email,DiaChi
      FROM dbo.NhaCungCap ${where} ORDER BY MaNCC
      OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY`, [
      ...params,
      { name: 'Offset', type: sql.Int, value: (currentPage - 1) * pageSize },
      { name: 'PageSize', type: sql.Int, value: pageSize }
    ]);
    res.render('suppliers/index', {
      title: 'Nhà cung cấp', rows: result[0].recordset,
      q, page: currentPage, pages, pageSize, total
    });
  } catch (e) {
    next(e);
  }
});

router.get('/create', (req, res) => {
  res.render('suppliers/form', {
    title: 'Thêm nhà cung cấp',
    action: '/suppliers/create',
    row: {},
    create: true,
    error: null
  });
});

router.post('/create', async (req, res) => {
  const row = req.body;

  if (!required(row.MaNCC) || !required(row.TenNCC)) {
    return res.render('suppliers/form', {
      title: 'Thêm nhà cung cấp',
      action: '/suppliers/create',
      row,
      create: true,
      error: 'Mã và tên nhà cung cấp là bắt buộc.'
    });
  }

  if (!isEmail(row.Email)) {
    return res.render('suppliers/form', {
      title: 'Thêm nhà cung cấp',
      action: '/suppliers/create',
      row,
      create: true,
      error: 'Gmail/Email không đúng định dạng.'
    });
  }

  try {
    await query(`
      INSERT dbo.NhaCungCap
          (MaNCC, TenNCC, SoDienThoai, Email, DiaChi)
      VALUES
          (@MaNCC, @TenNCC, @Phone, @Email, @Addr)
    `, [
      {
        name: 'MaNCC',
        type: sql.VarChar(10),
        value: row.MaNCC
      },
      {
        name: 'TenNCC',
        type: sql.NVarChar(150),
        value: row.TenNCC
      },
      {
        name: 'Phone',
        type: sql.VarChar(15),
        value: row.SoDienThoai || null
      },
      {
        name: 'Email',
        type: sql.VarChar(100),
        value: row.Email || null
      },
      {
        name: 'Addr',
        type: sql.NVarChar(255),
        value: row.DiaChi || null
      }
    ]);

    res.redirect('/suppliers');
  } catch (e) {
    res.render('suppliers/form', {
      title: 'Thêm nhà cung cấp',
      action: '/suppliers/create',
      row,
      create: true,
      error: e.message
    });
  }
});

router.get('/edit/:id', async (req, res, next) => {
  try {
    const r = await query(`
      SELECT
          MaNCC,
          TenNCC,
          SoDienThoai,
          Email,
          DiaChi
      FROM dbo.NhaCungCap
      WHERE MaNCC = @id
    `, [
      {
        name: 'id',
        type: sql.VarChar(10),
        value: req.params.id
      }
    ]);

    const row = r[0].recordset[0];

    if (!row) {
      return res.status(404).render('error', {
        title: 'Không tìm thấy',
        message: 'Nhà cung cấp không tồn tại.'
      });
    }

    res.render('suppliers/form', {
      title: 'Sửa nhà cung cấp',
      action: `/suppliers/edit/${encodeURIComponent(req.params.id)}`,
      row,
      create: false,
      error: null
    });
  } catch (e) {
    next(e);
  }
});

router.post('/edit/:id', async (req, res) => {
  const row = {
    ...req.body,
    MaNCC: req.params.id
  };

  if (!required(row.TenNCC)) {
    return res.render('suppliers/form', {
      title: 'Sửa nhà cung cấp',
      action: `/suppliers/edit/${encodeURIComponent(req.params.id)}`,
      row,
      create: false,
      error: 'Tên nhà cung cấp là bắt buộc.'
    });
  }

  if (!isEmail(row.Email)) {
    return res.render('suppliers/form', {
      title: 'Sửa nhà cung cấp',
      action: `/suppliers/edit/${encodeURIComponent(req.params.id)}`,
      row,
      create: false,
      error: 'Gmail/Email không đúng định dạng.'
    });
  }

  try {
    await query(`
      UPDATE dbo.NhaCungCap
      SET
          TenNCC = @TenNCC,
          SoDienThoai = @Phone,
          Email = @Email,
          DiaChi = @Addr
      WHERE MaNCC = @MaNCC
    `, [
      {
        name: 'TenNCC',
        type: sql.NVarChar(150),
        value: row.TenNCC
      },
      {
        name: 'Phone',
        type: sql.VarChar(15),
        value: row.SoDienThoai || null
      },
      {
        name: 'Email',
        type: sql.VarChar(100),
        value: row.Email || null
      },
      {
        name: 'Addr',
        type: sql.NVarChar(255),
        value: row.DiaChi || null
      },
      {
        name: 'MaNCC',
        type: sql.VarChar(10),
        value: row.MaNCC
      }
    ]);

    res.redirect('/suppliers');
  } catch (e) {
    res.render('suppliers/form', {
      title: 'Sửa nhà cung cấp',
      action: `/suppliers/edit/${encodeURIComponent(req.params.id)}`,
      row,
      create: false,
      error: e.message
    });
  }
});

router.post('/delete/:id', async (req, res) => {
  try {
    await query(
      'DELETE dbo.NhaCungCap WHERE MaNCC = @id',
      [
        {
          name: 'id',
          type: sql.VarChar(10),
          value: req.params.id
        }
      ]
    );

    res.redirect('/suppliers');
  } catch (e) {
    res.render('error', {
      title: 'Không thể xóa',
      message: e.message
    });
  }
});

module.exports = router;
