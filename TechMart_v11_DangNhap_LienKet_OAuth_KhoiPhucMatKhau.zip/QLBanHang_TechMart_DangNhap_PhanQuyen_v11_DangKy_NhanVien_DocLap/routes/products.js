const express = require('express');
const { sql, query } = require('../config/db');
const { required, positiveNumber, nonNegativeNumber } = require('../utils/validation');

const router = express.Router();

async function categories() {
  return (await query('SELECT MaLoai,TenLoai FROM dbo.LoaiSanPham ORDER BY MaLoai'))[0].recordset;
}

async function load(id) {
  const r = await query('SELECT MaSP,TenSP,DonViTinh,GiaBan,SoLuongTon,MaLoai FROM dbo.SanPham WHERE MaSP=@id', [
    { name: 'id', type: sql.VarChar(10), value: id }
  ]);
  return r[0].recordset[0];
}

router.get('/', async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim();
    const pageSize = [20, 50, 100].includes(Number(req.query.size)) ? Number(req.query.size) : 20;
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const params = [{ name: 'q', type: sql.NVarChar(200), value: `%${q}%` }];
    const fromWhere = `FROM dbo.SanPham sp JOIN dbo.LoaiSanPham l ON l.MaLoai=sp.MaLoai
      WHERE (@q = '%%' OR sp.MaSP LIKE @q OR sp.TenSP LIKE @q OR sp.DonViTinh LIKE @q
        OR sp.MaLoai LIKE @q OR l.TenLoai LIKE @q)`;
    const count = await query(`SELECT COUNT(*) AS Total ${fromWhere}`, params);
    const total = Number(count[0].recordset[0].Total || 0);
    const pages = Math.max(1, Math.ceil(total / pageSize));
    const currentPage = Math.min(page, pages);
    const result = await query(`SELECT sp.MaSP,sp.TenSP,sp.DonViTinh,sp.GiaBan,sp.SoLuongTon,sp.MaLoai,l.TenLoai
      ${fromWhere} ORDER BY sp.MaSP OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY`, [
      ...params,
      { name: 'Offset', type: sql.Int, value: (currentPage - 1) * pageSize },
      { name: 'PageSize', type: sql.Int, value: pageSize }
    ]);
    res.render('products/index', { title: 'Sản phẩm', rows: result[0].recordset, q, page: currentPage, pages, pageSize, total });
  } catch (e) { next(e); }
});

router.get('/create', async (req, res, next) => {
  try { res.render('products/form', { title: 'Thêm sản phẩm', action: '/products/create', create: true, error: null, row: { SoLuongTon: 0 }, categories: await categories() }); } catch (e) { next(e); }
});

router.post('/create', async (req, res) => {
  const row = req.body;
  const cats = await categories();
  if (!required(row.MaSP) || !required(row.TenSP) || !required(row.DonViTinh) || !required(row.MaLoai) || !positiveNumber(row.GiaBan) || !nonNegativeNumber(row.SoLuongTon)) {
    return res.render('products/form', { title: 'Thêm sản phẩm', action: '/products/create', create: true, error: 'Vui lòng nhập đầy đủ; giá bán phải > 0 và tồn kho không âm.', row, categories: cats });
  }
  try {
    await query(`INSERT dbo.SanPham(MaSP,TenSP,DonViTinh,GiaBan,SoLuongTon,MaLoai) VALUES(@MaSP,@TenSP,@DVT,@Gia,@Ton,@Loai)`, [
      { name: 'MaSP', type: sql.VarChar(10), value: row.MaSP },
      { name: 'TenSP', type: sql.NVarChar(200), value: row.TenSP },
      { name: 'DVT', type: sql.NVarChar(30), value: row.DonViTinh },
      { name: 'Gia', type: sql.Decimal(18, 2), value: Number(row.GiaBan) },
      { name: 'Ton', type: sql.Int, value: Number(row.SoLuongTon) },
      { name: 'Loai', type: sql.VarChar(10), value: row.MaLoai }
    ]);
    res.redirect('/products');
  } catch (e) { res.render('products/form', { title: 'Thêm sản phẩm', action: '/products/create', create: true, error: e.message, row, categories: cats }); }
});

router.get('/edit/:id', async (req, res, next) => {
  try {
    const [row, cats] = await Promise.all([load(req.params.id), categories()]);
    if (!row) return res.status(404).render('error', { title: 'Không tìm thấy', message: 'Sản phẩm không tồn tại.' });
    res.render('products/form', { title: 'Sửa sản phẩm', action: `/products/edit/${encodeURIComponent(req.params.id)}`, create: false, error: null, row, categories: cats });
  } catch (e) { next(e); }
});

router.post('/edit/:id', async (req, res) => {
  const cats = await categories();
  const row = { ...req.body, MaSP: req.params.id };
  try {
    await query(`UPDATE dbo.SanPham SET TenSP=@TenSP,DonViTinh=@DVT,GiaBan=@Gia,SoLuongTon=@Ton,MaLoai=@Loai WHERE MaSP=@MaSP`, [
      { name: 'TenSP', type: sql.NVarChar(200), value: row.TenSP },
      { name: 'DVT', type: sql.NVarChar(30), value: row.DonViTinh },
      { name: 'Gia', type: sql.Decimal(18, 2), value: Number(row.GiaBan) },
      { name: 'Ton', type: sql.Int, value: Number(row.SoLuongTon) },
      { name: 'Loai', type: sql.VarChar(10), value: row.MaLoai },
      { name: 'MaSP', type: sql.VarChar(10), value: row.MaSP }
    ]);
    res.redirect('/products');
  } catch (e) { res.render('products/form', { title: 'Sửa sản phẩm', action: `/products/edit/${encodeURIComponent(req.params.id)}`, create: false, error: e.message, row, categories: cats }); }
});

router.post('/delete/:id', async (req, res) => {
  try {
    await query('DELETE dbo.SanPham WHERE MaSP=@id', [{ name: 'id', type: sql.VarChar(10), value: req.params.id }]);
    res.redirect('/products');
  } catch (e) { res.render('error', { title: 'Không thể xóa', message: e.message }); }
});

module.exports = router;
